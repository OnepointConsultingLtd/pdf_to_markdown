
## 3 Review of PISA data on career aspirations of 15-year-old students

This section reviews the most recent results on the career aspirations of 15-year-old secondary school students from the PISA 2022 survey from OECD countries and non-OECD countries and economies and compares these results with the pre-pandemic wave in 2018. These results from the PISA survey are important as there is evidence from longitudinal studies that early career aspirations in working in the health sector have a predictive character of what young people will end up working in (Schoon, 2001). Many factors can influence the interest of young people in pursuing a career in the health sector or in other sectors, including: 1) intrinsic factors, such as a desire to help others and an interest in the health sector; 2) extrinsic factors, such as remuneration, working conditions, job stability and the prestige of the profession; 3) socio-demographic factors, including gender and socio-economic background; and 4) interpersonal factors, including family influence and interactions with health professionals.

### 3.1 Students’ aspirations in working in the health sector

The PISA 2022 survey results on students’ career aspirations in the health sector in OECD countries are mixed when compared to the findings from the previous wave in 2018. In a third of OECD countries, a greater share of students aspired to become health professionals in 2022 than in 2018, with notable increases in Japan and Korea. However, in about half of OECD countries, students’ interest decreased. This reduction in students’ interest was particularly marked in the United States, Belgium, Canada, Finland and Costa Rica. In other countries, the interest remained stable between 2018 and 2022. By comparison, the share of students aiming for careers as information and communications technology (ICT) professionals increased in nearly all countries.


### Figure 3.4. Share of 15-year-olds expecting to become doctors in non-OECD countries, 2018 and 2022

| Country               | 2018 (%) | 2022 (%) |
|----------------------|----------|----------|
| Gulf Countries       | 25       | 27       |
| Lebanon              | 20       | 21       |
| Kazakhstan           | 15       | 16       |
| Colombia             | 10       | 11       |
| UAE                  | 9        | 10       |
| Brazil               | 8        | 9        |
| Morocco              | 7        | 8        |
| Peru                 | 6        | 7        |
| North Macedonia      | 5        | 5        |
| Jordan               | 4        | 4        |
| Panama               | 3        | 3        |
| Dominican Republic   | 2        | 2        |
| Armenia              | 1        | 2        |
| Other Countries      | 1        | 1        |

Source: OECD, PISA 2018 and 2022 Database.

3.3 Students’ aspirations in working as nurses

Despite long-standing efforts by nurses associations to build a more positive public image of their profession, nursing has never been a career option as popular as becoming a doctor among 15-year-olds, particularly among boys. On average across OECD countries, only around 2% of 15-year-olds expected to become nurses in 2022, a proportion four times lower than those aspiring to become doctors. This ratio is inversely related to the actual composition of the health workforce: on average across OECD countries, there are about two-and-a-half times more nurses than doctors (OECD, 2023).

Interest in pursuing a career in nursing among 15-year-olds has diminished between 2018 and 2022 in half of OECD countries. This reduction was particularly marked in the United States and Canada, some Nordic countries (Norway and Denmark), Ireland, the United Kingdom and Switzerland. Overall, across OECD countries, the share of 15-year-olds expecting to become nurses fell from 2.3% in 2018 to 2.1% in 2022. However, in some OECD countries, the share of 15-year-olds expecting to work as nurses has increased between 2018 and 2022, most notably in Japan, but also to a lesser extent in Korea, the Slovak Republic, Spain and Portugal.

In Poland, the Baltic countries (Latvia, Estonia and Lithuania), Hungary, Italy and Greece, less than 1% of 15-year-olds anticipated working as nurses in 2022. Japan and the United States had the highest share of young people expecting to become nurses, despite the sharp reduction in the United States between 2018 and 2022.
```
{
  "Figure": "3.6 Share of 15-year-olds expecting to become nurses in non-OECD countries, 2018 and 2022",
  "Data": [
    {"Country": "Philippines", "2018": 0.6, "2022": 6.0},
    {"Country": "Ecuador", "2018": 1.0, "2022": 5.5},
    {"Country": "Saudi Arabia", "2018": 2.0, "2022": 5.0},
    {"Country": "Brazil", "2018": 1.7, "2022": 3.0},
    {"Country": "Nepal", "2018": 1.7, "2022": 2.5},
    {"Country": "Peru", "2018": 1.3, "2022": 2.5},
    {"Country": "Dominican Republic", "2018": 0.8, "2022": 2.0},
    {"Country": "Venezuela", "2018": 0.5, "2022": 1.5},
    {"Country": "Mongolia", "2018": 0.4, "2022": 1.0},
    {"Country": "Costa Rica", "2018": 1.0, "2022": 0.8},
    {"Country": "Colombia", "2018": 0.3, "2022": 0.7},
    {"Country": "Chile", "2018": 0.4, "2022": 0.6},
    {"Country": "Argentina", "2018": 0.1, "2022": 0.4}
  ]
}

3.4 Gender differences in interest in working as doctors and nurses

Traditionally, health sector jobs have been more appealing to girls than boys. This is no longer only the case for nursing but also increasingly in medicine. On average across OECD countries, 72% of 15-year-olds who aspired to work as doctors in 2022 were girls. This is up from 69% in 2015. Japan is the only country where boys in 2022 accounted for more than half of 15-year-old students aspiring to become doctors. Analysis of PISA 2018 data showed that girls who performed better in the PISA academic assessments in mathematics, science and reading were more likely to expect to work as doctors, whereas high-achiever boys tended to express higher career aspirations in science or engineering (Mann, Denis and Percy, 2020(16)).
```
The results from PISA 2022 also confirm that nursing continues to be a career aspiration mainly for girls, with very few boys showing interest in this occupation. On average across OECD countries, over 90% of 15-year-old students expecting to work as nurses were girls in 2022. This proportion has remained stable between 2018 and 2022. In countries such as Latvia and Poland, almost none of the boys expressed any interest in nursing. Some countries, such as Italy, Colombia, Slovenia and Spain, were slightly more successful in attracting the interest of young boys in nursing, although even in these countries less than 20% of those students expecting to work as nurses were boys. Becoming a nurse is particularly appealing to 15-year-old girls who scored lower in PISA academic assessments and come from lower socio-economic backgrounds based on earlier analysis of PISA 2018 data.

Figure 3.9. Share of 15-year-old girls and boys expecting to become nurses in OECD countries, 2022

{
  "table": {
    "columns": ["Country", "Girls (%)", "Boys (%)"],
    "rows": [
      {"Country": "Italy", "Girls": 18, "Boys": 3},
      {"Country": "Spain", "Girls": 17, "Boys": 3},
      {"Country": "Greece", "Girls": 15, "Boys": 3},
      {"Country": "Ireland", "Girls": 14, "Boys": 3},
      {"Country": "Portugal", "Girls": 13, "Boys": 3},
      {"Country": "Poland", "Girls": 10, "Boys": 0},
      {"Country": "Latvia", "Girls": 9, "Boys": 1},
      {"Country": "Colombia", "Girls": 18, "Boys": 3},
      {"Country": "Slovenia", "Girls": 13, "Boys": 2},
      {"Country": "Spain", "Girls": 14, "Boys": 3},
      {"Country": "United Kingdom", "Girls": 10, "Boys": 0},
      {"Country": "OECD Average", "Girls": 10, "Boys": 3},
      {"Country": "Czech Republic", "Girls": 8, "Boys": 3},
      {"Country": "Finland", "Girls": 10, "Boys": 0},
      {"Country": "Estonia", "Girls": 10, "Boys": 0},
      {"Country": "Norway", "Girls": 8, "Boys": 3},
      {"Country": "Denmark", "Girls": 7, "Boys": 3},
      {"Country": "Sweden", "Girls": 6, "Boys": 3},
      {"Country": "Netherlands", "Girls": 5, "Boys": 3},
      {"Country": "Belgium", "Girls": 5, "Boys": 3},
      {"Country": "Austria", "Girls": 5, "Boys": 3},
      {"Country": "Germany", "Girls": 5, "Boys": 3},
      {"Country": "Australia", "Girls": 5, "Boys": 3},
      {"Country": "Finland", "Girls": 5, "Boys": 3},
      {"Country": "Iceland", "Girls": 5, "Boys": 3},
      {"Country": "Switzerland", "Girls": 5, "Boys": 3},
      {"Country": "Malta", "Girls": 5, "Boys": 3},
      {"Country": "Japan", "Girls": 5, "Boys": 1},
      {"Country": "South Korea", "Girls": 5, "Boys": 1},
      {"Country": "United States", "Girls": 5, "Boys": 1}
    ]
  }
}
```
{
    "title": "Share of 15-year-old girls and boys expecting to become nurses in non-OECD countries, 2022",
    "data": [
        {"Country": "Canada", "Girls": 20, "Boys": 12},
        {"Country": "Turkey", "Girls": 22, "Boys": 10},
        {"Country": "Indonesia", "Girls": 15, "Boys": 9},
        {"Country": "Colombia", "Girls": 21, "Boys": 11},
        {"Country": "Saudi Arabia", "Girls": 16, "Boys": 6},
        {"Country": "Philippines", "Girls": 30, "Boys": 20},
        {"Country": "Mexico", "Girls": 25, "Boys": 15},
        {"Country": "Chile", "Girls": 24, "Boys": 14},
        {"Country": "Brazil", "Girls": 27, "Boys": 18},
        {"Country": "Argentina", "Girls": 34, "Boys": 29},
        {"Country": "Uruguay", "Girls": 50, "Boys": 35},
        {"Country": "Costa Rica", "Girls": 38, "Boys": 22},
        {"Country": "Republic of Moldova", "Girls": 33, "Boys": 16},
        {"Country": "North Macedonia", "Girls": 7, "Boys": 5},
        {"Country": "Dominican Republic", "Girls": 15, "Boys": 8},
        {"Country": "Peru", "Girls": 12, "Boys": 5},
        {"Country": "Israel", "Girls": 56, "Boys": 30},
        {"Country": "Kazakhstan", "Girls": 39, "Boys": 21},
        {"Country": "Bulgaria", "Girls": 59, "Boys": 48},
        {"Country": "Albania", "Girls": 62, "Boys": 44},
        {"Country": "Kosovo", "Girls": 71, "Boys": 61}
    ]
}


## 4 Review of programme data on student applications and admissions in nursing education

This section reviews available data on the number of applications and admissions to nursing education based on programme data. As already noted, it focuses on nursing programmes only because of greater concerns of reduced interest in nursing and that any reduction in applications may result in lowering admission standards and a growing number of unfilled training positions.

The data on applications and admissions in nursing education programmes have been collected in two ways:

1. Online search of data by the OECD for a subgroup of OECD countries for which it was possible to collect data covering at least five years to monitor trends over time; and
2. Regular data reported by countries to WHO through the NHWA.

### 4.1 Results of online search of data for a subgroup of OECD countries

Data covering at least five years on admissions to nursing education programmes have been gathered through online search for about half of OECD countries (18 countries), while the availability of such trend data on applications is more limited with a coverage of only 9 OECD countries. Furthermore, the comparability of data across countries on applications is limited due to differences in application process systems and variations in data coverage of various nursing education programmes (see Section 2). 

In France, the number of applications rose by about 50% between 2019 and 2022, while the number of students admitted to nursing programmes increased by 12%. This sharp increase in applications is primarily linked to the use for the first time in 2019 of the application platform “Parcoursup” to apply to nursing education programmes, which facilitated applications to multiple programmes. Nevertheless, nursing was the most popular field of studies in the higher-education “Parcoursup” application system in France in 2021 and 2022 (Le Figaro, 2023).


*No tables or images were provided to convert.*
{
  "France": {
    "Applications": [270, 275, 268, 280, 300, 350, 360, 370],
    "Admissions": [30, 35, 45, 50, 55, 58]
  },
  "Ireland": {
    "Applications": [5, 6, 7, 5, 4],
    "Admissions": [3, 5, 4, 4]
  },
  "Italy": {
    "Applications": [50, 45, 30, 25],
    "Admissions": [10, 20, 15]
  },
  "Japan": {
    "Applications": [270, 250, 230, 220, 200, 180],
    "Admissions": [90, 85, 80, 75, 70]
  },
  "Norway": {
    "Applications": [15, 20, 18, 16, 15],
    "Admissions": [8, 10, 9, 11]
  },
  "Poland": {
    "Applications": [10, 12, 15, 20, 25],
    "Admissions": [5, 8, 10, 12]
  }
}


Japan has faced a reduction of 20% in the number of applications to nursing schools between 2019 and 2023. Admissions to nursing schools have been more stable, but still saw a decline of 3% between 2022 and 2023.

In Norway, application numbers were also declining before the pandemic and continued to decrease between 2020 and 2023, but this trend has reversed in 2024. In 2023, the country did not meet its target enrollment for nursing courses for the first time in a decade, leaving about 800 slots unfilled. On a more positive note, application and admission numbers have seen an increase in 2024, with more students choosing nursing as their first preferences of study compared to 2023. However, the numbers are still far from pre-pandemic levels, and around 300 slots remain unfilled again despite the increase in admissions.

By contrast, in Poland, the number of applications in nursing education programmes surged by more than 60% between 2019 and 2023, and admissions increased by 50%. This growth coincided with the introduction of a generous scholarship programme in 2019, offering up to around EUR 3,000 per year to attract more students. The more than 30% increase in the remuneration of nurses between 2018 and 2022 might also have helped to increase the attractiveness of the profession.

In Spain also, the number of applications in nursing increased greatly by 65% between 2019 and 2022, while the number of students admitted increased more modestly by 17% between 2019 and 2023. This increase coincided with a government measure in 2020 that expanded internship capacity for nurses by 35%. However, the government has not yet planned any measures to expand the capacity of nursing degree programmes, signalling persistent educational capacity constraints.

In the United Kingdom, both the number of applications and admissions to nursing programmes returned close to their pre-pandemic levels in 2022 and 2023, following a strong increase during the first two years of the COVID-19 pandemic. In 2022, nursing was the only major health profession to see a decline in university admissions compared to medicine, dentistry, and midwifery. The 2023 NHS Long-term Workforce Plan called for a significant expansion in the education and training of new nurses to nearly double current capacity, but the 10% decrease in first-year enrollments in 2023 sparks concerns about the future supply of domestic nursing graduates. In February 2024, the total number of applicants to nursing programmes was 10% lower than in February 2023, despite generous bursaries and recent funding to cover ancillary costs related to clinical placements. This decline has prompted calls for an emergency package of measures to counteract the waning interest among students in pursuing nursing studies.

In the United States, both student applications and admissions to entry-level Bachelor’s programmes in nursing had been increasing steadily over the past two decades up to 2022, but they experienced their first decline in 2022 despite increased funding for scholarship and loan forgiveness programmes. Applications fell by 4%, while admissions dropped by 1.4%. This was followed by a marginal increase in applications and admissions in 2023, but the numbers remained below their peak in 2021. Despite the downturn in applications, thousands of qualified applicants continue to be rejected from nursing schools due to faculty staff shortages and limited clinical training capacity. Recent measures have been taken to both attract more students in nursing and address the bottlenecks in nursing education and training capacity.
```
Box 4.1. The United States has taken steps to attract more students into nursing and tackle staff shortages in nursing faculties

Following the pandemic, the US Government allocated more than USD 1 billion under the American Rescue Plan and the Build Back Better Act in 2021 and 2022 to scholarship programs and loan forgiveness for nurses and other health professionals in exchange for a period of service in primary care settings. The number of scholarships provided through the Nurse Corps Programme also increased by four-fold supported by additional funding in 2021.

At the same time, funding was provided to remove the main barriers to admitting more qualified students in nursing schools in the United States, which relate mainly to a lack of clinical placements and educators. The Build Back Better Act earmarked USD 500 million in 2021 to increase the number of faculty and staff in underserved areas. This grant aimed to improve the retention of nursing faculty members and recruit more staff, placing particular emphasis on promoting the diversity of the educators. In 2022, the US Department of Labor also allocated USD 80 million to bolster educational capacity by training or upskilling current or former nurses to become nursing educators.

---

Figure 4.2 shows data for the nine OECD countries for which the OECD has only been able to collect data on admissions in nursing education programmes (not on student applications). Recent trends in student intakes following the pandemic among these countries are mixed.

1. **Australia**: The number of students admitted in nursing education programmes increased between 2011 and 2020, but then fell slightly in 2021 and 2022.
2. **Canada**: Following a period of stability between 2014 and 2019, the number of students admitted in nursing education programmes increased slightly in 2020 and remained stable in 2021 (no more recent data available).
3. **Belgium**: The increase in student admissions during the first year of the pandemic in 2020 did not last and admissions came back to their pre-pandemic level by 2022 (although the most recent data for 2021 and 2022 relate only to the Flemish region).
4. **Netherlands**: A decade-long upward trend in nursing student intakes reached a record high in 2021, but this was followed by a 14% drop in 2022. Some negative public perception of the working conditions of nurses during the pandemic seems to have reduced interest in nursing.
5. **Czechia**: The number of students admitted in nursing increased greatly in 2020 and 2021 and then stabilised in 2022 and 2023, but at a much higher level than before the pandemic.
6. **Germany**: The admission numbers also fluctuated during the pandemic, but they were at the same level in 2022 as in 2018. This lack of growth is raising concerns about future shortages to meet the needs of ageing populations.

Source: Campaign for Action (2022).


This text does not contain any tables or images that need conversion to JSON or plain text. If there are any specific tables or images you need to address, please provide those separately.
{
  "data": [
    {
      "country": "Netherlands",
      "years": [
        {"year": "2011-12", "value": 20000},
        {"year": "2012-13", "value": 20000},
        {"year": "2013-14", "value": 25000},
        {"year": "2014-15", "value": 20000},
        {"year": "2015-16", "value": 22000},
        {"year": "2016-17", "value": 24000},
        {"year": "2017-18", "value": 26000},
        {"year": "2018-19", "value": 27000},
        {"year": "2019-20", "value": 27000},
        {"year": "2020-21", "value": 28000},
        {"year": "2021-22", "value": 26000},
        {"year": "2022-23", "value": 26000}
      ]
    },
    {
      "country": "Portugal",
      "years": [
        {"year": "2015-16", "value": 1000},
        {"year": "2016-17", "value": 1500},
        {"year": "2017-18", "value": 2000},
        {"year": "2018-19", "value": 2000},
        {"year": "2019-20", "value": 2000},
        {"year": "2020-21", "value": 2500},
        {"year": "2021-22", "value": 2000},
        {"year": "2022-23", "value": 2000}
      ]
    },
    {
      "country": "Switzerland",
      "years": [
        {"year": "2013-14", "value": 1500},
        {"year": "2014-15", "value": 1500},
        {"year": "2015-16", "value": 1600},
        {"year": "2016-17", "value": 1700},
        {"year": "2017-18", "value": 1800},
        {"year": "2018-19", "value": 1900},
        {"year": "2019-20", "value": 2100},
        {"year": "2020-21", "value": 2200},
        {"year": "2021-22", "value": 2000},
        {"year": "2022-23", "value": 2000}
      ]
    }
  ]
}


In Israel, the number of new students admitted in nursing increased greatly in the first year of the pandemic, but then fell back to its pre-pandemic level in 2021 and 2022.

In Portugal, the pandemic had a similar positive effect on admissions in 2020, followed by a decline in 2021 and 2022. This resulted in only a slight increase of 4% compared to 2019. In Switzerland, an increase in the number of students admitted also occurred in 2021, but the numbers then dropped back to their pre-pandemic levels in 2022.

### 4.2. Gender differences in admissions to nursing schools

As expected, the vast majority of new students admitted to nursing programs remain female. On average across 11 OECD countries, 85% of students admitted to nursing schools in 2022 were females, reflecting traditional gender-related perceptions of nursing as a predominantly female profession. Germany and Belgium have a relatively higher share of male students, with 20% or more of first-year students being men. By contrast, in Ireland, Japan, and the United Kingdom, the proportion of male students was only around 10%. Despite recent efforts in the UK to attract more men into nursing, there is still a persistent stereotype regarding the profession.
{
  "title": "Share of female and male students admitted in nursing schools, 11 OECD countries, 2022",
  "data": [
    {
      "Country": "Germany",
      "Female": 26,
      "Male": 9
    },
    {
      "Country": "Belgium",
      "Female": 19,
      "Male": 11
    },
    {
      "Country": "Spain",
      "Female": 17,
      "Male": 12
    },
    {
      "Country": "Portugal",
      "Female": 16,
      "Male": 13
    },
    {
      "Country": "Switzerland",
      "Female": 16,
      "Male": 14
    },
    {
      "Country": "OECD11",
      "Female": 16,
      "Male": 15
    },
    {
      "Country": "France",
      "Female": 15,
      "Male": 15
    },
    {
      "Country": "Czechia",
      "Female": 14,
      "Male": 12
    },
    {
      "Country": "Poland",
      "Female": 13,
      "Male": 11
    },
    {
      "Country": "UK",
      "Female": 12,
      "Male": 9
    },
    {
      "Country": "Japan",
      "Female": 11,
      "Male": 9
    },
    {
      "Country": "Ireland",
      "Female": 9,
      "Male": 8
    }
  ],
  "note": "Belgium data refer to the French region and to the 2020/21 academic year.",
  "source": "Please see Annex C."
}
Here's the content converted to markdown, following your specified rules:


Box 4.2. The “We are the NHS” campaign in the United Kingdom aims to attract more males in nursing

Recruiting more males into nursing studies and careers is a particular challenge in all countries that requires dismantling the long-standing stereotype that views nursing as a low-status and poorly paid profession suited primarily for women. Some countries like the United Kingdom have tried to attract more males into nursing and other health occupations under broader public awareness campaigns to attract more people into health careers. The “We are the NHS” campaign, launched in 2018 and still in place, aims to attract more men into nursing by featuring male nurses in visual materials and sharing their real-life stories, and disseminating information about career opportunities. Following the campaign, male applications increased slightly in 2019 and 2020, but have stabilised since 2021. By comparison, female applications have fallen sharply in 2022 and 2023, although they remain several times higher than male applications. The short-term success of this campaign highlights the need for sustained and comprehensive approaches to tackle the long-standing stereotype that views nursing as suited primarily for women. 

Figure 4.4. Trends in the number of female and male applicants and admitted students in the United Kingdom, 2013/14 to 2023/24

json
{
  "data": [
    {
      "year": "2013/14",
      "male_admitted_students": 10000,
      "male_applicants": 60000,
      "female_applicants": 20000,
      "female_admitted_students": 50000
    },
    {
      "year": "2014/15",
      "male_admitted_students": 12000,
      "male_applicants": 70000,
      "female_applicants": 25000,
      "female_admitted_students": 55000
    },
    {
      "year": "2015/16",
      "male_admitted_students": 15000,
      "male_applicants": 75000,
      "female_applicants": 35000,
      "female_admitted_students": 60000
    },
    {
      "year": "2016/17",
      "male_admitted_students": 17000,
      "male_applicants": 80000,
      "female_applicants": 40000,
      "female_admitted_students": 65000
    },
    {
      "year": "2017/18",
      "male_admitted_students": 19000,
      "male_applicants": 85000,
      "female_applicants": 42000,
      "female_admitted_students": 68000
    },
    {
      "year": "2018/19",
      "male_admitted_students": 20000,
      "male_applicants": 90000,
      "female_applicants": 43000,
      "
Acknowledgements

The preparation of this report was led by the Organisation for Economic Co-operation and Development (OECD) with the support from the World Health Organization (WHO). The report was supported through the joint Working for Health Multi-Partner Trust Fund. The Working for Health (W4H) programme is a joint initiative between the OECD, WHO and International Labour Organization (ILO) to support countries and regions in optimising their investments in health workforce education and employment with the aim of strengthening health workforce capacity by 2030 (WHO, 2024(1)). As a component of the W4H, the Interagency Data Exchange (IADeX) specifically focuses on supporting the development of data-driven policies by improving measurement, tracking, and monitoring of health workforce education and supply capacity, thereby enabling more effective policy responses to workforce challenges.

The main authors of the report are Ekin Dagistan and Gaetan Lafortune from the OECD Health Division, with useful input from Mathieu Boniol, Khassoum Diallo, Lennah Etyang, Stephanie Rose Flores, Teena Kunjumen and Tapas Sadasivan Nair from the WHO Health Workforce Department.
```
## Table 4.1. Applications and enrolments in nursing education programme based on data reported by countries to WHO on the NHWA data platform

json
[
    {
        "Country": "Albania",
        "Latest year": 2019,
        "Applications": 10773,
        "Enrolments": 7859,
        "Applications per 10 000 population": 37.74,
        "Enrolments per 10 000 population": 27.53,
        "Application/Enrolment ratio": 1.4,
        "Data issues": ""
    },
    {
        "Country": "Antigua and Barbuda",
        "Latest year": 2019,
        "Applications": 72,
        "Enrolments": 62,
        "Applications per 10 000 population": 7.82,
        "Enrolments per 10 000 population": 6.73,
        "Application/Enrolment ratio": 1.2,
        "Data issues": ""
    },
    {
        "Country": "Bangladesh",
        "Latest year": 2022,
        "Applications": 111562,
        "Enrolments": 21676,
        "Applications per 10 000 population": 6.52,
        "Enrolments per 10 000 population": 1.27,
        "Application/Enrolment ratio": 5.1,
        "Data issues": ""
    },
    {
        "Country": "Barbados",
        "Latest year": 2023,
        "Applications": 206,
        "Enrolments": 66,
        "Applications per 10 000 population": 7.31,
        "Enrolments per 10 000 population": 2.34,
        "Application/Enrolment ratio": 3.1,
        "Data issues": ""
    },
    {
        "Country": "Belize",
        "Latest year": 2023,
        "Applications": 164,
        "Enrolments": 291,
        "Applications per 10 000 population": 3.99,
        "Enrolments per 10 000 population": 7.08,
        "Application/Enrolment ratio": 0.6,
        "Data issues": "Enrolments higher than applications"
    },
    {
        "Country": "Benin",
        "Latest year": 2022,
        "Applications": 217,
        "Enrolments": 423,
        "Applications per 10 000 population": 0.16,
        "Enrolments per 10 000 population": 0.32,
        "Application/Enrolment ratio": 0.5,
        "Data issues": "Enrolments higher than applications"
    },
    {
        "Country": "Botswana",
        "Latest year": 2020,
        "Applications": 470,
        "Enrolments": 380,
        "Applications per 10 000 population": 1.85,
        "Enrolments per 10 000 population": 1.49,
        "Application/Enrolment ratio": 1.2,
        "Data issues": ""
    },
    {
        "Country": "Brazil",
        "Latest year": 2019,
        "Applications": 1056778,
        "Enrolments": 138489,
        "Applications per 10 000 population": 49.88,
        "Enrolments per 10 000 population": 6.54,
        "Application/Enrolment ratio": 7.6,
        "Data issues": ""
    },
    {
        "Country": "Burkina Faso",
        "Latest year": 2023,
        "Applications": 112088,
        "Enrolments": 1312,
        "Applications per 10 000 population": 48.21,
        "Enrolments per 10 000 population": 0.56,
        "Application/Enrolment ratio": 85.4,
        "Data issues": "Substantial decrease between 2022-23"
    },
    {
        "Country": "Cameroon",
        "Latest year": 2022,
        "Applications": 743,
        "Enrolments": 170,
        "Applications per 10 000 population": 0.27,
        "Enrolments per 10 000 population": 0.06,
        "Application/Enrolment ratio": 4.5,
        "Data issues": "Substantial decrease between 2021-22"
    },
    {
        "Country": "Canada",
        "Latest year": 2017,
        "Applications": 16942,
        "Enrolments": 51734,
        "Applications per 10 000 population": 4.64,
        "Enrolments per 10 000 population": 14.16,
        "Application/Enrolment ratio": 0.3,
        "Data issues": "Enrolments higher than applications"
    },
    {
        "Country": "Chad",
        "Latest year": 2023,
        "Applications": 9908,
        "Enrolments": 2231,
        "Applications per 10 000 population": 5.42,
        "Enrolments per 10 000 population": 1.22,
        "Application/Enrolment ratio": 4.4,
        "Data issues": ""
    },
    {
        "Country": "Colombia",
        "Latest year": 2021,
        "Applications": 21852,
        "Enrolments": 6028,
        "Applications per 10 000 population": 4.24,
        "Enrolments per 10 000 population": 1.17,
        "Application/Enrolment ratio": 3.6,
        "Data issues": ""
    },
    {
        "Country": "Cuba",
        "Latest year": 2018,
        "Applications": 4775,
        "Enrolments": 7958,
        "Applications per 10 000 population": 4.22,
        "Enrolments per 10 000 population": 7.02,
        "Application/Enrolment ratio": 0.6,
        "Data issues": "Enrolments higher than applications"
    },
    {
        "Country": "Czechia",
        "Latest year": 2019,
        "Applications": 1400,
        "Enrolments": 2355,
        "Applications per 10 000 population": 1.31,
        "Enrolments per 10 000 population": 2.21,
        "Application/Enrolment ratio": 0.6,
        "Data issues": "Enrolments higher than applications"
    },
    {
        "Country": "Estonia",
        "Latest year": 2023,
        "Applications": 1800,
        "Enrolments": 729,
        "Applications per 10 000 population": 13.18,
        "Enrolments per 10 000 population": 5.34,
        "Application/Enrolment ratio": 2.5,
        "Data issues": ""
    },
    {
        "Country": "Eswatini",
        "Latest year": 2022,
        "Applications": 3170,
        "Enrolments": 120,
        "Applications per 10 000 population": 26.38,
        "Enrolments per 10 000 population": 1.00,
        "Application/Enrolment ratio": 26.4,
        "Data issues": "Same enrolment figures reported in 2021 & 2022"
    },
    {
        "Country": "Gambia",
        "Latest year": 2019,
        "Applications": 498,
        "Enrolments": 259,
        "Applications per 10 000 population": 1.98,
        "Enrolments per 10 000 population": 1.03,
        "Application/Enrolment ratio": 1.9,
        "Data issues": ""
    },
    {
        "Country": "Ghana",
        "Latest year": 2018,
        "Applications": 25119,
        "Enrolments": 13078,
        "Applications per 10 000 population": 8.14,
        "Enrolments per 10 000 population": 4.24,
        "Application/Enrolment ratio": 1.9,
        "Data issues": ""
    },
    {
        "Country": "Guatemala",
        "Latest year": 2023,
        "Applications": 1428,
        "Enrolments": 1074,
        "Applications per 10 000 population": 0.81,
        "Enrolments per 10 000 population": 0.61,
        "Application/Enrolment ratio": 1.3,
        "Data issues": ""
    },
    {
        "Country": "Honduras",
        "Latest year": 2023,
        "Applications": 661,
        "Enrolments": 661,
        "Applications per 10 000 population": 0.62,
        "Enrolments per 10 000 population": 0.62,
        "Application/Enrolment ratio": 1.0,
        "Data issues": "Same figures for applications and enrolments"
    },
    {
        "Country": "Iceland",
        "Latest year": 2018,
        "Applications": 408,
        "Enrolments": 627,
        "Applications per 10 000 population": 11.57,
        "Enrolments per 10 000 population": 17.78,
        "Application/Enrolment ratio": 0.7,
        "Data issues": "Enrolments higher than applications"
    },
    {
        "Country": "Indonesia",
        "Latest year": 2022,
        "Applications": 260310,
        "Enrolments": 29754,
        "Applications per 10 000 population": 9.45,
        "Enrolments per 10 000 population": 1.08,
        "Application/Enrolment ratio": 8.8,
        "Data issues": ""
    },
    {
        "Country": "Iran",
        "Latest year": 2023,
        "Applications": 45000,
        "Enrolments": 15000,
        "Applications per 10 000 population": 5.05,
        "Enrolments per 10 000 population": 1.68,
        "Application/Enrolment ratio": 3.0,
        "Data issues": ""
    },
    {
        "Country": "Ireland",
        "Latest year": 2018,
        "Applications": 9626,
        "Enrolments": 1823,
        "Applications per 10 000 population": 19.78,
        "Enrolments per 10 000 population": 3.75,
        "Application/Enrolment ratio": 5.3,
        "Data issues": ""
    },
    {
        "Country": "Jordan",
        "Latest year": 2018,
        "Applications": 7206,
        "Enrolments": 2059,
        "Applications per 10 000 population": 6.89,
        "Enrolments per 10 000 population": 1.97,
        "Application/Enrolment ratio": 3.5,
        "Data issues": ""
    },
    {
        "Country": "Kenya",
        "Latest year": 2017,
        "Applications": 7934,
        "Enrolments": 7125,
        "Applications per 10 000 population": 1.62,
        "Enrolments per 10 000 population": 1.46,
        "Application/Enrolment ratio": 1.1,
        "Data issues": ""
    },
    {
        "Country": "Lao PDR",
        "Latest year": 2019,
        "Applications": 2100,
        "Enrolments": 449,
        "Applications per 10 000 population": 2.91,
        "Enrolments per 10 000 population": 0.62,
        "Application/Enrolment ratio": 4.7,
        "Data issues": ""
    },
    {
        "Country": "Madagascar",
        "Latest year": 2018,
        "Applications": 674,
        "Enrolments": 423,
        "Applications per 10 000 population": 0.25,
        "Enrolments per 10 000 population": 0.16,
        "Application/Enrolment ratio": 1.6,
        "Data issues": ""
    },
    {
        "Country": "Mexico",
        "Latest year": 2018,
        "Applications": 13417,
        "Enrolments": 7254,
        "Applications per 10 000 population": 1.08,
        "Enrolments per 10 000 population": 0.58,
        "Application/Enrolment ratio": 1.9,
        "Data issues": ""
    },
    {
        "Country": "Montenegro",
        "Latest year": 2023,
        "Applications": 90,
        "Enrolments": 51,
        "Applications per 10 000 population": 1.46,
        "Enrolments per 10 000 population": 0.83,
        "Application/Enrolment ratio": 1.8,
        "Data issues": ""
    },
    {
        "Country": "Morocco",
        "Latest year": 2023,
        "Applications": 4570,
        "Enrolments": 4741,
        "Applications per 10 000 population": 1.21,
        "Enrolments per 10 000 population": 1.25,
        "Application/Enrolment ratio": 1.0,
        "Data issues": "Enrolments higher than applications"
    },
    {
        "Country": "Mozambique",
        "Latest year": 2021,
        "Applications": 5133,
        "Enrolments": 100,
        "Applications per 10 000 population": 1.60,
        "Enrolments per 10 000 population": 0.03,
        "Application/Enrolment ratio": 53.3,
        "Data issues": ""
    },
    {
        "Country": "Myanmar",
        "Latest year": 2022,
        "Applications": 530,
        "Enrolments": 478,
        "Applications per 10 000 population": 0.10,
        "Enrolments per 10 000 population": 0.09,
        "Application/Enrolment ratio": 1.1,
        "Data issues": ""
    }
]
```
```
| Country                    | Latest year | Applications | Enrolments | Applications per 10,000 population | Enrolments per 10,000 population | Application/Enrolment ratio | Data issues                                   |
|---------------------------|-------------|--------------|------------|--------------------------------------|-----------------------------------|------------------------------|-----------------------------------------------|
| Namibia                   | 2018        | 737          | 737        | 3.06                                 | 3.06                              | 1.0                         | Same figures for applications and enrolments |
| Norway                    | 2023        | 8,929        | 14,469     | 16.18                                | 26.21                             | 0.6                         | Enrolments higher than applications           |
| Papua New Guinea          | 2023        | 1,200        | 1,115      | 1.16                                 | 1.08                              | 1.1                         | Round numbers on applications                 |
| Paraguay                  | 2018        | 1,046        | 2,460      | 1.62                                 | 3.82                              | 0.4                         | Enrolments higher than applications           |
| Saint Lucia               | 2023        | 110          | 110        | 6.10                                 | 6.10                              | 1.0                         | Same figures for applications and enrolments |
| St Vincent and Grenadines | 2018        | 100          | 123        | 9.50                                 | 11.68                             | 0.8                         | Enrolments higher than applications           |
| Senegal                   | 2019        | 3,082        | 75         | 1.93                                 | 0.05                              | 38.6                        |                                                  |
| Sierra Leone              | 2018        | 485          | 485        | 0.62                                 | 0.62                              | 1.0                         |                                                  |
| Slovak Republic           | 2022        | 2,068        | 1,169      | 3.81                                 | 2.15                              | 1.8                         |                                                  |
| Slovenia                  | 2019        | 1,304        | 788        | 6.24                                 | 3.77                              | 1.7                         |                                                  |
| Spain                     | 2023        | 43,871       | 15,447     | 9.07                                 | 3.19                              | 2.8                         |                                                  |
| Sri Lanka                 | 2023        | 9,000        | 3,100      | 4.08                                 | 1.41                              | 2.9                         | Round number for applications                 |
| Sweden                    | 2023        | 16,642       | 5,822      | 15.79                                | 5.53                              | 2.9                         |                                                  |
| Trinidad and Tobago       | 2018        | 811          | 1,644      | 5.39                                 | 10.93                             | 0.5                         | Enrolments higher than applications           |
| Türkiye                   | 2021        | 16,032       | 16,232     | 1.91                                 | 1.93                              | 1.0                         | Enrolments higher than applications           |
| United Arab Emirates      | 2019        | 719          | 2,039      | 0.78                                 | 2.21                              | 0.4                         | Enrolments higher than applications           |
| Uruguay                   | 2022        | 1,812        | 1,812      | 5.29                                 | 5.29                              | 1.0                         | Same data applications and admissions         |



### Note
It is important to note that countries are not required to report on all NHWA indicators on an annual basis. They can set their own pace for the progressive implementation of the NHWA and decide which indicators they wish to report on. They may therefore prioritise reporting indicators that are included in global monitoring mechanisms (such as health workforce density and gender distribution), which can explain the variation in reporting by countries on different indicators. The inclusion of health workforce training indicators in the monitoring and evaluation frameworks of global health and care workforce initiatives could potentially improve international reporting on these indicators and also lead to national efforts to improve reporting systems and the quality of data on health workforce training.
```
# Conclusion

Recent OECD and WHO work has highlighted the urgent need for new investments to bolster the number of frontline health workers to effectively achieve universal health coverage (UHC), respond to growing healthcare needs arising from population ageing, and be better prepared to respond to any future public health crisis and shocks (OECD, 2023; WHO, 2022). The COVID-19 pandemic highlighted clearly that the most important factor for a well-functioning health system is a robust, well-trained and dedicated health workforce, but it also highlighted how demanding the working conditions in hospitals and other parts of the health system can be. Increasing health workforce education and training capacity to produce new doctors, nurses and other skilled health workers is one of the main policy levers to increase the supply of health workers and address any current or future shortages, and many countries have recognised this and have taken steps to increase the number of students in medical, nursing and other education programmes. However, expanding educational capacity will prove ineffective if there is not a sufficient pool of qualified and motivated candidates to fill these positions. Preventing future health workforce shortages will depend crucially on enhancing the attractiveness of health sector jobs among young people by finding effective approaches to address critical factors affecting young people’s interest in health careers.

This report has reviewed the available data on young people's interest in health careers at two points in their education pathways based on two different data sources: 1) the data on the career aspirations of 15-year-old students based on the OECD PISA survey; and 2) the administrative (programme) data on applications and admissions (enrolments) in various health education programmes based on an ad hoc online search by the OECD for a subgroup of OECD countries and annual reporting by countries to WHO through the NHWA data platform, focussing in particular on nursing education programmes.

An important advantage of the PISA survey is that it is a well-established survey that is carried out regularly (usually every three years) in around 80 countries around the world. The sample size of students responding to the survey is large, ranging from about 1,500 students in some of the small population countries to over 20,000 students in some of the larger population countries for the last wave in 2022. One of the main findings from the last wave of the PISA 2022 survey is that interest in health careers has reduced in several countries following the pandemic (in about half of OECD countries and a smaller but non-negligible number of non-OECD countries). Another key finding from the PISA survey is that there are huge gender differences in interest among 15-year-old students in working in the health sector, with health sector jobs generally appealing much more to girls than boys. This has traditionally been the case in nursing, but also increasingly in medicine. On average across OECD countries, 72% of 15-year-old students aspiring to become as doctors were girls in 2022, up from 69% in the PISA 2015 survey. This is also the case in most non-OECD countries and economies where girls represent at least two-thirds of students expressing interest in becoming doctors. When it comes to nursing, this proportion reaches over 85% in most OECD and non-OECD countries and economies. A persisting major challenge in most countries is to attract more males to nursing. The next wave of the PISA survey, to be carried out in 2025, will provide new evidence to assess whether the worrying trend of reduced interest in health careers in several countries and the large gender gaps in interest in health careers persist or whether the situation may be improving in some countries.

This report also reviewed the availability, quality and comparability of data on applications and admissions in health education programmes, focusing on nursing education programmes given the particular


concerns about low and reduced interest in nursing in several countries. One advantage of data on applications to nursing education programmes is that they can provide more concrete evidence of interest in pursuing studies and careers of students at an older age when they complete secondary education. Based on the ad hoc online research carried out by the OECD, data on admissions to nursing education programmes were more readily available than data on applications. This suggests that greater efforts at the national level to link data on applications and admissions could improve data availability, consistency and usability. For some countries (e.g. France), there are important breaks in time series limiting any trends analysis due to major changes in the application process. In the limited number of OECD countries for which consistent trend data are available, the data generally show that a notable increase in applications during the first two years of the pandemic in 2020 and 2021 in several countries, but this was followed by a subsequent decline in 2022 and 2023 in at least some of these countries. However, the availability and comparability of these data is affected by the specific application process to postsecondary education programmes in different countries and discrepancies in the definition of "application".

Very limited time series are available from the NHWA as it stands now for both OECD and non-OECD countries, thereby restricting any trends analysis. The review of the available data (as of September 2024) indicates huge cross-country variations and some apparent data inconsistencies between the data on applications and enrolments for about one-quarter of countries (i.e. the data on enrolments is greater or equal to the data on applications). Part of this inconsistency may be to a misinterpretation of the term “enrolment” in some countries, which might be interpreted as students enrolled in all years of the study programme instead of only first-year students. While NHWA does not require countries to report on education indicators, their integration into the monitoring and evaluation frameworks of global health and care workforce initiatives could improve data reporting systems and quality.

Further research and developmental (R&D) would be required by the OECD and WHO in co-operation with countries to improve the availability, interpretability and comparability of data on applications and admissions to nursing education programmes before such data and indicators can be used to monitor trends in students' interest in nursing and increased national efforts in actually training more nurses among a large number of OECD and non-OECD countries. Until such R&D work is completed, the current OECD and WHO data collections on the number of graduates from nursing, medicine and other health-related programmes will remain the most reliable indicator to monitor national training efforts.


Since 2010, data on medical and nursing graduates (as well as graduates from other health education programmes) have been collected across OECD and other European countries through the annual OECD/Eurostat/WHO-Europe Joint Questionnaire, and more recently WHO-Headquarters has also started to collect these data from other countries in parts of the world.

Table A.1 shows some of the results from the 2024 OECD data collection on medical graduates in OECD countries, focusing on trends between 2015 and 2022. In most OECD countries, the number of new medical graduates has increased by more than 10% over the 2015-22 period. Several countries experienced substantial increases: the numbers have more than doubled in Türkiye (110%), followed by France (63%), Latvia (62%), Poland (43%) and Mexico (41%). The growth was less than 10% only in Korea (1%), Canada and Portugal (2%), the United Kingdom (3%), Spain (5%) and Australia (8%). There was a noticeable decline in the number of medical graduates in one country only, Norway (14%). The number of students admitted in medical schools in Norway has only recently increased following a long period of stability. For a long time, Norway has been able to rely on a large number of Norwegian students going abroad to get their first medical degree before coming back home, but in 2019 the Norwegian Government endorsed the objective of increasing substantially the number of places in Norwegian medical schools to increase the proportion of domestically trained doctors, so the number of graduates should increase in the coming years.

### Table A.1: Number of medical graduates in OECD countries based on OECD data collection, 2015-22

json
[
    {
        "Country": "Australia",
        "2015": 3751,
        "2016": 3858,
        "2017": 3800,
        "2018": 3958,
        "2019": 4022,
        "2020": 3839,
        "2021": 3945,
        "2022": 4068,
        "Growth rate 2015-22": "8%"
    },
    {
        "Country": "Austria",
        "2015": 1255,
        "2016": 1218,
        "2017": 1248,
        "2018": 1346,
        "2019": 1242,
        "2020": 1455,
        "2021": 1466,
        "2022": null,
        "Growth rate 2015-22": "17%"
    },
    {
        "Country": "Belgium",
        "2015": 1359,
        "2016": 1614,
        "2017": 1684,
        "2018": 3221,
        "2019": 2020,
        "2020": 1917,
        "2021": 1988,
        "2022": 1833,
        "Growth rate 2015-22": "35%"
    },
    {
        "Country": "Canada",
        "2015": 2813,
        "2016": 2847,
        "2017": 2811,
        "2018": 2863,
        "2019": 2856,
        "2020": 2876,
        "2021": 2861,
        "2022": null,
        "Growth rate 2015-22": "2%"
    },
    {
        "Country": "Colombia",
        "2015": 4830,
        "2016": 5145,
        "2017": 5748,
        "2018": 6429,
        "2019": 6319,
        "2020": 5955,
        "2021": null,
        "2022": null,
        "Growth rate 2015-22": "23%"
    },
    {
        "Country": "Czechia",
        "2015": 1430,
        "2016": 1596,
        "2017": 1815,
        "2018": 1700,
        "2019": 1718,
        "2020": 1771,
        "2021": 1790,
        "2022": 1766,
        "Growth rate 2015-22": "23%"
    },
    {
        "Country": "Denmark",
        "2015": 969,
        "2016": 1230,
        "2017": 1281,
        "2018": 1335,
        "2019": 1234,
        "2020": 1264,
        "2021": null,
        "2022": null,
        "Growth rate 2015-22": "31%"
    },
    {
        "Country": "Estonia",
        "2015": 133,
        "2016": 145,
        "2017": 151,
        "2018": 136,
        "2019": 138,
        "2020": 157,
        "2021": 164,
        "2022": null,
        "Growth rate 2015-22": "23%"
    },
    {
        "Country": "Finland",
        "2015": 625,
        "2016": 634,
        "2017": 645,
        "2018": 657,
        "2019": 674,
        "2020": 702,
        "2021": 729,
        "2022": null,
        "Growth rate 2015-22": "17%"
    },
    {
        "Country": "France",
        "2015": 625,
        "2016": 631,
        "2017": 752,
        "2018": 768,
        "2019": 689,
        "2020": 795,
        "2021": null,
        "2022": null,
        "Growth rate 2015-22": "63%"
    },
    {
        "Country": "Germany",
        "2015": 9215,
        "2016": 9474,
        "2017": 928,
        "2018": 9563,
        "2019": 10324,
        "2020": 10019,
        "2021": 10320,
        "2022": 10377,
        "Growth rate 2015-22": "13%"
    },
    {
        "Country": "Greece",
        "2015": 1162,
        "2016": 1017,
        "2017": 1334,
        "2018": 1449,
        "2019": 1465,
        "2020": 1403,
        "2021": null,
        "2022": null,
        "Growth rate 2015-22": "21%"
    },
    {
        "Country": "Hungary",
        "2015": 1319,
        "2016": 1388,
        "2017": 1410,
        "2018": 1560,
        "2019": 1532,
        "2020": 1574,
        "2021": 1629,
        "2022": null,
        "Growth rate 2015-22": "24%"
    },
    {
        "Country": "Iceland",
        "2015": 42,
        "2016": 53,
        "2017": 50,
        "2018": 48,
        "2019": 41,
        "2020": 49,
        "2021": 51,
        "2022": null,
        "Growth rate 2015-22": "21%"
    }
]
```
```
| Country         | 2015  | 2016  | 2017  | 2018  | 2019  | 2020  | 2021  | 2022  | Growth rate 2015-22 (or nearest year) |
|------------------|-------|-------|-------|-------|-------|-------|-------|-------|------------------------------------------|
| Ireland          | 1,107 | 1,162 | 1,196 | 1,254 | 1,225 | 1,268 | 1,310 | 1,325 | 20%                                      |
| Israel           | 458   | 578   | 601   | 658   | 654   | 639   | 637   | 690   | 51%                                      |
| Italy            | 7,500 | 8,032 | 9,120 | 10,129| 11,213| 10,788| 9,827 | 9,795 | 31%                                      |
| Japan            | 8,118 | 8,529 | 8,673 | 8,751 | 9,003 | 8,757 | 9,013 | 9,095 | 12%                                      |
| Korea            | 3,861 | 3,886 | 3,898 | 3,860 | 3,827 | 3,757 | 3,910 | 1%    |                                          |
| Latvia           | 320   | 320   | 337   | 428   | 450   | 454   | 515   | 517   | 62%                                      |
| Lithuania       | 476   | 462   | 545   | 554   | 552   | 571   | 571   | 601   | 26%                                      |
| Mexico           | 13,334| 15,328| 16,586| 15,346| 17,408| 18,389| 19,327| 18,819| 41%                                      |
| Netherlands      | 2,480 | 2,610 | 2,730 | 2,720 | 2,620 | 2,500 | 2,710 | 2,490 | 0.4%                                     |
| New Zealand      | 399   | 444   | 437   | 474   | 493   | 528   | 543   | 533   | 34%                                      |
| Norway           | 580   | 580   | 586   | 542   | 606   | 587   | 555   | 549   | -14%                                     |
| Poland           | 3,888 | 3,963 | 4,157 | 4,006 | 4,546 | 4,638 | 5,067 | 5,558 | 43%                                      |
| Portugal         | 1,642 | 1,698 | 1,657 | 1,760 | 1,629 | 1,619 | 1,682 | 1,670 | 2%                                       |
| Slovak Republic   | 848   | 871   | 918   | 962   | 984   | 1,044 | 1,039 | 1,039 | 23%                                      |
| Slovenia         | -     | -     | -     | -     | -     | -     | -     | 274   | 240                                      |
| Spain            | 6,053 | 6,286 | 6,749 | 6,664 | 6,574 | 6,600 | 6,718 | 6,326 | 5%                                       |
| Sweden           | 1,216 | 1,189 | 1,281 | 1,334 | 1,385 | 1,405 | 1,474 | 1,457 | 20%                                      |
| Switzerland      | 894   | 885   | 946   | 995   | 1,017 | 1,115 | 1,089 | 1,164 | 30%                                      |
| Türkiye          | 6,896 | 7,561 | 8,530 | 9,395 | 10,854| 11,939| 14,506| -     | 110%                                     |
| United Kingdom    | 8,860 | 8,490 | 8,590 | 8,570 | 8,730 | 8,750 | 8,835 | 9,140 | 3%                                       |
| United States    | 24,026| 24,415| 25,277| 25,978| 26,640| 27,328| 28,337| 28,758| 20%                                      |


The availability of time series on medical graduates for non-OECD countries reported under the WHO NHWA platform is more limited. According to the available data, the number of medical graduates also increased substantially in several countries between 2015 and 2022 (or nearest years). However, a few countries also report substantial reductions (Belarus, Serbia, and Cameroon).
| Country                | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | Growth rate 2015-22 (or nearest years) |
|-----------------------|------|------|------|------|------|------|------|------|---------------------------------------|
| Albania               | 397  |      |      |      |      |      |      |      |                                       |
| Armenia               | 748  | 591  | 620  | 839  |      |      |      |      |                                       |
| Belarus               | 2,767| 2,431| 2,252| 2,298| 2,277| 2,480|      |      | -10%                                 |
| Benin                 | 138  |      |      |      |      |      |      |      |                                       |
| Bhutan                | 17   | 14   | 25   | 39   |      |      |      |      | 47%                                   |
| Bosnia and Herzegovina| 416  | 360  |      |      |      |      |      |      |                                       |
| Botswana              | 47   | 47   | 50   | 40   | 43   | 56   |      |      | 19%                                   |
| Bulgaria              | 837  | 859  | 1,052| 1,102| 1,350| 1,414| 1,564|      | 87%                                   |
| Burkina Faso          | 225  |      |      | 404  | 411  |      |      |      |                                       |
| Cambodia              |      |      | 567  |      |      |      |      |      |                                       |
| Cameroon              | 466  | 739  | 843  | 615  | 622  | 89   | 200  | 207  | -56%                                  |
| Chad                  |      | 171  |      | 108  | 240  |      |      |      |                                       |
| Croatia               | 513  | 607  | 579  | 627  | 689  | 677  | 654  |      | 27%                                   |
| Cyprus                |      |      |      |      |      |      |      | 45   |                                       |
| Dominican Republic     |      |      |      | 3,612|      |      |      |      |                                       |
| El Salvador           |      | 305  |      |      |      |      |      |      |                                       |
| Ethiopia              | 1,376|      |      |      |      |      |      |      |                                       |
| India                 | 80,312|84,649|      |      |      |      |      |      |                                       |
| Indonesia             | 9,368| 6,003| 10,645|     |      |      |      |      |                                       |
| Iran                  | 4,254| 4,254|      |      |      |      |      |      |                                       |
| Kazakhstan           | 5,228| 5,831| 5,649| 5,459| 5,472| 7,909|      |      | 51%                                   |
| Kenya                | 520  |      |      |      |      |      |      |      |                                       |
| Kyrgyzstan           | 1,600| 1,742| 2,532| 2,838| 3,471|      |      |      | 117%                                  |
| Lao PDR              | 94   |      |      |      |      |      |      |      |                                       |
| Madagascar           | 155  |      |      |      |      |      |      |      |                                       |
| Malawi               | 63   | 65   |      |      |      |      |      |      | 3%                                    |
| Malta                | 103  | 154  | 164  | 169  | 134  |      |      |      | 30%                                   |
| Mozambique           | 200  |      |      |      |      |      |      |      |                                       |
| Myanmar              |      |      | 23   |      |      |      |      |      |                                       |
| Nigeria              | 153  | 144  | 173  | 273  | 258  | 2,909| 1,041|      | 69%                                   |
| Panama               | 123  | 211  |      |      |      |      |      |      |                                       |
| Philippines          |      |      | 4,139|      |      |      |      |      |                                       |
| Republic of Moldova   |      | 632  |      | 783  |      |      |      |      |                                       |
| Romania              | 3,892| 4,368| 4,610| 5,076| 4,967| 5,067| 5,006|      | 29%                                   |
| Rwanda               | 91   |      |      |      |      |      |      |      |                                       |
| Saudi Arabia         | 282  |      |      |      |      |      |      |      |                                       |
| Serbia               | 1,455| 1,304| 1,231| 1,317| 1,149| 237  |      |      | -21%                                  |
| Sierra Leone         |      |      |      |      |      |      |      | 237  |                                       |
| Sri Lanka            | 1,150| 1,200|      |      |      |      |      |      |                                       |
| Timor-Leste          | 52   | 30   | 65   |      |      |      |      |      |                                       |
| Turkmenistan         | 269  | 257  | 289  | 363  | 400  | 412  | 455  |      | 69%                                   |
| United Arab Emirates   | 399  | 419  | 503  |      |      |      |      |      |                                       |
| Uruguay              | 32   | 91   |      |      |      |      |      |      |                                       |
| Zambia               | 32   |      |      |      |      |      |      |      |                                       |
| Zimbabwe             | 91   |      |      |      |      |      |      |      |                                       |

**Note:** The numbers shown in this table correspond to "general medical practitioner" graduates according to the NHWA methodology. Growth rates were calculated only for countries with at least a five-year span between data points. Source: WHO NHWA data platform (September 2024).
```
Table A.3. Number of nursing graduates in OECD countries based on OECD data collection, 2015-22

| Country         | 2015   | 2016   | 2017   | 2018   | 2019   | 2020   | 2021   | 2022   | Growth rate 2015-22 (or nearest year) |
|------------------|--------|--------|--------|--------|--------|--------|--------|--------|---------------------------------------|
| Australia        | 18,291 | 19,835 | 20,798 | 23,994 | 27,620 | 27,717 | 29,725 | 31,461 | 72%                                   |
| Austria          | 2,744  | 3,010  | 2,842  | 3,364  | 3,518  | 3,737  | 2,913  | 4,110  | 6%                                    |
| Belgium          | 5,601  | 6,236  | 6,473  | 7,203  | 3,569  | 5,194  | 5,423  | 5,376  | -4%                                   |
| Canada           | 20,964 | 20,967 | 19,262 |        |        |        |        |        |                                       |
| Chile            | 3,875  | 4,537  | 5,314  | 5,570  | 5,950  | 5,516  | 2,531  | 7,265  | 42%                                   |
| Colombia         | 4,073  | 3,929  | 3,971  | 3,821  | 3,864  | 4,097  |        |        | 1%                                    |
| Czechia          | 1,665  | 1,714  | 3,079  | 2,938  | 3,065  | 3,102  | 3,925  | 3,731  | 21%                                   |
| Denmark          | 2,574  | 2,524  | 2,559  | 2,589  | 2,565  | 2,640  | 2,679  |        | 8%                                    |
| Estonia          | 430    | 425    | 468    | 389    | 383    | 367    | 363    | 401    | -7%                                   |
| Finland          | 3,804  | 3,803  | 4,256  | 4,206  | 4,150  | 3,745  | 3,958  | 3,723  | -3%                                   |
| France           | 25,888 | 26,111 | 26,065 | 25,757 | 25,358 | 25,558 | 24,567 | 24,379 | -3%                                   |
| Germany          | 35,941 | 38,221 | 36,939 | 35,742 | 36,398 | 35,860 | 36,756 | 37,165 | 3%                                    |
| Greece           | 3,715  | 3,778  | 7,181  | 4,830  | 6,187  | 10,591 |        |        | 45%                                   |
| Hungary          | 4,318  | 4,044  | 4,305  | 4,340  | 4,123  | 4,934  | 3,527  | 2,348  | -6%                                   |
| Iceland          | 239    | 220    | 253    | 194    | 215    | 219    | 268    | 1,665  | 23%                                   |
| Israel           | 1,592  | 1,791  | 2,107  | 2,127  | 2,404  | 2,682  | 3,098  | 2,859  | 80%                                   |
| Italy            | 12,563 | 12,117 | 11,205 | 11,105 | 10,227 | 10,191 | 11,639 | 9,639  | -19%                                   |
| Japan            | 64,722 | 65,365 | 65,269 | 66,382 | 65,920 | 64,643 | 66,195 | 65,061 | 1%                                    |
| Korea            | 52,489 | 57,260 | 51,302 | 53,107 | 51,848 | 54,124 | 54,429 | 55,091 | 5%                                    |
| Latvia           | 545    | 392    | 534    | 515    | 514    | 567    | 509    | 311    | 43%                                   |
| Lithuania       | 73     | 65     | 72     | 70     | 82     | 78     | 84     | 68     | 4%                                    |
| Luxembourg       | 14,598 | 19,133 | 17,881 | 19,850 | 22,129 | 19,831 | 21,987 | 24,467 | 24%                                   |
| Mexico          | 7,060  | 7,370  | 9,040  | 9,160  | 10,460 | 11,010 | 10,990 |        | 56%                                   |
| Netherlands     | 2,112  | 2,166  | 2,176  | 2,084  | 1,985  | 2,082  | 2,210  | 2,405  | 14%                                   |
| New Zealand      | 3,811  | 3,983  | 2,411  | 2,575  | 4,269  | 4,059  | 4,282  | 2,182  | 12%                                   |
| Norway           | 8,902  | 4,147  | 4,463  | 5,375  | 5,419  | 5,250  | 5,769  | 7,406  | -17%                                   |
| Portugal         | 2,716  | 2,528  | 2,522  | 2,580  | 2,732  | 2,667  | 2,873  | 2,711  | 0.0%                                   |
| Slovak Republic   | 1,853  | 1,622  | 1,684  | 1,440  | 1,194  | 1,007  | 1,322  | 3,641  | -28%                                   |
| Slovenia         | 10,760 | 10,578 | 10,115 | 9,936  | 10,250 | 10,587 | 10,691 | 11,168 | 41%                                   |
| Spain            | 3,871  | 4,128  | 4,172  | 4,337  | 4,443  | 4,502  | 4,896  | 4,226  | 14%                                   |
| Switzerland      | 7,918  | 8,225  | 8,526  | 9,039  | 9,269  | 9,663  | 9,802  | 9,814  | 24%                                   |
| Turkey           | 30,205 | 57,045 | 15,134  | 15,754 | 15,414 | 15,273 | 15,562 |        | 39%                                   |
| United Kingdom    | 33,265 | 31,045 | 30,595 | 31,610 | 29,905 | 28,490 | 28,245 | 29,080 | -6%                                    |
| United States    | 202,345 | 199,710 | 201,206 | 215,236 | 216,045 | 220,841 | 225,088 |        | 11%                                   |

Note: 1. Break in time series. If necessary, growth rates have been adjusted to take account of breaks in series (e.g. in Chile, the growth rate has been calculated from 2015 to 2020 to avoid the major break in the series in 2021).
Source: OECD Health Statistics 2024.
```
The time series on nurse graduates in non-OECD countries are more limited under the NHWA data platform. While some countries are reporting a large increase in the number of nurse graduates between 2015 and 2022 (or nearest years), ten countries are reporting a reduction.

json
{
  "table": {
    "headers": [
      "Country",
      "2015",
      "2016",
      "2017",
      "2018",
      "2019",
      "2020",
      "2021",
      "2022",
      "Growth rate 2015-22 (or nearest years)"
    ],
    "data": [
      ["Afghanistan", "1 874", "1 707", "1 812", "4 797", null, null, null, null, null],
      ["Albania", "2 000", null, null, "2 563", null, null, null, null, null],
      ["Angola", null, "727", null, null, "20", "20", null, null, "-23%"],
      ["Antigua and Barbuda", "26", "18", "24", "20", "20", null, null, null, null],
      ["Argentina", "5 684", null, null, null, null, null, null, null, null],
      ["Armenia", "1 159", "750", "622", "571", "491", null, null, null, "-58%"],
      ["Bangladesh", "6 308", "6 343", null, null, null, null, null, null, null],
      ["Barbados", null, "137", null, null, "89", null, null, null, null],
      ["Belarus", "1 748", "1 580", "3 305", "1 721", "2 051", "2 048", null, null, "17%"],
      ["Belize", "26", "49", "32", "50", null, null, null, null, null],
      ["Benin", null, null, null, "80", null, null, null, null, null],
      ["Bhutan", "43", "123", "123", "61", "103", null, null, null, "140%"],
      ["Bosnia and Herzegovina", "398", "278", "361", "432", null, null, null, null, null],
      ["Botswana", "280", "290", "260", "250", "260", null, null, null, "-7%"],
      ["Brazil", "42 253", "41 264", null, null, null, null, null, null, null],
      ["Bulgaria", "379", "434", "490", "593", "497", "481", "552", null, "46%"],
      ["Burkina Faso", "1 535", "3 714", "2 039", "2 718", "2 630", null, null, null, "71%"],
      ["Cambodia", "1 113", null, null, null, null, null, null, null, null],
      ["Cameroon", "1 875", null, "4 236", "1 032", null, null, null, null, null],
      ["Chad", "347", null, "1 412", "1 838", null, null, null, null, null],
      ["Cook Islands", "7", "6", null, null, null, null, null, null, null],
      ["Croatia", "977", "1 277", "988", "1 399", "1 509", "1 446", "1 467", null, "50%"],
      ["Cuba", "450", null, null, null, null, null, null, null, null],
      ["Cyprus", "266", "178", "137", "134", "122", null, null, null, "-54%"],
      ["Dominican Republic", "1 480", "1 641", null, null, null, null, null, null, null],
      ["El Salvador", "550", "488", null, null, null, null, null, null, null],
      ["Eritrea", "374", "392", "256", "560", null, null, null, null, null],
      ["Eswatini", "183", "256", "278", "298", null, null, null, null, null],
      ["Gambia", "125", null, "125", null, null, null, null, null, null],
      ["Georgia", "9", null, null, null, null, null, null, null, null],
      ["Ghana", null, null, null, "13 078", null, null, null, null, null],
      ["Guatemala", "289", "456", "356", null, null, null, null, null, null],
      ["Guyana", "85", "187", "32", "225", null, null, null, null, null],
      ["India", "322 827", null, "292 564", null, null, null, null, null, null],
      ["Indonesia", "73 862", "85 317", null, null, null, null, null, null, "28 886"],
      ["Iran", "9 445", "9 445", null, null, null, null, null, null, null],
      ["Jamaica", "418", null, null, null, null, null, null, null, null],
      ["Jordan", "1 825", null, null, null, null, null, null, null, null],
      ["Kazakhstan", "6 812", "7 129", "6 516", "6 895", "6 958", "6 662", null, null, "-2%"],
      ["Kenya", "6 836", "241", "7 120", null, null, null, null, null, null],
      ["Kyrgyzstan", "7 170", "7 088", "6 649", "6 761", "5 677", null, null, null, "-21%"],
      ["Lao PDR", "298", null, "526", null, null, null, null, null, null],
      ["Lesotho", "304", null, null, null, null, null, null, null, null]
    ]
  }
}
``` 

WHAT DO WE KNOW ABOUT YOUNG PEOPLE’S INTEREST IN HEALTH CAREERS? © OECD 2025
```
# Table of contents

Acknowledgements 3  
Executive summary 6  
1 Introduction 7  
2 Methodology and data sources 8  
   2.1 PISA survey data on the career aspirations of secondary school students 8  
   2.2 Data on applications and admissions in nursing education programmes from national administrative (programme) data sources 9  
3 Review of PISA data on career aspirations of 15-year-old students 11  
   3.1 Students’ aspirations in working in the health sector 11  
   3.2 Students’ aspirations in working as doctors 13  
   3.3 Students’ aspirations in working as nurses 15  
   3.4 Gender differences in interest in working as doctors and nurses 17  
4 Review of programme data on student applications and admissions in nursing education 21  
   4.1 Results of online search of data for a subgroup of OECD countries 21  
   4.2 Gender differences in admissions to nursing schools 27  
   4.3 Results of data reported through the NHWA for OECD and non-OECD countries 29  
5 Conclusion 33  
Annex A. Data on medical and nursing graduates in OECD and non-OECD countries from the OECD and WHO annual data collections 35  
Annex B. Number of students who answered the question on career aspirations in PISA 2022 in the 80 participating countries and economies 41  
Annex C. National data sources and coverage on applications and admissions in nursing education programmes, OECD data collection 42  
Notes 44  
References 45  
```
| Country                    | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | Growth rate 2015-22 (or nearest years) |
|---------------------------|------|------|------|------|------|------|------|------|----------------------------------------|
| Libya                     | 201  | 135  | 263  |      |      |      |      |      |                                        |
| Madagascar                | 150  | 116  | 168  | 159  |      |      |      |      |                                        |
| Malawi                    | 1,886| 1,620| 5,779| 5,753| 5,753| 5,670|      |      | -2%                                    |
| Malaysia                  | 5,779| 5,753| 5,753| 5,753| 5,670|      |      |      |                                        |
| Maldives                  | 129  |      |      |      |      |      |      |      |                                        |
| Malta                     | 158  | 178  | 143  | 132  | 166  | 165  |      |      | 4%                                     |
| Marshall Islands          |      |      | 175  |      |      |      |      |      |                                        |
| Mongolia                  | 737  |      |      |      |      |      |      |      |                                        |
| Montenegro                | 55   | 37   | 42   | 40   | 34   |      |      |      | -38%                                   |
| Mozambique                | 943  | 606  | 714  | 87   | 396  |      |      |      | -58%                                   |
| Myanmar                   | 2,060| 2,522| 3,646|      |      |      |      |      |                                        |
| Namibia                   | 323  | 300  | 269  |      |      |      |      |      |                                        |
| Nigeria                   | 300  |      | 14,083| 8,375|      |      |      |      |                                        |
| North Korea               | 19,830|     |      |      |      |      |      |      |                                        |
| Oman                      | 223  | 212  | 274  | 583  | 599  |      |      |      | 169%                                   |
| Pakistan                  | 11,691|11,691|11,691|5,600|      |      |      |      |                                        |
| Panama                    |      |      |      |      |      |      |      | 315  | 307                                    |
| Papua New Guinea          | 220  | 467  | 439  | 387  |      |      |      |      |                                        |
| Paraguay                  | 1,368| 1,308| 1,171| 1,046|      |      |      |      |                                        |
| Philippines               | 12,267| 11,111| 12,098| 7,204|      |      |      |      |                                        |
| Qatar                     | 13   |      |      |      |      |      |      |      |                                        |
| Republic of Moldova       | 1,015| 1,065| 1,127| 1,163| 1,265| 1,239| 1,336|      | 32%                                    |
| Romania                   |      |      |      |      |      |      |      |      |                                        |
| Rwanda                    | 1,531| 865  | 787  | 947  |      |      |      |      |                                        |
| St Vincent and the Grenadines | 54 | 46   | 58   | 47   |      |      |      |      |                                        |
| Samoa                     | 50   | 117  |      |      |      |      |      |      |                                        |
| Senegal                   |      |      |      | 523  |      |      |      |      |                                        |
| Serbia                    | 4,083| 4,013| 3,933| 4,057| 3,886| 3,591|      |      | -12%                                   |
| Seychelles                |      |      | 8    |      |      |      |      |      |                                        |
| Sierra Leone              | 286  | 298  | 350  | 902  |      |      |      |      |                                        |
| South Africa              |      |      | 10,192|     |      |      |      |      |                                        |
| Sri Lanka                 | 2,500| 3,000| 3,000| 2,999|      |      |      |      | 20%                                    |
| Sudan                     | 5,355|      |      |      |      |      |      |      |                                        |
| Syria                     | 1,412|      |      |      |      |      |      |      |                                        |
| Tajikistan                | 11,056|     |      |      |      |      |      |      |                                        |
| Thailand                  | 9,365| 10,670| 10,670|     |      |      |      |      |                                        |
| Timor-Leste              | 60   |      |      |      |      |      |      |      |                                        |
| Trinidad and Tobago       | 432  |      |      |      |      |      |      |      |                                        |
| Turkmenistan              | 261  | 288  | 310  | 310  | 280  | 290  | 378  |      | 45%                                    |
| Uganda                    | 6,310| 8,224| 10,743| 10,353|    |      |      |      |                                        |
| United Arab Emirates      | 365  | 256  | 384  |      |      |      |      |      |                                        |
| Uruguay                   | 305  | 179  | 192  |      |      |      |      |      |                                        |
| Vanuatu                   |      |      | 37   |      |      |      |      |      |                                        |
| Zambia                    | 2,558|      |      |      |      |      |      |      |                                        |
| Zimbabwe                  | 742  | 934  | 814  | 796  |      |      |      |      |                                        |

Note: Growth rates were calculated only for countries with at least a five-year span between data points.
Source: WHO NHWA data platform (September 2024).
```
{
  "OECD_countries": [
    {"Country": "Australia", "Number": 9538},
    {"Country": "Austria", "Number": 3595},
    {"Country": "Belgium", "Number": 2016},
    {"Country": "Canada", "Number": 13200},
    {"Country": "Chile", "Number": 3639},
    {"Country": "Colombia", "Number": 5499},
    {"Country": "Costa Rica", "Number": 4480},
    {"Country": "Czechia", "Number": 4647},
    {"Country": "Denmark", "Number": 2859},
    {"Country": "Estonia", "Number": 4073},
    {"Country": "Finland", "Number": 4548},
    {"Country": "France", "Number": 4036},
    {"Country": "Germany", "Number": 3127},
    {"Country": "Greece", "Number": 4315},
    {"Country": "Hungary", "Number": 3297},
    {"Country": "Iceland", "Number": 1818},
    {"Country": "Ireland", "Number": 4311},
    {"Country": "Israel", "Number": 3597},
    {"Country": "Italy", "Number": 6727},
    {"Country": "Japan", "Number": 4110},
    {"Country": "Lithuania", "Number": 3798},
    {"Country": "Latvia", "Number": 2989},
    {"Country": "Mexico", "Number": 4479},
    {"Country": "Netherlands", "Number": 2582},
    {"Country": "Norway", "Number": 3644},
    {"Country": "New Zealand", "Number": 2866},
    {"Country": "Poland", "Number": 3819},
    {"Country": "Portugal", "Number": 4589},
    {"Country": "Slovak Republic", "Number": 3203},
    {"Country": "Slovenia", "Number": 4212},
    {"Country": "South Korea", "Number": 5994},
    {"Country": "Spain", "Number": 20913},
    {"Country": "Sweden", "Number": 3611},
    {"Country": "Switzerland", "Number": 3742},
    {"Country": "Turkey", "Number": 5839},
    {"Country": "United Kingdom", "Number": 7521},
    {"Country": "United States", "Number": 3131}
  ],
  "Non_OECD_countries": [
    {"Country": "Albania", "Number": 3298},
    {"Country": "United Arab Emirates", "Number": 16122},
    {"Country": "Argentina", "Number": 6239},
    {"Country": "Bulgaria", "Number": 2705},
    {"Country": "Brazil", "Number": 6036},
    {"Country": "Brunei Darussalam", "Number": 3644},
    {"Country": "Dominican Republic", "Number": 2363},
    {"Country": "Georgia", "Number": 2073},
    {"Country": "Guatemala", "Number": 2689},
    {"Country": "Hong Kong (China)", "Number": 3733},
    {"Country": "Croatia", "Number": 4012},
    {"Country": "Indonesia", "Number": 8832},
    {"Country": "Jamaica", "Number": 1719},
    {"Country": "Jordan", "Number": 4382},
    {"Country": "Kazakhstan", "Number": 15386},
    {"Country": "Cambodia", "Number": 2962},
    {"Country": "Kosovo", "Number": 356},
    {"Country": "Macao (China)", "Number": 3639},
    {"Country": "Morocco", "Number": 3251},
    {"Country": "Republic of Moldova", "Number": 4369},
    {"Country": "North Macedonia", "Number": 3728},
    {"Country": "Malta", "Number": 2205},
    {"Country": "Montenegro", "Number": 3742},
    {"Country": "Mongolia", "Number": 4174},
    {"Country": "Malaysia", "Number": 5166},
    {"Country": "Panama", "Number": 1498},
    {"Country": "Philippines", "Number": 4776},
    {"Country": "Paraguay", "Number": 3224},
    {"Country": "Palestinian Authority", "Number": 4636},
    {"Country": "Qatar", "Number": 4231},
    {"Country": "Baku (Azerbaijan)", "Number": 2607},
    {"Country": "Ukrainian regions (18 of 27)", "Number": 2039},
    {"Country": "Romania", "Number": 805},
    {"Country": "Saudi Arabia", "Number": 4417},
    {"Country": "Singapore", "Number": 5227},
    {"Country": "Serbia", "Number": 4085},
    {"Country": "Chinese Taipei", "Number": 4406},
    {"Country": "Thailand", "Number": 5923},
    {"Country": "Uruguay", "Number": 3961},
    {"Country": "Uzbekistan", "Number": 3709},
    {"Country": "Viet Nam", "Number": 4861}
  ],
  "Total": {
    "OECD": 171159,
    "Non_OECD": 192440,
    "Grand_total": 371599
  }
}
```
| Source name (and web address) | Data coverage                         |
|-------------------------------|--------------------------------------|
| Australia                     | Department of Education              |
|                               | www.education.gov.au/higher-education-statistics/undergraduate-applications-offers-and-acceptances-publications      | Bachelor of nursing (3 years) |
| Belgium                       | Académie de recherche et d’enseignement supérieur (the French region)               |
|                               | Indicateurs (ares.ac.be)            |
|                               | KU Leuven University (the Flemish region)   |
|                               | https://onderwijs.vlaanderen.be/nonderwijsstatistieken/dataloep-aan-de-slag-met-cijfers-over-onderwijs | French region: Bachelor of nursing (Haute École) (4 years), Flemish region: Vocational education (3 years) and Bachelor (4 years) of nursing and midwifery |
| Czechia                       | Ministry of Education and Sports of the Czech Republic    | www.mshv.cz/vzdelavani/skolstvi-v-cr/statistika-skolstvi-data-o-studenttech-poprve-zapsanych-za-obdobi-vysokych | Bachelor of nursing (3 years) |
| France                        | DREES                              | https://data.drees.sante.gouv.fr/explore/dataset/491-la-formation-aux-professions-de-sante/information/ | Bachelor of nursing (3 years) |
|                               | (for admissions, and applications until 2019) |
|                               | Ministère de l'Enseignement supérieur et de la Recherche.    | https://data.enseignementsup-recherche.gouv.fr/referentiels-parcoursup/information/ | (for applications 2019 onwards) |
| Germany                       | Federal Institute for Vocational Education and Training (BIBB)  | www.bibb.de/de/index.php/d/175452.php | Bachelor of nursing (3 years), Vocational training programme (3 years) |
| Ireland                       | Central Applications Office         | www.cao.ie/index.php?page=app_stats&bb=mediastats | Bachelor of 4 years |
| Italy                         | Conferenza Nazionale Corsi di Laurea delle Professioni Sanitarie | www.floto.it/italia/img/Report%20Mastrillo%202021.pdf | Bachelor of nursing (3 years) |
| Japan                         | Ministry of Health, Labour and Welfare | www.e-stat.go.jp/stat-search/files?page=1&tokei=00450141&tstat=000001022606 | Vocational education programme (3 years), Bachelor of nursing (4 years) |
| Netherlands                  | Statistics Netherlands              | www.cbs.nl/nl-nl/nieuws/2021/25/12-procent-mer-studenten-begonnen-met-hbo-verpleegkunde | Bachelor of nursing (3 years) |
| Norway                        | Norwegian Universities and Colleges Admission Service | www.samordnaopptak.no/info/on/sokertal/sluttstatikker/ | Bachelor of nursing (3 years) |
| Poland                       | POL-on Integrated Information System for Higher Education and Science (Report on the number of candidates and enrollments) | https://polon.nauka.gov.pl/en/public-data/ | Bachelor of nursing (3 years) |


```json
[
    {
        "Source": "Ministry of Universities",
        "Web Address": "https://estadisticas.universidades.gob.es/ajax/PxTablad.htm?path=Universitaria/Alumnado/UEU_2023/GradoCiolo/Neolengresol/0/8&file=1_3_Mat_Sex_Edad(1)_Amb_Tot.px (for admissions)",
        "Data Coverage": "Bachelor of nursing (4 years)"
    },
    {
        "Source": "Central Bureau of Statistics",
        "Web Address": "www.bfs.admin.ch/bfs/home/statistics/education-science/personnes-formation/degre-tertiaires-hautes-ecoles/specialises.assetDetail.24343575.html",
        "Data Coverage": "Bachelor of nursing (Haute Ecole) (3 years)"
    },
    {
        "Source": "Universities and Colleges Admissions Service (UCAS)",
        "Web Address": "www.ucas.com/data-and-analysis/undergraduate-statistics-and-reports/",
        "Data Coverage": "Bachelor of nursing (4 years)"
    },
    {
        "Source": "American Association of Colleges of Nursing (AACN)",
        "Web Address": "www.aacnnursing.org/news-data/all-news/new-data-show-enrollment-declines-in-schools-of-nursing-raising-concerns-about-the-nations-nursing-workforce",
        "Data Coverage": "Bachelor of nursing (4 years)"
    },
    {
        "Source": "American Association of Colleges of Nursing (AACN)",
        "Web Address": "www.aacnnursing.org/News-Information/Press-Releases/View/ArticleId/25183/Nursing-Schools-See-Enrollment-Increases-in-Entry-Level-Programs",
        "Data Coverage": "Bachelor of nursing (4 years)"
    }
]
```
# Notes

1. In Türkiye, this reduced interest has coincided with worsening working conditions for doctors, notably a growing number of highly publicised incidents of violence against doctors, as well as disputes over wage settlements. This sharp reduction in interest is also reflected in a growing proportion of unfilled places in medical schools: 3.7% of medical school places remained unfilled in 2022, up from 1% only in 2019.

2. In Qatar, there are notable initiatives to nurture medical career aspirations among high school students and preparing them for medical schools, such as short-course campus experience activities or targeted training programmes for high-achieving high school students.

3. The interest in nursing in Albania and Kosovo seems to stem from perceived job security and income stability of the nursing profession, along with the attractive prospect of employment opportunities in other European countries, particularly in Germany.

4. More than half of nurses working in Ireland were foreign-trained nurses in 2023. This was by far the largest share across all EU and OECD countries.

5. These recent trends in student applications in Japan contrast with the PISA 2022 results which showed an increase in the interest of 15-year-old students in nursing careers. This suggests that interest in nursing may be diminishing between age 15 and the time that students apply to postsecondary education programmes.

6. In the United Kingdom, undergraduate nursing students are eligible for a bursary of a minimum of GBP 5,000 per year to fund their studies. In 2023, the government also announced 50% more funding for students in health-related programmes to cover accommodation and travel expenses during their clinical placements for the 2023-24 academic year.
```
References

1. Abdulrahman, M. et al. (2016), “Specialty preferences and motivating factors: A national survey on medical students from five UAE medical schools”, *Education for Health* (Abingdon, England), Vol. 29/3, pp. 231-243, [https://doi.org/10.4103/1/2-6283.204225](https://doi.org/10.4103/1/2-6283.204225).

2. American Association of Colleges of Nursing (2023), *New Data Show Enrollment Declines in Schools of Nursing, Raising Concerns About the Nation’s Nursing Workforce*, [www.aacnnursing.org/news-data/all-news/article/new-data-show-enrollment-declines-in-schools-of-nursing-raising-concerns-about-the-nations-nursing-workforce](www.aacnnursing.org/news-data/all-news/article/new-data-show-enrollment-declines-in-schools-of-nursing-raising-concerns-about-the-nations-nursing-workforce).

3. Council of Higher Education (2022), *Tıp | YÖK Meslek Atlası (Medical Education Atlas)*, [https://yokatlas.yok.gov.tr/meslek-lisans.php?b=10206](https://yokatlas.yok.gov.tr/meslek-lisans.php?b=10206).

4. Council of Higher Education (2020), *Yükseköğretim Kurulu 2020 Yılı Yükseköğretim Kurumları Sınavı Yerleştirme Sonucular Raporu (Higher Education Institutions Exam Placement Results Report: 2020)*, [https://www.yok.gov.tr/HaberBelgeleri/BasinAciiklamasi/2020/yks-yerlestirme-sonuclari-raporu-2020.pdf](https://www.yok.gov.tr/HaberBelgeleri/BasinAciiklamasi/2020/yks-yerlestirme-sonuclari-raporu-2020.pdf).

5. Dahl, K. et al. (2021), “Motivation, Education, and Expectations: Experiences of Philippine Immigrant Nurses”, *Sage Open*, Vol. 11/2, [https://doi.org/10.1177/21582440211016554](https://doi.org/10.1177/21582440211016554).

6. Eder, R. (2016), “I Am Where I Think I Will Work: Higher Education and Labor Migration Regime in the Philippines”, *Educational Studies*, Vol. 52/5, pp. 452-468, [https://doi.org/10.1080/00311946.2016.1214913](https://doi.org/10.1080/00311946.2016.1214913).

7. European Observatory on Health Systems and Policies (2019), *Large increase in the Medical and Nursing Internship Programmes in 2020*, [https://eurohealthobservatory.who.int/im/monitors/health-systems-monitor/updates/hspm/spain-2018/large-increase-in-the-medical-and-nursing-internship-programmes-in-2020](https://eurohealthobservatory.who.int/im/monitors/health-systems-monitor/updates/hspm/spain-2018/large-increase-in-the-medical-and-nursing-internship-programmes-in-2020).

8. Financial Times (2024), “UK nursing applications fall sharply despite NHS shortages”, [www.ft.com/content/81b10479-42b3-4544-9d6a-659f3d2de668](www.ft.com/content/81b10479-42b3-4544-9d6a-659f3d2de668).

9. Genc, K. (2022), “Turkish doctors emigrate amid low pay and rising violence”, *The Lancet*, Vol. 400/10351, pp. 482-483, [https://doi.org/10.1016/s0140-1/2/22)01524-0](https://doi.org/10.1016/s0140-1/2/22)01524-0.

10. Irish Government Economic and Evaluation Service (2022), *Spending Review 2022*, [https://assets.gov.ie/257131/fbbe5c4e-63cc-49f9-bcf4-f0ddc71e5850.pdf](https://assets.gov.ie/257131/fbbe5c4e-63cc-49f9-bcf4-f0ddc71e5850.pdf).


### References

1. Kraja, J. et al. (2022). “Student's Reasons of Choosing the Bachelor Study Program in Nursing”. Open Access Macedonian Journal of Medical Sciences, Vol. 10/G, pp. 445-454, https://doi.org/10.3889/oamjms.2022.9006.

2. Le Figaro (2023). Écoles d'infirmiers: «2000 places supplémentaires» créées à la rentrée prochaine. https://etudiant.lefigaro.fr/article/ecoles-d-infirmiers-2000-places-supplementaires-creees-a-la-rentree-prochaine_ff5c2906-e41e-11ed-a82e-5cf803bd6520/.

3. Mann, A. and V. Denis (2020). Can nursing thrive in the age of the coronavirus? What young people think about the profession | The OECD Forum Network. www.oecd-forum.org/posts/can-nursing-thrive-in-the-age-of-the-coronavirus-what-young-people-think-about-the-profession-dce5a659-cc6d-1/2-b412-42e994b4e8197.

4. Mann, A., V. Denis and C. Percy (2020). Career ready?: How schools can better prepare young people for working life in the era of COVID-19. https://doi.org/10.1787/1520534-en.

5. Mann, A. et al. (2020). Dream Jobs? Teenagers’ Career Aspirations and the Future of Work – OECD. www.oecd.org/education/dream-jobs-teenagers-career-aspirations-and-the-future-of-work.htm.

6. NHS (2024). Annual nursing payments. www.healthcareers.nhs.uk/nursing-careers/annual-nursing-payments.

7. NHS England (2023). NHS Long Term Workforce Plan. www.england.nhs.uk/long-read/nhs-long-term-workforce-plan-2/#2-train-growing-the-workforce.

8. Nursing Times (2023). England student nurses offered more help with placement expenses. www.nursingtimes.net/news/education/england-student-nurses-offered-more-help-with-placement-expenses-01-09-2023/.

9. OECD (2024). PISA 2022 Technical Report, PISA, OECD Publishing, Paris, https://doi.org/10.1787/018206d6-en.

10. OECD (2023). Health at a Glance 2023: OECD Indicators, OECD Publishing, Paris, https://doi.org/10.1787/7a7afb35-en.

11. OECD (2023). PISA 2022 Results (Volume I): The State of Learning and Equity in Education, PISA, OECD Publishing, Paris, https://doi.org/10.1787/53f23881-en.

12. OECD (2023). PISA 2022 Results (Volume II): Learning During – and From – Disruption, PISA, OECD Publishing, Paris, https://doi.org/10.1787/a97db61c-en.

13. OECD (2023). Ready for the Next Crisis? Investing in Health System Resilience, OECD Health Policy Studies, OECD Publishing, Paris, https://doi.org/10.1787/1e53cf80-en.

14. OECD (2019). PISA 2018 Results (Volume II): Where All Students Can Succeed, PISA, OECD Publishing, Paris, https://doi.org/10.1787/b5d1b18f-en.

15. OECD/European Commission (2024). Health at a Glance: Europe 2024: State of Health in the EU Cycle, OECD Publishing, Paris, https://doi.org/10.1787/b3704e14-en.

16. OECD/European Observatory on Health Systems and Policies (2023). Poland: Country Health Profile 2023, State of Health in the EU, OECD Publishing, Paris, https://doi.org/10.1787/f597c810-en.
```
## Executive summary

Health workforce shortages are reported in most countries around the world, and there are concerns that these shortages might worsen in the coming years due to population ageing and the ageing of the health workforce itself. Increasing the training capacity of new doctors and nurses is one of the main policy levers for countries to respond to growing demand for health services and address potential shortages. However, expanding educational capacity will prove ineffective if there is not a sufficient pool of qualified and motivated candidates to fill these positions.

The COVID-19 pandemic has underscored the critical role of frontline health workers, but also highlighted how demanding and stressful the working conditions can be in the health sector. There are growing concerns that these difficult working conditions, combined with relatively low pay for some categories of health workers, may deter young people from pursuing studies and careers in health. Preventing future health workforce shortages will depend crucially on enhancing the attractiveness of health sector jobs.

While the number of graduates in health-related education programmes provides a good indicator of national efforts to train new health workers, it is also important to look at the earlier stages of the education process to gauge students’ interest in health sector jobs. This technical report examines the availability and comparability of data on students’ interest in health sector jobs from two main sources: 1) the OECD Programme for International Student Assessment (PISA) survey that covers around 80 OECD and non-OECD countries and economies (including most G20 countries); and 2) student applications and admissions to health education programmes based on national administrative (programme) data as collected by the OECD and WHO. The analysis from this second data source focuses primarily on nursing education programmes, given the concerns about declining interest in this field. This technical report does not aim to address the broader policy issues of attracting more young people in health sector jobs.

Data from the PISA survey indicate that the interest of 15-year-old students in pursuing careers in the health sector, and more specifically as doctors and nurses, has decreased in about half of OECD countries between 2018 and 2022, and it has also decreased in several non-OECD countries. 15-year-old girls are far more likely than boys to express interest in careers not only in nursing, but also to become doctors in nearly all OECD and non-OECD countries and economies. A persisting major challenge therefore in most countries is to attract more males into health professions, and particularly in nursing.

National administrative data on applications and admissions in health education programmes can provide additional insights into students’ interest in pursuing health careers, especially at the stage when they are making their higher education and career choices. The online research conducted by the OECD revealed that data on student applications are less readily available than admissions data in most countries. In the limited number of OECD countries for which consistent trend data are available, applications in nursing programmes increased during the early pandemic years, but subsequently decreased in 2022 and 2023 in several countries, signalling reduced interest. The data collection under the WHO National Health Workforce Accounts (NHWA) currently provides very limited time series for both OECD and non-OECD countries on applications and enrolments/admissions in nursing education programmes, thereby limiting any trends analysis before and after the pandemic. The available data show substantial cross-country variations in application and admission rates, as well as data inconsistencies in approximately one-quarter of countries reporting these data. This suggests a need to work with countries to clarify some of the definitions used in this data collection (e.g. the term “enrolments”). Although the NHWA does not mandate countries to report on education indicators, incorporating these indicators into the monitoring and evaluation frameworks of global health and care workforce initiatives could enhance data quality and consistency.
```
# Introduction

Health workforce shortages are reported in most OECD and non-OECD countries, and there are concerns that these shortages might worsen in the coming years due to population ageing (which is expected to increase the demand for health workers and reduce the size of the working-age populations) and the ageing of the health workforce itself (which will lead to increased attrition as a large number of current health workers will retire). Increasing the education and training of new doctors and nurses is one of the main policy levers for countries to maintain if not increase the health workforce to respond to growing demand and address shortages. Many countries have recognised this and have already expanded enrolment in medical and nursing education programmes and/or are planning further increases in the coming years. However, expanding educational capacity will be ineffective if there is not a sufficient pool of qualified and motivated candidates applying to fill these places.

The COVID-19 pandemic added new challenges to attracting young people in health education programmes. While health workers were widely celebrated as heroes during the crisis, their experiences of unprecedented stress, challenging working conditions, exposure to health risks and relatively low pay in some occupations may have paradoxically deterred many young people from pursuing health careers. Monitoring whether and how the pandemic has influenced the career aspirations of young people in healthcare is therefore important to understand the potential pool of applicants and future domestic supply of health workers.

This report builds on the existing OECD and WHO annual data collections on the number of graduates in health-related education programmes through the OECD/Eurostat/WHO-Europe Joint Questionnaire and the WHO's National Health Workforce Accounts (NHWA) system. The number of graduates provides a good indicator of national efforts to train new health workers. It reflects the number of students that were admitted a number of years earlier (depending on the duration of the education programme - often 5 years to obtain a first medical degree and about 3 years to obtain a nursing degree) minus the dropout rate of students during the course of these studies. In other words, data on the number of graduates reflect decisions on student intakes taken a number of years before as well as efforts to reduce student dropout rates. 

The results from these data collections show that in most countries, the number of medical and nursing graduates has increased over the past decade albeit at different rates.

This report reviews the availability and comparability of data at an earlier stage of the education process of new health workers, focussing in particular on young people's interest in pursuing careers in health professions in OECD and non-OECD countries. It draws on two main data sources. The first source is the data on the career aspirations of young people based on the OECD Programme for International Student Assessment (PISA) survey, which covers over 80 countries and economies. The second source relates to student applications and admissions in health education programmes based on national administrative (programme) data as collected by the OECD through online (ad hoc) research and by WHO through the NHWA. The analysis of the available data focuses specifically on nursing education programmes given the particular concerns of reduced interest in nursing and to keep the scope of this analysis manageable.
```
## 2 Methodology and data sources

This report reviews the data availability and comparability of data on students’ interest in pursuing health careers from two different data sources:

1. Data on the career aspirations of 15-year-old students from the OECD PISA survey; and
2. Data on applications and admissions in health education programmes, focusing in particular on nursing education programmes, as collected by the OECD through online (ad hoc) research and by WHO through the NHWA.

These data sources have different objectives, methodologies and cover students at different ages; hence it should not be expected that these two different data sources provide the same or similar results.

### 2.1 PISA survey data on the career aspirations of secondary school students

The main aim of the PISA survey, launched by the OECD in 2000, is to capture student performance in participating countries by measuring 15-year-olds’ skills and knowledge in reading, mathematics and science. This survey is usually carried out every three years, with the only exception being during the COVID-19 pandemic when the survey was carried out in 2022 instead of 2021. In the last wave of 2022, almost 700,000 students from 81 countries and economies took the survey (OECD, 2023). Among G20 countries, the following currently participate in PISA: Argentina, Australia, Brazil, Canada, China, France, Germany, Indonesia, Italy, Japan, Korea, Mexico, Saudi Arabia, Türkiye the United Kingdom and the United States. India and the Russian Federation have also participated in earlier rounds of PISA but are not currently participants, and South Africa does not currently participate.

The PISA survey also includes a question on the career expectations of 15-year-old students, asking them the following open-ended question: “What kind of job do you expect to have when you are about 30 years old?”. The plain responses to this question are subsequently coded based on the International Standard Classification of Occupations (ISCO-08). Regarding health occupations, the categories include all health occupations at the two-digit levels (code 22) with the exception of traditional and complementary medicine professions, and a finer breakdown at the three-digit level for doctors (code 221), professional nurses and midwives (code 222), and associate professionals nurses and midwives (code 322) and other health occupations. The occupations under these codes have been used for analysis in this report, with the exception of the codes relating to midwifery only.

All respondents who did not respond to this question or do not provide sufficiently specific responses are excluded (this represented 23% of all respondents in PISA 2018 survey and 39% in PISA 2022). The pandemic has led to lower student response rates due to school closures and the uneven pace of reopening across countries (OECD, 2024). While the majority of countries and economies nevertheless managed to collect data in accordance with PISA sampling standards, a dozen (Australia, Canada, Denmark, Hong Kong (China), Ireland, Jamaica, Latvia, the Netherlands, New Zealand, Panama, the United Kingdom and the United States) did not meet one or more sampling standards, which may have resulted in some bias (OECD, 2023).
```
In total, 371,599 students from 80 countries and economies provided sufficiently specific responses to the question on career aspirations in PISA 2022 (only students from Cyprus among participating countries did not respond to this question), of which 171,159 students were from 37 OECD countries and the remaining 192,440 students were from non-OECD countries and economies. The number of students who responded to the question ranged from about 1,500 students in Panama to nearly 21,000 students in Spain. Annex B provides information on the sample size of students who responded to this question in each participating country.

### 2.2 Data on applications and admissions in nursing education programmes from national administrative (programme) data sources

The data on applications and admissions to nursing education programmes were collected from national administrative sources through online (ad hoc) research by the OECD and through the NHWA.

The data collected by the OECD only cover a subgroup of OECD countries and aimed to collect time series including at least a few years before the pandemic and a few years following the pandemic to be able to assess any impact of the pandemic on application and admission rates. The data come mainly from national administrative sources managed by Ministries of Education or Higher-Education or national statistical agencies. In some cases, the data were only available from professional associations or specific research projects. Annex C provides more information on the data sources and the coverage of nursing education programmes in each country.

For other OECD and non-OECD countries, the data come from the NHWA, which collects data annually from designated national focal points on applications and enrolments in various health workforce education and training programmes including nursing programmes (WHO, 2023). The review of the data in this report only includes countries that have submitted both application and enrolment data for a recent year.

The data in this report relate exclusively to applications and admissions to undergraduate nursing education programmes (i.e. it excludes data related to master’s and doctoral degree programmes). They also exclude applications to become associate professional nurses.

#### 2.2.1 Definition of applications and data comparability issues

Applications are generally defined as the number of students who formally submitted their interest in being admitted to the first year of a nursing education programme. The overall aim of the data collection is to collect the number of applicants (i.e. the number of people who apply to a nursing education programme), not the overall number of applications to avoid double-counting people who are applying to more than one nursing programme. However, not all national data sources in the OECD data collection provided data specifically on applicants (instead of overall applications). In addition, in the NHWA, there is some ambiguity in the definition of applications, which is defined as the number of applications to the first year of a health education and training programme, so the numbers in some countries may include some double-counting of people applying to more than one programme (WHO, 2023).

The data collected by the OECD through the online (ad hoc) research have a number of limitations in terms of comparability across countries or over time, due to factors such as significant changes in application systems and differences in data coverage:
- As already noted, in some countries, only data on the overall number of applications are available, resulting in a potentially large over-estimation (double-counting) of the number of applicants (e.g. Japan, Portugal).


