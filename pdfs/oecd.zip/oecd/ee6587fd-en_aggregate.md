# Trends Shaping Education 2025

**Image Description:**
The image shows a person climbing a set of colorful stairs. The stair treads are painted in various geometric shapes and colors, including blue, turquoise, and orange. The person is wearing black pants and white sneakers, emphasizing the upward motion. 

**Note:** No conversion of tables or additional text content is included, as the provided image is the only element present.
# Executive Summary

This report explores global megatrends that are shaping societies in OECD countries and beyond through an educational lens. It raises questions about the implications of global trends for various stages and sectors of education and offers thinking tools to help education systems anticipate disruptions and think strategically about the future. In times of rapid change and uncertainty, futures thinking can help education systems navigate complex global challenges. By imagining potential scenarios and exploring diverse possibilities, it enables education policymakers and stakeholders to make informed decisions that are resilient and adaptive. This proactive approach can help education systems to prepare for potential disruptions, but also to seize emerging opportunities and take action today to shape the future. This summary highlights key trends explored in this edition along with suggestive questions they may raise for education.

## A polarised world

The 2025 edition of this report reflects how the early 2020s have been marked by mounting geopolitical tensions and escalating ecological crises, with far-reaching implications for migration, energy security, trade dynamics, labour markets and policy priorities. Global conflicts and crises adversely affect human and planetary health, exacerbate existing inequalities and generate new disparities.

Social and economic inequalities, in turn, risk aggravating political polarisation, as gaps in life experiences and economic standing intensify divergent interests and priorities. Polarisation was chosen as Word of the Year for 2024 by the dictionary publisher Merriam-Webster, based on significant increases in lookups and its relevance to current events. This highlights how opposing extremes in opinions and beliefs have become a defining feature of our societies, influencing everything from political discourse to social interactions.

The trends reviewed in this report paint a diverse and contrasting picture of social progress, where life outcomes are closely linked to the intersection of personal and group characteristics such as age, gender, migration background and socio-economic status. When people experience economic threats or fear for their safety, their social and moral circles may retract, leading them to prioritise their own kin or in-group. The fragmentation of the media landscape and the rise of social media can exacerbate this by reinforcing echo chambers and reducing exposure to diverse perspectives. Conversely, our levels of openness and empathy are more likely to grow when we feel secure.

Geopolitical tensions and global crises underscore the role of education in fostering resilience among learners and providing them with a sense of security. This includes those who have been directly affected, as well as children growing up in an increasingly conflict-ridden, unstable world. While education may not resolve the root causes of global conflict, climate change and inequality, can it empower learners to understand, shape and demand the changes they want to see? And what role can it play, alongside other areas of public policy, in fostering social cohesion and respect for diversity? In a world where many expect today’s children to grow up to be worse off than their parents, how can education contribute to inter-generational understanding and solidarity?


Equality Index Report, https://disabilityin-bulk.s3.amazonaws.com/2024/DEI/2024+Disability+Equality+Index+Report_Final-508.pdf.

1. Touzet, C. (2023). “Using AI to support people with disability in the labour market: Opportunities and challenges”, OECD Artificial Intelligence Papers, No. 7, OECD Publishing, Paris, https://doi.org/10.1787/008b32b7-en; Alymnyti, M. et al. (2024). “Artificial Intelligence and the health workforce: Perspectives from medical associations on AI in health”, OECD Artificial Intelligence Papers, No. 28, OECD Publishing, Paris, https://doi.org/10.1787/9a31d8af-en; Maslej, N. et al. (2024), The AI Index 2024 Annual Report, AI Index Steering Committee, Institute for Human-Centered AI, Stanford University, https://aiindex.stanford.edu/report/; Deloitte (2024), 2024 Global Health Care Sector Outlook, https://www2.deloitte.com/content/dam/Deloitte/global/Documents/qx-transforming-health-care-with-artificial-intelligence.pdf.

2. OECD (2023), Beyond Applause? Improving Working Conditions in Long-Term Care, OECD Publishing, Paris, https://doi.org/10.1787/2fd33ab3-en; OECD (2023), Time for Better Care at the End of Life, OECD Health Policy Studies, OECD Publishing, Paris, https://doi.org/10.1787/722b927a-en; OECD (2024), Is Care Affordable for Older People?, OECD Health Policy Studies, OECD Publishing, Paris, https://doi.org/10.1787/450ea778-en; OECD (2020), Who Cares? Attracting and Retaining Care Workers for the Elderly, OECD Health Policy Studies, Paris, https://doi.org/10.1787/92c0ef68-en.

3. OECD (2023), Health at a Glance 2023: OECD Indicators, OECD Publishing, Paris, https://doi.org/10.1787/7afb35-en; OECD (2024), Society at a Glance 2024: OECD Social Indicators, https://doi.org/10.1787/918d8d3b-en; OECD (2020), Who Cares? Attracting and Retaining Care Workers for the Elderly, OECD Health Policy Studies, Paris, https://doi.org/10.1787/92c0ef68-en; OECD (2024), OECD Health Statistics 2023 - Health Workforce Migration, https://data.oecd.org/reg/health-workforce-migration.htm (accessed 18 June 2024).

4. Hanna, T. et al. (2023), Forecasting time spent in unpaid care and domestic work - Technical brief, UN Women and Frederick S. Pardee Center for International Futures, University of Denver, https://data.unwomen.org/publications/forecasting-time-spent-unpaid-care-and-domestic-work; OECD (2023), Joining Forces for Gender Equality: What is Holding us Back?, OECD Publishing, Paris, https://doi.org/10.1787/67480424-en; OECD (2023), SIGI 2023 Global Report: Gender Equality in Times of Crisis, Social Institutions and Gender Index, OECD Publishing, Paris, https://doi.org/10.1787/467b6077c7-en; Ervin, J. et al. (2022), “Gender differences in the association between unpaid labour and mental health in employed adults: a systematic review”, The Lancet Public Health, Vol. 7/9, pp. e775-e786, https://www.thelancet.com/journals/lanpub/article/PIIS24682667(22)00160-8/fulltext; OECD (2024), Megatrends and the Future of Social Protection, OECD Publishing, Paris, https://doi.org/10.1787/6c9202e8-en.


# Trends Shaping Education 2025

Did you ever wonder how rising inequality and polarisation will shape education? Or how advances in artificial intelligence, virtual reality, and other technologies could transform teaching and learning?

Trends Shaping Education is a triennial report exploring the social, technological, economic, environmental and political forces transforming education systems worldwide. The trends are robust, but the questions raised in this report are suggestive. They are designed to inspire reflection and inform strategic thinking on how global trends might transform education and how education can shape a better future.

The 2025 edition explores a rich array of topics related to the key themes of global conflict and cooperation, work and progress, voices and storytelling, and bodies and minds. It builds on foresight exercises from previous editions, while introducing a range of new futures thinking tools to inspire reflection and action.

This report is designed to give policy makers, researchers, educational leaders, administrators and teachers a robust, non-specialist source of international comparative trends shaping education, whether in early childhood education and care, schools, universities or in programmes for older adults. It will also be of interest to students, parents and anyone curious about how education can address today's challenges and prepare for the future.


**Image text**: 

PRINT ISBN 978-92-64-97682-5  
PDF ISBN 978-92-64-74933-7  
9789264976825
# New forms of progress

Amidst these tensions, progress made through international co-operation and global advocacy indicates that collective action can offer hope. The recent past has shown that global challenges like pandemics, climate change, disruptions in energy supply, or cyberattacks can best be addressed through international efforts. Pooling scientific expertise and financial resources can enable societies to respond more swiftly and effectively to global crises. Similarly, international co-operation and agreements can help consolidate social progress on human rights, equality, and non-discrimination by setting global norms and standards.

Within countries, trust in democratic institutions and participation in elections are declining, but people who feel they have a say in government decisions report much higher levels of trust. This highlights the importance of citizen participation, with various forms of participative governance holding the promise for citizens to influence public decisions in meaningful ways. But citizen voice is expressed in increasingly diverse forms, challenging traditional democratic processes to adapt. Movements like #MeToo, Black Lives Matter, and Fridays for Future, as well as the spread of decolonial perspectives, have fueled debates about whose stories are being told and heard within democracies and in a globalised cultural landscape. While the explosion of digital technologies and social media has created new challenges by enabling the spread of false and misleading claims, it has also opened democratic debate to more voices.

More broadly, technological advancements and innovations are transforming all aspects of our lives and help imagine new approaches to global issues like climate change, food security, and public health. Frontier technologies including artificial intelligence, the Internet of Things, and virtual reality are already changing how we work, learn, and communicate. While concerns about job displacement, data privacy, equity, and mental health abound, the promise of these technologies to drive prosperity and transform fields as diverse as agriculture, transportation, medicine, and culture are fueling investment and innovation.

For education, rapid labour-market transitions have raised questions about how best to anticipate future skill needs and diversify educational pathways to meet the rising demand for high-skilled workers and lifelong learning. Given the rapid pace of change, how best to combine the teaching of specific skills with that of broader competencies needed to continue learning throughout life, including metacognitive skills? How can education systems address both foundational and more complex sets of skills in a way that complements rather than compromises one for the other? And how can the education sector use technologies to optimise its own core processes?

Thinking further ahead, how radically will technological developments and sustainability imperatives impact the need for human labour and the way that humans interact with each other? Shifting priorities indicate that, for increasing numbers of young people, work no longer constitutes a core component of their identity. AI is expanding the capacity of robots to work with humans in different fields, meaning that more of us will work collaboratively with intelligent machines in the years to come. And while human relationships remain central to caring for others, new technologies have the potential to transform social interactions. With less time spent in direct human contact, can education help maintain a sense of community and foster socio-emotional learning and well-being?

These and other questions for education are explored throughout this report, encouraging readers to engage actively with its content, explore alternative futures with an open mind, and adapt questions, scenarios, and thinking tools to support constructive stakeholder debates and forward-looking education policies.
```
urgent need to address climate change calls for education to promote sustainable living and responsible consumption, while helping learners to situate such actions with broader sectoral and systems changes.

Rapid societal transformations bring opportunities but also risk exacerbating existing inequalities. Low and middle incomes have been rising at slower rates than higher incomes, the ongoing cost-of-living crisis has hit young people particularly hard, and gender equality in the world of work presents a mixed picture of progress and setbacks. At the same time, technological advancements are redefining the very nature of work and social interactions. For education systems, these rapid changes raise questions of how to best support resilience and agility among all learners, supporting people in their quest for flexibility and self-actualisation while ensuring that they are equipped to navigate dynamic and uncertain labour markets.

Chapter 3, Voices and Storytelling, focuses on whose voices are heard and whose stories are told in our increasingly digital and globalised world. Democracies worldwide have seen a decline in voter turnout, particularly among younger voters, reflecting growing dissatisfaction with traditional political processes. However, the increase in protests on issues such as economic justice, climate change, and civil rights shows that young people are not apathetic but rather seek different forms of expression. Movements like #MeToo and Black Lives Matter have amplified discussions about whose perspectives are heeded and whose are marginalised, challenging historical imbalances. Education can empower individuals and communities to address issues they care about and promote active citizenship.

The rise of populism and polarisation highlights the need for education to promote social cohesion and critical thinking, while the spread of disinformation and the decline in press freedom show the importance of media literacy and responsible digital citizenship. Digital technologies and globalised cultural industries have raised concerns about the survival of local identities. But there are also signs that digitalisation is fostering linguistic diversity and empowering local cultural expressions, as well as supporting various forms of self-expression, with more people becoming influencers, podcasters, and self-published authors. The ubiquity of connected devices and the growing role of the Internet of Things (IoT) in everyday life also raise new opportunities and challenges for education.

Chapter 4, Bodies and Minds, explores the intricate connections between physical and mental health, environmental factors, and societal changes. Mental health has become a top health concern globally, with symptoms of mental distress more prevalent now than before the COVID-19 pandemic. While rates of daily smoking and alcoholism have gone down, recent years have seen persistent challenges of substance abuse and the emergence of new addictive patterns, particularly those related to digital media use. Addressing the broader context of health and well-being, the chapter highlights the interconnectedness of human, animal, and environmental health. Issues like plastic waste, antimicrobial resistance, and rising asthma and allergy rates underscore the need for coordinated action. Education can promote environmental protection and develop strategies to address rising health issues among students and staff.

The chapter also delves into new forms of treatments and care. Advances in medicine and technology, including AI, offer new opportunities to support people with disabilities and chronic health conditions, and can be leveraged for greater educational inclusivity. Advances in assisted reproduction technologies and emerging fertility technologies are enabling single people and same-sex couples to become parents, contributing to a growing diversity of family and household structures. While technology can help, human relationships remain at the core of caring for others. Education can help advance socio-emotional competencies, relevant skills for caregiving and attitudinal changes required to address the gender care gap.


{
  "figure": {
    "title": "Trends Shaping Education 2025: Overview of chapters and sub-chapters",
    "content": [
      "Bodies & Minds",
      "Global Conflict & Co-operation",
      "Voices & Storytelling",
      "Work & Progress",
      "Cross-cutting themes"
    ],
    "sections": [
      {
        "title": "Bodies & Minds",
        "items": [
          "Mental health concern",
          "Addictions old and new",
          "One Health & environmental health threats",
          "Fertility and reproductive health",
          "Disability and advances in medicine and technology",
          "Paid and unpaid care work"
        ]
      },
      {
        "title": "Global Conflict & Co-operation",
        "items": [
          "The cost of global conflict",
          "Demographics on the move",
          "Changing dynamics of global trade",
          "Energy security",
          "Co-operation on climate change",
          "Global science collaboration & technological innovation"
        ]
      },
      {
        "title": "Voices & Storytelling",
        "items": [
          "Democracy and its challenges",
          "Diverse voices in a globalized world",
          "Populism and polarization",
          "Freedom of expression & free reuse in the digital age",
          "The digital stage",
          "Look, who’s talking?"
        ]
      },
      {
        "title": "Work & Progress",
        "items": [
          "Mastering the twin transition",
          "Young adults and society in transition",
          "Economic inequality",
          "Diversities of experience"
        ]
      }
    ]
  }
}

### Cross-cutting themes
In addition to its main chapters, two major themes are woven throughout the report rather than addressed in their own dedicated chapters—advancements in technology, including artificial intelligence (AI), and considerations about environmental sustainability. This reflects how interactions with technology and sustainability questions are now embedded in all aspects of our lives and can hardly be considered in isolation.

Inequality is also addressed as a cross-cutting theme. Global trends can typically only offer a snapshot of a situation, masking significant differences across various socio-demographic groups. While advances in technology and changes in the environment are overarching themes, they influence and shape diverse experiences across different populations.
```
have been made globally in addressing inequalities related to poverty, gender, sexual orientation, age, minority status, disability and chronic health conditions, progress is often fragile, and vulnerable groups are hit the hardest by sudden shocks and crises. The trend data also shows that progress in equality dimensions is rarely linear. Often, societies may advance equality in one area, only to fall backwards in another. Inequalities threaten social cohesion and deepen fragmentation and polarisation – therefore they require special attention in futures thinking.

The following sub-sections crystallise the three dominant cross-cutting themes that emerged throughout the analysis in this report.

## Learning in an AI-driven world

Technological advancements are rapidly transforming most aspects of our lives, including education and the workforce. Frontier technologies such as artificial intelligence (AI), the Internet of Things (IoT) and virtual reality (VR) are developing rapidly, offering solutions to global challenges like climate change, food security and public health. These innovations are already changing how we work, learn and communicate. The chapters provide insights into how AI and other technologies are reshaping the educational landscape.

- **AI in the workforce**: The integration of AI and other advanced technologies is reshaping the labour market, automating many tasks, and creating new ones that require different skill sets. AI is also expanding the capacity of robots to work with humans in different fields, meaning that more of us will work collaboratively with intelligent machines in the years to come. How can education systems ensure individuals are prepared for the jobs of the future and foster lifelong learning to keep pace with technological advancements?

- **AI in education**: AI has the potential to revolutionise education itself by providing personalised learning experiences, automating administrative tasks, and supporting teachers in identifying students’ needs. Immersive technologies like VR are already commonly used to teach technical skills in areas like medicine and are also being explored for developing softer skills like empathy. However, the implementation of these technologies in education also raises concerns about data privacy, equity, and the potential for bias. How can education systems leverage AI and other frontier technologies to enhance learning while addressing these ethical and practical challenges?

- **Digital literacy and responsible use**: As digital technologies become more pervasive, there is a growing need for digital literacy to navigate the complexities of the digital world. This includes understanding how to use AI responsibly and ethically. How can education best equip students with the skills to critically evaluate digital content, protect their privacy, and use technology in ways that enhance their learning and well-being? How can curricula be designed to integrate digital literacy and promote responsible use?

- **Health and well-being**: Advances in AI and technology offer new opportunities to support health and well-being. AI can enhance the precision of mental health diagnoses and treatment options, while VR aids in managing phobias, anxiety, and social isolation. Assistive technologies also provide valuable support to individuals with disabilities and chronic health conditions. Education systems can leverage these technologies to provide comprehensive support for students and staff. How can schools ensure that AI and other technologies are used to promote health and well-being, while addressing emerging mental health challenges related to excessive use of digital devices?

- **Equity and access**: The digital divide remains a significant barrier to the equitable use of AI and technology. Ensuring that all students have access to the necessary tools and resources is crucial for fostering an inclusive educational environment. How can education systems address the digital divide and ensure that the benefits of AI and technology extend to all learners?


**Images or tables** were not present for conversion, hence no JSON or plain text output for those elements.
## Education on a fragile planet

The planetary crises of climate change, biodiversity loss, and pollution intersect with education in various ways: education and training systems are both vulnerable to the impacts of socio-ecological emergencies and crucial in shaping behaviours, collective action, and skills that can support sustainable societies and greening economies. The chapters highlight several key areas where sustainability presents both challenges and opportunities for educational systems.

- **The most global of all challenges:** Global socio-ecological challenges such as climate change threaten the stability of economies and societies worldwide, highlighting the importance of international co-operation. Can education foster understanding of the global, regional and local dimensions of these challenges and contribute to a more sustainable future?
  
- **Green jobs and skills:** The transition to greener economies and clean energy is essential for achieving climate targets. However, there is a skills mismatch that could slow this transition. How can education systems best support the development of relevant skills and help people transition out of polluting sectors to ensure that no one is left behind?
  
- **Sustainable consumption:** Changing patterns of production and consumption are essential to all pathways to net-zero carbon emission. Can education influence both individual and collective change by promoting environmental literacy and sustainable practices while highlighting historical imbalances and allowing for different values and world views?
  
- **Advocacy and activism:** Changing forms of political participation and cultural expression pave the way for new forms of climate activism and advocacy, while the rise of disinformation and political polarisation are threatening constructive debate. How can education foster trust in democratic institutions and responsible citizenship to help societies address complex, systemic challenges?
  
- **One Health approach:** The interconnectedness of human, animal, and environmental health underscores the importance of a holistic approach to sustainability. Can education foster understanding of One Health challenges and promote coordinated action across different sectors?

## Mind the gaps: inequality, fragmentation and polarisation

Social and economic inequality affect educational outcomes and social cohesion. When gaps in life experiences and outcomes between different groups widen, people may increasingly see themselves as part of distinct, often competing, factions. Fragmentation and polarisation can manifest itself in various ways, including more segregated communities and separate communication channels, limiting opportunities for interaction and understanding between different groups. The chapters explore how these challenges affect education and the ways in which education policies can contribute to mitigating them, alongside the broader cross-sectoral policies needed to target the root causes of inequality.

- **Migration:** Conflicts and economic pressures drive migration, which can exacerbate social and economic inequalities. How can education systems support the inclusion of newcomers in national education systems and promote appreciation for diversity among the host population?
  
- **Income inequality:** Rising within-country economic inequalities impact social cohesion and stability. Can education mitigate these inequalities by fostering social responsibility and improving life chances for students from lower socio-economic backgrounds?
  
- **Challenges for youth:** Younger generations are experiencing higher levels of mental distress, partly due to economic pressures and societal changes. Can education help young people navigate these challenges and foster inter-generational mobility, solidarity and cohesion?
  
- **Gender inequality:** Gender gaps in workforce participation and unpaid care work remain significant. Can education shift traditional gender roles and promote equality by empowering all?


students to follow their aspirations regardless of gender and fostering socio-emotional competencies among all?
- Political polarisation: The rise of populist movements and political polarisation has deepened social divides, creating challenges for democratic engagement and civic education. Can schools help mitigate the effects of polarisation and cultivate responsible and engaged citizens?

## Futures thinking

The future is not set in stone - endless possibilities await. Beyond a consideration of current trends, this report is designed to support futures thinking and strategic foresight efforts, adaptable to diverse contexts. Strategic foresight involves the structured consideration of ideas about the future to make better decisions in the present. At the end of each chapter, the report encourages readers to think about alternative futures and their implications for education. These efforts can help readers navigate uncertainty, prepare for disruptions, and, crucially, act to shape the future. They also allow readers to reflect on what a desired future might look like, and what steps might be taken to get there.

This section gives an overview of the futures thinking tools developed throughout the main chapters and offers ideas to adapt these to the specific context and concerns of your education system.

## Scenarios and stakeholder stories

A first step in practising futures thinking is to explore a range of potential developments (possible, probable, plausible, or preferable futures), and to identify drivers of change, large and small. From there, we can consider the implications of each future for specific domains such as education. Strategic foresight practitioners have developed various approaches to performing these tasks.

This edition presents imaginary future scenarios, exploring how the world and education could look in 2040 if one or more of the trends continue or change course. These scenarios are not intended to be a "study of the future" - their value lies primarily in the critical thinking, creativity and dialogue that is generated through their use. The three scenarios presented at the end of each chapter are constructed according to three archetypes:
- **Continuation scenarios** assume that current trends continue in the same direction and pace. These scenarios might be less surprising, but nonetheless require us to think of their implications. They also invite us to consider how current trends may interact with each other, as they continue.

However, since developments are rarely a linear continuation of the past, we are called upon to contemplate other types of futures:
- **Transformation scenarios** assume some transformative force has brought about significant changes. These forces could be technological, ecological, social, or other, and could have positive or negative consequences.
- **Collapse scenarios** assume a breakdown of a dramatic magnitude in one or more aspects (e.g., technological, ecological, social, economic), leading to a drastically different, failed world.

The scenario archetypes were inspired by those proposed by scholars in the field of strategic foresight (see Futures thinking resources section). The scenarios developed in this report serve as examples; they are not predictions, and they focus on some trends more than others. We invite readers to form new archetypes or variations on those described. Choice is an integral part of constructing a scenario: for example, which trends do we emphasise in a continuation scenario? What type of transformation or collapse do we propose? Being conscious about these choices supports a systematic approach to futures thinking.


{
  "Future Scenarios": {
    "Continuation": [
      "A Fragmented world",
      "Uneven progress",
      "Culture in Conflict",
      "Mixed prognosis"
    ],
    "Transformation": [
      "Radical glocalisation",
      "All out digital",
      "No representation without participation",
      "Biotech all around"
    ],
    "Collapse": [
      "Climate catastrophe",
      "The twin failure",
      "Techno authoritarianism",
      "Inter-connected health crises"
    ]
  }
}

The scenarios at the end of each chapter are paired with fictional stakeholder narratives, taking the perspective of key actors in education, and highlighting the opportunities, challenges, and tensions they face in a specific future. These stories are intended to inspire readers to consider the implications of alternative futures for actual people, and how impacts differ for different education stakeholders (e.g., Daniel, a school teacher; Leon, a primary-school student; Gabriel, a parent; or Priya, a policy maker). The stakeholders vary not only in the roles and functions they perform within education but also represent different socio-demographic background characteristics that may influence their educational experience.

By presenting a small selection of personas, we encourage you to think of relevant stakeholders in your context. Just as the scenarios, the stakeholder stories are not predictions; rather, they are intended to spark reflection on the implications of different possible futures and guide action
## Playing with your own scenarios

We invite readers to explore the scenarios, stakeholder narratives and reflection questions in an engaged manner, and as a basis for discussions on the future of education in your system. Involving a range of education stakeholders in these discussions helps to bring together different perspectives and explore creative ideas about the future, what needs to be done to prepare for it and how to shape it.

To perform your own scenario building exercise based on the trends and archetypes in this report, you can select an archetype and decide on a time frame (e.g., 10 or 20 years) and then use data on current trends, signals, and drivers to imagine how they might evolve under the archetype. Ensure your scenario is plausible, logically consistent, and addresses multiple trends or issues. We encourage you to be deliberate, challenge assumptions, and avoid bias. Give your scenario a compelling title that reflects its key themes.

To explore the implications of your scenario, you may want to identify stakeholders affected by your developments, factoring in characteristics such as gender, age, minority status, and roles in education (e.g., students, parents, teachers, policymakers). Think critically about how different groups might experience or respond to the scenario.

Going further, consider implications for specific aspects of education, such as different levels and sectors of education
## Futures wheel

The futures wheel is a tool to help you systematically map out the ripple effects of future scenarios, trends, or events on education systems and policies. It builds on the work of scholars in the field of strategic foresight and aims to identify potential impacts of alternative futures, implications for various stakeholder groups, and actions or policies that are needed to respond in the short and longer term. To develop a futures wheel suited to the context and concerns of your education system, you may follow these steps:

1. Choose a scenario, trend, or event from this report that challenges your assumptions about the future of your system or organisation.
2. Identify as many direct impacts as possible (first-order impacts).
3. Identify the direct impacts of each of the first-order impacts on your list (second-order impacts).
4. Repeat the process, identifying the direct impacts of the second-order impacts (third-order impacts).
5. Example: 

### Futures wheel example

json
{
  "Scenario/event/driver": "Planet has crossed multiple climate tipping points",
  "First-order impact": [
    "Reconstruction and redesign of education buildings",
    "Extreme weather causes crop failure",
    "Hunger among low-income families",
    "Expanded school meal programmes"
  ],
  "Second-order impact": [
    "Reduced staffing budget",
    "Teacher recruitment and retention challenges"
  ],
  "Third-order impact": [
    "Planet has crossed multiple climate tipping points"
  ]
}
```

### Figure 1.5. Futures wheel example

Futures wheel exploring first, second, and third-order impacts of ‘Climate catastrophe’ scenario in Chapter 1 (Global conflict and co-operation).

**Source:** Adapted from Save the Children UK, School of International Futures (2019), The Future is Ours: Strategic Foresight Toolkit - making better decisions, https://resourcecentre.savethechildren.net/document/future-ours-strategic-foresight-toolkit-making-better-decisions/ (accessed 15 November 2024).

```

Turning insights into action

- Which are the most significant implications for your education system?
- Which education stakeholders will be most affected by these implications, and who can best address them?
- What actions or policies need to be implemented in the short term?
- What actions or policies need to be implemented in the longer term?

Stress testing
Stress testing helps you assess the resilience of policies, strategies, or objectives by testing how they perform across different future scenarios. It aims to identify which plans are resilient across multiple scenarios, which policies work better in specific scenarios and could be priorities and how current plans could be adapted to make them robust across a range of possible futures. To stress test various policy options across a range of possible futures, you may follow these steps:
1. Identify key policies, strategies, or objectives that you want to stress test.
2. Select three contrasting scenarios from this report.
3. Evaluate each policy under the different scenarios. Is it robust, redundant, or does it need modification?
4. Reflect on the insights and decide on next steps using the questions provided.

Figure 1.6. Stress testing example

json
[
  {
    "Policy": "Policy option 1",
    "Future 1": "Works well",
    "Future 2": "Needs modification",
    "Future 3": "Doesn't work"
  },
  {
    "Policy": "Policy option 2",
    "Future 1": "Works well",
    "Future 2": "Works well",
    "Future 3": "Needs modification"
  },
  {
    "Policy": "Policy option 3",
    "Future 1": "Doesn't work",
    "Future 2": "Needs modification",
    "Future 3": "Works well"
  }
]
```

Source: Adapted from Save the Children UK, School of International Futures (2019), The Future is Ours: Strategic Foresight Toolkit - making better decisions, [Save the Children](https://resourcecentre.savethechildren.net/document/future-ours-strategic-foresight-toolkit-making-better-decisions/) (accessed 15 November 2024); UK Government Office for Science (2024), The Futures Toolkit, [UK Government](https://www.gov.uk/government/publications/futures-toolkit-for-policy-makers-and-analysts) (accessed 15 November 2024).
```
Turning insights into action
- Which plans are resilient across multiple scenarios?
- Which policies are tailored to specific scenarios and could be prioritized or prepared for?
- How can we adapt current plans to make them more robust for a range of possible futures?

Futures thinking resources
- Dator, J. (2009), “Alternative futures at the Manoa School”, Journal of Futures Studies, Vol. 14/2, [https://doi.org/10.1007/978-3-319-07809-0_5](https://doi.org/10.1007/978-3-319-07809-0_5).
- European Parliament, ESPAS (2024), Global Trends to 2040: Choosing Europe’s Future, Publications Office of the European Union, [https://op.europa.eu/en/publication-detail-/publication/848599a1-0901-11ef-a251-01aa7e5d71a1/language-en](https://op.europa.eu/en/publication-detail-/publication/848599a1-0901-11ef-a251-01aa7e5d71a1/language-en) (accessed 15 November 2024).
- Glenn, J. “The Futures Wheel”, Futures Research Methodology, The Millennium Project, [https://www.researchgate.net/publication/349335014_THE_FUTURES_WHEEL](https://www.researchgate.net/publication/349335014_THE_FUTURES_WHEEL) (accessed 1 December 2024).
- Hines, A. (2014), Fun with scenario archetypes, [https://www.andyhinesight.com/fun-with-scenario-archetypes/](https://www.andyhinesight.com/fun-with-scenario-archetypes/) (accessed 15 November 2024).
- Nolan, A. (2021), “Making life richer, easier and healthier: Robots, their future and the roles for public policy”, OECD Science, Technology and Industry Policy Papers, No. 117, OECD Publishing, Paris, [https://doi.org/10.1787/5ea15d01-en](https://doi.org/10.1787/5ea15d01-en) (accessed 16 December 2024).
- OECD (Forthcoming), A strategic foresight toolkit for resilient public policy.
- OECD (2024), OECD Digital Economy Outlook 2024 (Volume 1): Embracing the Technology Frontier, OECD Publishing, Paris, [https://doi.org/10.1787/16896dc5-en](https://doi.org/10.1787/16896dc5-en).
- OECD (2021), Global Scenarios 2035: Exploring Implications for the Future of Global Collaboration and the OECD, OECD Publishing, Paris, [https://doi.org/10.1787/d7ebc33-en](https://doi.org/10.1787/d7ebc33-en).
- OECD (2020), Back to the Future of Education: Four OECD Scenarios for Schooling, Educational Research and Innovation, OECD Publishing, Paris, [https://doi.org/10.1787/178ef527-en](https://doi.org/10.1787/178ef527-en).
- Save the Children UK, School of International Futures (2019), The Future is Ours: Strategic Foresight Toolkit - making better decisions, Save the Children UK, [https://resourcecentre.savethechildren.net/document/future-ours-strategic-foresight-toolkit-making-better-decisions/](https://resourcecentre.savethechildren.net/document/future-ours-strategic-foresight-toolkit-making-better-decisions/) (accessed 15 November 2024).
- Schultz, W. (2010), Futures Tools: Scanning, Futures Wheels, Verge, [https://www.slideshare.net/slideshow/futures-tools-scanning-futures-wheels-verge/5086915](https://www.slideshare.net/slideshow/futures-tools-scanning-futures-wheels-verge/5086915) (accessed 15 November 2024).
- Schultz, W. (2003), Scenario Archetypes, [http://www.infinitefutures.com/essays/prez/scenarch/index.htm](http://www.infinitefutures.com/essays/prez/scenarch/index.htm) (accessed 15 November 2024).
- UK Government Office for Science (2024), The Futures Toolkit, UK Government Office for Science, [https://www.gov.uk/government/publications/futures-toolkit-for-policy-makers-and-analysts](https://www.gov.uk/government/publications/futures-toolkit-for-policy-makers-and-analysts) (accessed 15 November 2024).
- US National Intelligence Council (2021), Global Trends 2040, US National Intelligence Council, [https://www.dni.gov/index.php/gt2040-home](https://www.dni.gov/index.php/gt2040-home) (accessed 15 November 2024).
```
The cost of global conflict

The rise in armed conflict and growing geopolitical tensions may spell the end of the ‘peace dividend’ that allowed many OECD countries to reduce defence spending after the Cold War. Direct conflicts between states are still rare but are becoming more frequent, and governments are increasingly providing military support in foreign conflicts. Education can promote the competencies needed to build a more peaceful world in the long term and plays a vital role in fostering resilience among those affected by war. With increased defence spending putting pressure on public finances, however, there is a risk that funding for areas like education will be squeezed.

Figure 2.1. Global conflict on the rise

State-based armed conflict by type, worldwide (1946-2022)

| Type                          | Number of Active Conflicts |
|-------------------------------|----------------------------|
| Extrasystemic                 | 0                          |
| Inter-state                   | 10                        |
| Internationalised intra-state  | 20                        |
| Intra-state                   | 60                        |

Source: Davies, Pettersson, and Oberg (2023), Organized violence 1989-2022 and the return of conflicts between states?, https://doi.org/10.1177/002234343321185169.

Russia’s invasion of Ukraine in 2022 sparked the first large-scale interstate war since the US-led invasion of Iraq in 2003. While this type of state-on-state conflict remains rare, it is becoming more common; there were as many interstate conflicts in the first three years of the 2020s as in the entire first decade of the 2000s. Even if states are not ‘at war’ in the traditional sense, their militaries may still be fighting in foreign conflicts. This is reflected in the steep increase in internationalised intrastate conflict, where foreign governments support one side in a domestic conflict between a state and non-state actors.

The rise in armed conflict and mounting geopolitical tensions have implications for public spending. After the Cold War, many governments reduced their share of spending on defence, creating space for spending on other priorities. Among OECD countries, average defence expenditure as a percentage of GDP fell from 3.07% in 1985 to 1.49% by 2021. There are already signs that the changing geopolitical climate is reversing this trend. Global military expenditure reached record levels in 2023 and several OECD countries have committed to further increases. If tensions continue to rise, countries will face the challenge of balancing security and defence spending with mounting pressures in other public policy areas, including education.

The costs of global conflict extend far beyond public spending. War not only results in the loss of lives and livelihoods but also has a profound and lasting impact on mental health and well-being, particularly for those affected.



vulnerable groups like children. It also disrupts the delivery of public services such as education, damaging infrastructure and forcing people from their homes. The resulting gaps in young people's learning can have a lasting impact on their personal and academic development. In today's hyperconnected world, the repercussions of conflict often spread beyond the regions directly affected, fuelling tensions in diaspora communities across the globe. The wave of campus protests linked to the evolving conflict in the Middle East since 2023 illustrates how distant wars can indirectly impact education institutions and how tensions can be amplified through social media.

These challenges underscore the role of education in fostering resilience among learners and providing them with a sense of security. This includes those who have been directly affected by war, but also children growing up in an increasingly conflict-ridden world. Moreover, education can nurture the knowledge, skills, attitudes and values that support cross-cultural co-operation and contribute to a more peaceful future.

**Figure 2.2. An end to the peace dividend?**

Average defence expenditure as a percentage of GDP, OECD countries (1988-2023)

Source: OECD calculations based on SIPRI (2024), SIPRI Military Expenditure Database, https://doi.org/10.55163/COGC9685.

**And education?**
- How might an increase in armed conflict at home or aboard affect students’ health, well-being, sense of hope and aspirations for the future? How could it affect educational experiences and the use of buildings and infrastructure (e.g., frequent safety drills, online learning during conflict, use of schools as emergency shelters)?
- How can education contribute to building and sustaining peace and supporting post-conflict recovery and reconciliation? What implications does this have for curriculum and teachers’ professional learning?
- As defence spending grows, there may be increased investment in strategic areas like science, technology, and cyber security. What are the implications for disciplines that are not seen as strategic?


**Demographics on the move**

Migration to OECD countries slowed during the COVID-19 pandemic, but has since rebounded, with asylum applications and labour migration on the rise. Conflict and persecution continue to be key drivers of humanitarian migration, and climate change threatens to displace larger numbers of people. Increased labour migration could help advanced economies alleviate labour shortages and demographic challenges, but rising anti-immigration sentiment complicates this political choice. If current migration flows continue, education and training policies will play a crucial role in ensuring that newcomers acquire the skills to participate fully in society. Education, alongside other public policies, also has a role to play in fostering social cohesion and respect for diversity.

### Figure 2.3. Labour migration and asylum applications on the rise

- **A. Permanent-type labour migration**: 
- **B. New asylum applications**, OECD countries (2013-2022)

json
{
  "LabourMigration": {
    "2013": 1.0,
    "2014": 1.1,
    "2015": 1.2,
    "2016": 1.1,
    "2017": 1.2,
    "2018": 1.2,
    "2019": 1.3,
    "2020": 1.0,
    "2021": 1.2,
    "2022": 1.4
  },
  "NewAsylumApplications": {
    "1990": 0.5,
    "1991": 0.5,
    "1992": 0.6,
    "1993": 0.7,
    "1994": 0.9,
    "1995": 1.0,
    "1996": 1.2,
    "1997": 1.5,
    "1998": 1.6,
    "1999": 1.8,
    "2000": 1.0,
    "2001": 1.2,
    "2002": 1.2,
    "2003": 1.3,
    "2004": 1.4,
    "2005": 1.5,
    "2006": 1.5,
    "2007": 1.6,
    "2008": 1.8,
    "2009": 1.5,
    "2010": 1.6,
    "2011": 1.4,
    "2012": 1.5,
    "2013": 1.6,
    "2014": 1.7,
    "2015": 1.6,
    "2016": 1.7,
    "2017": 1.8,
    "2018": 1.9,
    "2019": 2.0,
    "2020": 2.0,
    "2021": 2.1,
    "2022": 2.5
  }
}
```

**Note:** Labour migrants is an OECD classification for permanent-type migrants entering under economic or employment categories, excluding their accompanying family members; Asylum refers to first applications for protection registered by UNHCR.  
**Source:** OECD (2023), International Migration Outlook 2023, https://doi.org/10.1787/b040584-en.

The number of new asylum applications to OECD countries hit a record high in 2022, continuing the upward trend that began in the 2000s. On average, there were more than twice as many applications annually in the 2010s as in the 2000s – an increase of 134%. In the first three years of the 2020s (2020-2022), the number of applications was 39% higher than in the 2010s. Russia’s invasion of Ukraine led to the largest displacement of people in Europe since World War II, while ongoing conflicts and political crises in countries such as Afghanistan, Sudan, Syria, and Venezuela also contribute to the rising numbers of displaced people. With natural disasters already forcing millions of people from their homes every year, climate change is likely to become a significant driver of future displacement.

Permanent-type labour migration to OECD countries, which excludes workers on temporary and non-renewable arrangements, showed a similar pattern, increasing by 56% between 2019 and 2022. In countries such as Australia, Japan and Korea, the increase in labour migration between 2021 and 2022 meant a return to pre-pandemic levels. However, in most European and OECD countries and the United States, labour migration reached a 15-year record level in 2022. OECD countries such as Japan and Korea have increased targets for international migrants to address labour shortages and some have signed.
```
bilateral agreements to fill gaps in sectors like agriculture, care, and hospitality. Other countries, such as Canada, are starting to reduce their targets after accepting record inflows.

Targeted labour migration policies could alleviate demographic pressures in ageing societies. In OECD countries, the ratio of older dependents to the working-age population doubled from 14 dependents per 100 people in 1960 to 28 in 2022. Countries such as Japan and Italy have seen particularly sharp increases. Migrants, who are typically younger than the native-born population, could help slow this trend, easing pressure on pension systems and stimulating growth, even if migrants themselves obviously also age. Many countries with acute demographic pressures face rising anti-immigration sentiment, with some governments seeking to reduce overall immigration numbers. While not all OECD countries will see higher immigration, providing migrants and refugees of all ages with education and training that meets their needs will remain a priority for many. Education can also promote appreciation for diversity among the host population. This can support the inclusion of newcomers in national education systems and may also help to shift attitudes towards immigrants.

And education?
- What can education systems do to meet the needs of migrant children? How can they recognise adult migrants’ aspirations and prior experiences while meeting local labour demands and offering relevant reskilling and upskilling opportunities?
- What role can education play in promoting respect for diversity and challenging stereotypes? How can education institutions foster inclusive attitudes and address prejudice?
- International migration is increasingly multi-directional, with many people moving between multiple countries. How can governments collaborate to support education for people on the move (e.g., by improving alignment between systems, using digital technologies)?


**Image:**
```
Figure 2.4. Diverging dependencies
Age-dependency ratios, OECD and selected countries (1960-2022)

Age-dependency refers to the ratio of older dependents to the working-age population.
Source: World Bank (2024), “Age dependency ratio, old”, https://data.worldbank.org/indicator/SP.POP.DPND.OL.
```

**Table Conversion:**
```json
{
  "Diverging dependencies": {
    "Years": [1960, 1965, 1970, 1975, 1980, 1985, 1990, 1995, 2000, 2005, 2010, 2015, 2020, 2022],
    "Japan": [10, 12, 13, 15, 17, 20, 22, 24, 25, 26, 27, 30, 32, 35],
    "Italy": [8, 10, 12, 14, 15, 18, 20, 24, 28, 30, 32, 34, 38, 40],
    "OECD countries": [14, 15, 16, 17, 18, 20, 21, 23, 25, 26, 27, 29, 30, 32],
    "Middle-income countries": [12, 13, 14, 15, 16, 18, 19, 21, 22, 23, 25, 26, 29, 31],
    "Low-income countries": [4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 16, 18, 20, 22]
  }
}
```# Changing dynamics of global trade

In the era of ‘hyper-globalisation’ that began in the 1990s, global trade grew rapidly, driven by the rise of global value chains. This momentum has slowed since the 2008 Global Financial Crisis, leading to talk of a ‘de-globalisation’ trend. Recent years have also seen an increase in trade restrictions due to geopolitical tensions, while the rise of populist and nationalist movements reflects growing discontent with the consequences of globalisation. At the same time, trade in services continues to thrive, with digitalisation boosting trade. How can education help shape and implement a global economic order that benefits individuals and communities worldwide?

## Figure 2.5. Global trade slowing, restrictions rising

**Average global trade as a share of GDP; global trade restrictions (2009-2022)**

| Year   | Average global exports and imports/GDP (left axis) | Harmful trade interventions (right axis) |
|--------|-----------------------------------------------------|-------------------------------------------|
| 2009   | 60                                                  | 400                                       |
| 2010   | 64                                                  | 136                                       |
| 2011   | 65                                                  | 190                                       |
| 2012   | 63                                                  | 232                                       |
| 2013   | 61                                                  | 236                                       |
| 2014   | 60                                                  | 290                                       |
| 2015   | 58                                                  | 340                                       |
| 2016   | 57                                                  | 396                                       |
| 2017   | 58                                                  | 528                                       |
| 2018   | 59                                                  | 693                                       |
| 2019   | 58                                                  | 800                                       |
| 2020   | 56                                                  | 1000                                      |
| 2021   | 52                                                  | 1000                                      |
| 2022   | 50                                                  | 1200                                      |

(Counts estimated from visual representation in figure)

> Note: Harmful trade interventions, as defined by the Global Trade Alert, disadvantage foreign commercial interests compared to domestic ones.  
> Source: World Bank (2024), [World Development Indicators](https://data.worldbank.org/indicator/NE.TRD.GNFS.ZS); Global Trade Alert (2024), [Global Trade Alert](https://www.globaltradealert.org/global_dynamics/day-to-0515flow_all).

Following a period of ‘hyper-globalisation’ that began in the 1990s, international trade has slowed since the 2008 Global Financial Crisis. Global trade as a share of GDP grew rapidly from 1990 to 2008. This reflects the rise of global value chains (GVCs), which involve breaking the production process into different stages, with each stage carried out in different countries. Since 2009, however, trade growth has stalled, and restrictions have increased. The number of policies disadvantaging foreign commercial interests compared to domestic ones rose from 136 in 2010 to 364 in 2023, partly driven by geopolitical tensions.

At the same time, some aspects of trade globalisation continue to expand. Trade in services has grown during recent crises and GVC activity remains high. Digitalisation has reduced trade costs and connected businesses and customers worldwide. One of the fastest-growing sectors is digital trade, including digitally delivered goods and services (e.g., music and movie streaming, online learning), as well as physical goods and services ordered online. Digitally delivered services grew by an average of 8.1% annually from 2005 to 2022, now comprising 54% of all services exports.

While international trade has driven prosperity and lowered consumer prices, it has also disrupted industries and displaced jobs, fuelling anti-globalisation sentiment (often exploited by nationalist and populist movements) and raising significant questions about the future of international trade. The need for...
to mitigate climate change and reduce carbon footprints may also lead some countries to focus on local production and more regionalised trade.

The shifting dynamics of global trade are affecting the demand for labour and skills, challenging education and training systems to reflect these shifts in their curricula, qualifications and pathways. Increased connectivity can drive the benefits of digital trade, but consumers need digital literacy to get online and businesses need technical and entrepreneurial skills to innovate. Ensuring equitable access to quality education can equip people of all ages and backgrounds with the knowledge and skills they need to engage with changes in the labour market. Beyond this, education has a crucial role to play in equipping people to challenge inequalities and imagine a global economic order that benefits everyone.

### Figure 2.6. The digital dynamics of trade

json
{
  "title": "Growth in digital and non-digital trade (1995-2020)",
  "data": {
    "years": [
      1995, 1996, 1997, 1998, 1999, 2000, 2001,
      2002, 2003, 2004, 2005, 2006, 2007, 2008,
      2009, 2010, 2011, 2012, 2013, 2014, 2015,
      2016, 2017, 2018, 2019, 2020
    ],
    "other_trade": [
      100, 200, 300, 400, 400, 500,
      400, 450, 450, 500, 550, 600,
      580, 570, 570, 580, 600, 590,
      580, 580, 580, 570, 570, 570,
      570, 550
    ],
    "digital_trade": [
      100, 150, 200, 230, 250, 300,
      320, 370, 410, 460, 520, 560,
      570, 580, 590, 600, 610, 620,
      630, 640, 650, 660, 670, 680,
      690, 700
    ],
    "source": "López, Sorescu and Kaynak (2023)"
  }
}
```

And education?
- How might a continued slowdown in goods trade and a shift to services and digital trade affect the demand for labour and skills? How can education adapt to ensure people of all ages and backgrounds have the necessary skills?
- What do young people learn about trade and globalisation in a context where both are increasingly contested? How could education help them imagine a global economic order that works for all?
- While talk of ‘de-globalisation’ may be premature, trade shifts and emissions reduction measures may localise production and consumption. How can education equip communities with the skills and resources to manage and sustain essential needs like energy and food? What might a more locally focused professional education look like?
```Sure! Here’s the conversion of the PDF content to Markdown following your specified rules:


Energy security

Global shocks such as the COVID-19 pandemic and Russia’s invasion of Ukraine have affected energy supply. Prices rose sharply between 2021 and 2022 and remain above those seen in the early 2000s, meaning that households, businesses, and public services including education may face higher energy costs for years to come. These crises have highlighted the need for resilient energy systems, prompting countries to increase investment in clean energy as they seek to protect themselves from future shocks and meet climate goals. Education is key to achieving this energy transition, supplying the right skills, fostering technological innovation, and creating new opportunities for people transitioning out of the fossil fuel industry.

Figure 2.7. An energy shock  
Global Price of Energy Index (1992-2024)  

json
{
  "data": {
    "years": [1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023],
    "global_price_index": [100, 120, 140, 150, 160, 170, 175, 180, 185, 190, 195, 210, 220, 240, 260, 280, 300, 290, 350, 370, 380, 390, 360, 330, 100, 110, 115, 120, 200, 350, 400, 390]
  }
}
```

Note: July 2016 = 100. Values are for each month between January 1992 and December 2023.  
Source: IMF (2024), All Commodity Price Index, https://data.imf.org/?sk=471dd1d8-d87a-499a-81ba-5b332c01f8b9

The early 2020s were marked by a significant spike in energy prices. The outbreak of the COVID-19 pandemic led to persistent supply-chain disruptions, while the lifting of lockdown restrictions was followed by a surge in demand. Russia’s invasion of Ukraine triggered further limitations on energy supply, notably supplies of oil and gas. Gas and electricity prices in Europe and Asia reached historic highs in 2022, and gas prices in the US tripled at their peak. This energy shock has driven inflation and contributed to a cost-of-living crisis that weighs heaviest on lower earners. Although energy prices have declined since their 2022 peak, they remain higher than before the pandemic and higher than before the 2008 Global Financial Crisis. This raises the question of whether the lower prices seen in the 1990s and early 2000s are a thing of the past.

Recent crises have highlighted vulnerabilities in countries’ energy supply chains and accelerated efforts to diversify energy sources. Investment in clean energy was already increasing before 2020 and overtook fossil fuel investment in 2016. This shift reflects growing awareness of the need for action on climate change, but also factors like the increasing competitiveness of renewables compared to fossil fuels. Government support has also played a key role, with COVID-19 recovery packages and green growth initiatives in economies such as the United States, the European Union (EU), China, and Japan providing...
```

If you have more content or specific sections you would like converted, feel free to share!
a further boost to investment. Global clean energy investment increased by almost 30% between 2020 and 2022. However, this growth has been led by advanced economies and China, and fossil fuel investment still outstrips clean energy investment in some world regions.

If the era of cheap energy is over, schools and other places of learning will face increasing demands on their budgets, with energy bills draining resources that could be used on staff or learning materials. While several governments provided short-term support to help schools absorb the recent energy shock, improving the energy efficiency of education buildings will help to reduce spending in the long-term and improve sustainability. Education also has a key role to play in achieving a fast and fair energy transition by supplying the skills and innovations for a diverse energy sector while giving workers in the fossil fuel industry opportunities to upskill or reskill.

json
{
  "title": "Figure 2.8. The energy transition",
  "description": "Global investment in clean energy and fossil fuels (2015-2023)",
  "data": {
    "years": [2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023],
    "clean_energy": [1200, 1250, 1300, 1350, 1400, 1600, 1700, 1800, 1900],
    "fossil_fuels": [1000, 950, 900, 850, 820, 800, 780, 750, 720]
  }
}
```

And education?
- How can educational infrastructure be made resilient against rising energy costs and future supply-chain shocks? What mechanisms could ensure adequate funding to modernise education facilities, improve energy efficiency, and ensure sustainability?
- The cost-of-living crisis affects educators as well as students. What measures could mitigate the impact of future shocks on their quality of life?
- What education and training programmes are necessary to equip learners with the skills needed for the energy transition? What targeted measures could support the reskilling and upskilling of people transitioning out of the fossil fuel industry?
```

Co-operation on climate change
As heatwaves, floods, wildfires and other extreme weather events become more frequent and severe, the impacts of climate change are increasingly disrupting lives and draining resources. Addressing this global challenge requires international co-operation, and countries have increasingly joined forces through multilateral treaties like the Paris Agreement. However, current policies and commitments fall far short of what is needed to avoid the worst impacts of climate change. Additionally, some climate impact is already inevitable, meaning the education sector must adapt to a world where extreme weather is the new normal.

Figure 2.9. Burning up
Percentage of population exposed to maximum temperatures exceeding 35°C annually, OECD and OECD partner countries (1979-2022)

json
{
  "data": [
    {"year": 1979, "from_2_to_4_weeks": 25, "from_4_to_6_weeks": 0, "from_6_to_8_weeks": 0, "over_8_weeks": 0},
    {"year": 1980, "from_2_to_4_weeks": 26, "from_4_to_6_weeks": 0, "from_6_to_8_weeks": 0, "over_8_weeks": 0},
    {"year": 1981, "from_2_to_4_weeks": 27, "from_4_to_6_weeks": 0, "from_6_to_8_weeks": 0, "over_8_weeks": 0},
    {"year": 1982, "from_2_to_4_weeks": 26, "from_4_to_6_weeks": 0, "from_6_to_8_weeks": 0, "over_8_weeks": 0},
    {"year": 1983, "from_2_to_4_weeks": 28, "from_4_to_6_weeks": 0, "from_6_to_8_weeks": 0, "over_8_weeks": 0},
    {"year": 1984, "from_2_to_4_weeks": 29, "from_4_to_6_weeks": 0, "from_6_to_8_weeks": 0, "over_8_weeks": 0},
    {"year": 1985, "from_2_to_4_weeks": 27, "from_4_to_6_weeks": 0, "from_6_to_8_weeks": 0, "over_8_weeks": 0},
    {"year": 1986, "from_2_to_4_weeks": 29, "from_4_to_6_weeks": 0, "from_6_to_8_weeks": 0, "over_8_weeks": 0},
    {"year": 1987, "from_2_to_4_weeks": 28, "from_4_to_6_weeks": 0, "from_6_to_8_weeks": 0, "over_8_weeks": 0},
    {"year": 1988, "from_2_to_4_weeks": 30, "from_4_to_6_weeks": 0, "from_6_to_8_weeks": 0, "over_8_weeks": 0},
    {"year": 1989, "from_2_to_4_weeks": 31, "from_4_to_6_weeks": 0, "from_6_to_8_weeks": 0, "over_8_weeks": 0},
    {"year": 1990, "from_2_to_4_weeks": 32, "from_4_to_6_weeks": 0, "from_6_to_8_weeks": 0, "over_8_weeks": 0},
    {"year": 1991, "from_2_to_4_weeks": 35, "from_4_to_6_weeks": 0, "from_6_to_8_weeks": 0, "over_8_weeks": 0},
    {"year": 1992, "from_2_to_4_weeks": 36, "from_4_to_6_weeks": 0, "from_6_to_8_weeks": 0, "over_8_weeks": 0},
    {"year": 1993, "from_2_to_4_weeks": 37, "from_4_to_6_weeks": 1, "from_6_to_8_weeks": 0, "over_8_weeks": 0},
    {"year": 1994, "from_2_to_4_weeks": 34, "from_4_to_6_weeks": 0, "from_6_to_8_weeks": 1, "over_8_weeks": 0},
    {"year": 1995, "from_2_to_4_weeks": 38, "from_4_to_6_weeks": 1, "from_6_to_8_weeks": 1, "over_8_weeks": 0},
    {"year": 1996, "from_2_to_4_weeks": 31, "from_4_to_6_weeks": 0, "from_6_to_8_weeks": 1, "over_8_weeks": 0},
    {"year": 1997, "from_2_to_4_weeks": 29, "from_4_to_6_weeks": 1, "from_6_to_8_weeks": 0, "over_8_weeks": 0},
    {"year": 1998, "from_2_to_4_weeks": 30, "from_4_to_6_weeks": 1, "from_6_to_8_weeks": 1, "over_8_weeks": 0},
    {"year": 1999, "from_2_to_4_weeks": 31, "from_4_to_6_weeks": 1, "from_6_to_8_weeks": 1, "over_8_weeks": 0},
    {"year": 2000, "from_2_to_4_weeks": 33, "from_4_to_6_weeks": 1, "from_6_to_8_weeks": 1, "over_8_weeks": 0},
    {"year": 2001, "from_2_to_4_weeks": 36, "from_4_to_6_weeks": 2, "from_6_to_8_weeks": 1, "over_8_weeks": 0},
    {"year": 2002, "from_2_to_4_weeks": 38, "from_4_to_6_weeks": 2, "from_6_to_8_weeks": 1, "over_8_weeks": 1},
    {"year": 2003, "from_2_to_4_weeks": 41, "from_4_to_6_weeks": 3, "from_6_to_8_weeks": 1, "over_8_weeks": 1},
    {"year": 2004, "from_2_to_4_weeks": 36, "from_4_to_6_weeks": 3, "from_6_to_8_weeks": 2, "over_8_weeks": 1},
    {"year": 2005, "from_2_to_4_weeks": 40, "from_4_to_6_weeks": 4, "from_6_to_8_weeks": 3, "over_8_weeks": 1},
    {"year": 2006, "from_2_to_4_weeks": 39, "from_4_to_6_weeks": 4, "from_6_to_8_weeks": 3, "over_8_weeks": 1},
    {"year": 2007, "from_2_to_4_weeks": 38, "from_4_to_6_weeks": 5, "from_6_to_8_weeks": 3, "over_8_weeks": 2},
    {"year": 2008, "from_2_to_4_weeks": 37, "from_4_to_6_weeks": 6, "from_6_to_8_weeks": 4, "over_8_weeks": 2},
    {"year": 2009, "from_2_to_4_weeks": 36, "from_4_to_6_weeks": 7, "from_6_to_8_weeks": 4, "over_8_weeks": 2},
    {"year": 2010, "from_2_to_4_weeks": 35, "from_4_to_6_weeks": 6, "from_6_to_8_weeks": 5, "over_8_weeks": 2},
    {"year": 2011, "from_2_to_4_weeks": 34, "from_4_to_6_weeks": 7, "from_6_to_8_weeks": 5, "over_8_weeks": 2},
    {"year": 2012, "from_2_to_4_weeks": 33, "from_4_to_6_weeks": 8, "from_6_to_8_weeks": 5, "over_8_weeks": 2},
    {"year": 2013, "from_2_to_4_weeks": 32, "from_4_to_6_weeks": 9, "from_6_to_8_weeks": 6, "over_8_weeks": 3},
    {"year": 2014, "from_2_to_4_weeks": 31, "from_4_to_6_weeks": 9, "from_6_to_8_weeks": 6, "over_8_weeks": 3},
    {"year": 2015, "from_2_to_4_weeks": 30, "from_4_to_6_weeks": 10, "from_6_to_8_weeks": 6, "over_8_weeks": 3},
    {"year": 2016, "from_2_to_4_weeks": 30, "from_4_to_6_weeks": 10, "from_6_to_8_weeks": 7, "over_8_weeks": 3},
    {"year": 2017, "from_2_to_4_weeks": 29, "from_4_to_6_weeks": 11, "from_6_to_8_weeks": 7, "over_8_weeks": 3},
    {"year": 2018, "from_2_to_4_weeks": 28, "from_4_to_6_weeks": 12, "from_6_to_8_weeks": 8, "over_8_weeks": 3},
    {"year": 2019, "from_2_to_4_weeks": 27, "from_4_to_6_weeks": 13, "from_6_to_8_weeks": 8, "over_8_weeks": 3},
    {"year": 2020, "from_2_to_4_weeks": 26, "from_4_to_6_weeks": 14, "from_6_to_8_weeks": 8, "over_8_weeks": 4},
    {"year": 2021, "from_2_to_4_weeks": 25, "from_4_to_6_weeks": 15, "from_6_to_8_weeks": 9, "over_8_weeks": 4},
    {"year": 2022, "from_2_to_4_weeks": 24, "from_4_to_6_weeks": 16, "from_6_to_8_weeks": 9, "over_8_weeks": 5}
  ]
}
```

Climate change is already shaping the way we live, with extreme weather events being more frequent and devastating. In OECD and partner countries, the share of people experiencing over two weeks of hot days annually was about 45% higher in the period 2013-2022 than in 1983-1992. In early 2024, each month over the past year had set a new temperature record, with heatwaves, floods, and hurricanes causing widespread disruptions. 

The costs of climate change are escalating, with average daily economic losses from weather, climate, and water extremes almost eight times higher in the 2010s than in the 1970s.

Climate change poses a global threat to lives, livelihoods, and social and economic stability. Although it affects countries differently, all contribute to it in various degrees. Addressing climate change thus requires coordinated international action and increasing climate co-operation.

The number of international climate policies adopted by OECD and partner countries grew between 2013 and 2022, with many becoming more stringent. This includes treaties like the Paris Agreement, creating shared understanding and identifying solutions, alongside international public finance and reporting frameworks to measure progress.

However, climate action is diverging across countries, with geopolitical and economic shocks leading some governments to backtrack on environmental commitments while others strengthen their climate policies.
```
### Figure 2.10. Joining forces
Implementation of international climate policies, OECD and OECD partner countries (2010-2022)

json
{
  "data": [
    {
      "year": 2010,
      "number_of_adopted_policies": 50,
      "average_policy_stringency": 1
    },
    {
      "year": 2011,
      "number_of_adopted_policies": 75,
      "average_policy_stringency": 1
    },
    {
      "year": 2012,
      "number_of_adopted_policies": 100,
      "average_policy_stringency": 2
    },
    {
      "year": 2013,
      "number_of_adopted_policies": 150,
      "average_policy_stringency": 2
    },
    {
      "year": 2014,
      "number_of_adopted_policies": 175,
      "average_policy_stringency": 3
    },
    {
      "year": 2015,
      "number_of_adopted_policies": 200,
      "average_policy_stringency": 4
    },
    {
      "year": 2016,
      "number_of_adopted_policies": 225,
      "average_policy_stringency": 5
    },
    {
      "year": 2017,
      "number_of_adopted_policies": 250,
      "average_policy_stringency": 5
    },
    {
      "year": 2018,
      "number_of_adopted_policies": 275,
      "average_policy_stringency": 6
    },
    {
      "year": 2019,
      "number_of_adopted_policies": 300,
      "average_policy_stringency": 6
    },
    {
      "year": 2020,
      "number_of_adopted_policies": 325,
      "average_policy_stringency": 7
    },
    {
      "year": 2021,
      "number_of_adopted_policies": 340,
      "average_policy_stringency": 6
    },
    {
      "year": 2022,
      "number_of_adopted_policies": 350,
      "average_policy_stringency": 7
    }
  ]
}
```

And education?
- How is the role of education addressed in national and international climate policies? How are these policies aligned with education goals and curricula? 
- What role can learners and education staff play in climate adaptation and resilience? What training and other resources could support them in this role? 
- What infrastructure investments are needed to ensure that education institutions are resilient to climate impacts and can support the resilience of the communities around them? How can governments prioritise funding to education institutions in areas most vulnerable to extreme weather events?
```
Global science collaboration and technological innovation

Scientific and technological breakthroughs can contribute to addressing a range of global social, economic, and environmental challenges, but they rely on international exchange of knowledge, resources, and talent. While scientific collaboration has grown, geopolitical tensions and trade dependencies on critical raw materials pose risks to innovation and sustainability. The COVID-19 pandemic demonstrated the value of global science partnerships, but concerns over research security are rising. Education plays a crucial role in building ethical frameworks, shared goals, and skills to ensure scientific and technological progress benefits humanity and the planet while safeguarding collaboration and security.

### Figure 2.11. Rising research collaboration

Percentage of scientific publications involving international co-authorships, OECD (2008 and 2022)

| Year | Japan | USA | Mexico | Italy | UK | South Korea | Spain | France | Germany | China | Brazil | Canada | Australia | Sweden | Norway | Netherlands | Belgium | Luxembourg | Ireland |
|------|-------|-----|--------|-------|----|-------------|-------|--------|---------|-------|--------|--------|-----------|--------|--------|--------------|---------|------------|---------|
| 2008 | 30    | 35  | 25     | 28    | 30 | 33          | 27    | 30     | 31      | 22    | 20     | 22     | 35        | 28     | 32     | 30           | 29      | 26         | 27      |
| 2022 | 40    | 50  | 40     | 45    | 48 | 50          | 43    | 50     | 52      | 40    | 35     | 37     | 55        | 50     | 45     | 45           | 44      | 42         | 42      |

**Note:** OECD calculations based on Scopus Custom Data, Elsevier, Version 1.2024, April 2024  
**Source:** OECD (2024), Science, Technology and Innovation Scoreboard (Database), [OECD Source](https://www.oecd.org/en/data/datasets/science-technology-and-innovation-scoreboard.html).

Scientific and technological discoveries needed to tackle global challenges like climate change, public health, and food security depend on the global exchange of knowledge, talent, resources, and infrastructure. This became clear during the COVID-19 pandemic, when open data-sharing platforms and research partnerships accelerated progress in diagnosis, treatment, and vaccinations. Between 2008 and 2022, the percentage of scientific publications involving international collaboration increased in most OECD countries, underscoring the key role that global co-operation plays in advancing human knowledge.

In addition, many OECD economies depend on imports to achieve strategic goals in areas like security, health, and the digital and green transitions. For example, raw materials essential for green technologies are concentrated in specific regions. China supplies some 60% of global graphite, crucial for electric vehicle batteries, and is also dominant in the processing of many critical materials. The Democratic Republic of Congo provides around 70% of the world’s cobalt, critical for batteries, fuel cells, and wind energy. Export restrictions on these materials have risen sharply since 2009, driving up costs and limiting access, while geopolitical tensions exacerbate these risks.

Shifting geopolitical dynamics also have implications for international research collaboration. During the COVID-19 crisis, researchers from different countries collaborated regardless of the geopolitical and economic context.
```
Concerns are growing about risks from foreign governments or non-state actors interfering in research in ways that threaten economic or national security. Such risks include international property theft, confidentiality breaches in peer review, and the coercion of overseas researchers. This raises the challenge of ensuring research security—with measures that protect research ecosystems and national interests—while also allowing open scientific collaboration and academic freedom to thrive. Education also has a critical role to play in fostering the ethical frameworks, shared goals, and skills necessary to ensure scientific and technological advances benefit both humanity and the planet.

**Figure 2.12. Export restrictions on critical raw materials are increasing**
- Global export restrictions on raw materials critical to the green transition (2009-2020)

json
{
  "data": [
    {"year": 2009, "count": 2000},
    {"year": 2010, "count": 4000},
    {"year": 2011, "count": 6000},
    {"year": 2012, "count": 7000},
    {"year": 2013, "count": 8000},
    {"year": 2014, "count": 9000},
    {"year": 2015, "count": 10000},
    {"year": 2016, "count": 11000},
    {"year": 2017, "count": 12000},
    {"year": 2018, "count": 13000},
    {"year": 2019, "count": 14000},
    {"year": 2020, "count": 14000}
  ]
}
```

Note: The count of all types of measures in place across all covered raw materials and all implementing countries consider the stock of measures at the beginning of the period as well as new additions and eliminations. 

And education?
- Science, technology, engineering, and mathematics fields are vital for addressing the climate crisis and other global challenges, but they can’t drive the necessary social and economic transformations alone. What other skills and knowledge are needed, and how can education across all disciplines support these transformations?
- Geopolitical tensions increase pressure on higher education institutions to limit research collaborations and international student entry. How does this affect institutional finances? How can governments balance open collaboration with protective but restrictive regulations?
- How can education foster critical thinking and ethics to address the environmental and social trade-offs of technological advancements, such as e-waste and resource dependency?
```
This work is published under the responsibility of the Secretary-General of the OECD. The opinions expressed and arguments employed herein do not necessarily reflect the official views of the Member countries of the OECD.

This document, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

The statistical data for Israel are supplied by and under the responsibility of the relevant Israeli authorities. The use of such data by the OECD is without prejudice to the status of the Golan Heights, East Jerusalem and Israeli settlements in the West Bank under the terms of international law.

Please cite this publication as:
OECD (2025), Trends Shaping Education 2025, OECD Publishing, Paris, https://doi.org/10.1787/ee6587fd-en.

ISBN 978-92-64-97862-5 (print)  
ISBN 978-92-64-74933-7 (PDF)  
ISBN 978-92-64-51003-6 (HTML)  

Trends Shaping Education  
ISSN 2218-7030 (print)  
ISSN 2218-7049 (online)  

Photo credits: Cover © MemoryMan/Shutterstock.com.

Corrigenda to OECD publications may be found at: https://www.oecd.org/en/publications/support/corrigenda.html.

© OECD 2025

Attribution 4.0 International (CC BY 4.0)
This work is made available under the Creative Commons Attribution 4.0 International licence. By using this work, you accept to be bound by the terms of this licence (https://creativecommons.org/licenses/by/4.0/).  
**Attribution** – you must cite the work.  
**Translations** – you must cite the original work, identify changes to the original and add the following text: *In the event of any discrepancy between the original work and the translation, only the text of original work should be considered valid.*  
**Adaptations** – you must not cite the original work and add the following text: *This is an adaptation of an original work by the OECD. The opinions expressed and arguments employed in this adaptation should not be reported as representing the official views of the OECD or of its Member countries.*  
**Third-party material** – the license does not apply to third-party material in the work. If using such material, you are responsible for obtaining permission from the third party for any claims of infringement.  
You must not use the OECD logo, visual identity or cover image without express permission or suggest the OECD endorses your use of the work. Any dispute arising under this licence shall be settled by arbitration in accordance with the Permanent Court of Arbitration (PCA) Arbitration Rules 2012. The seat of arbitration shall be Paris (France). The number of arbitrators shall be one.


Notes and sources

1. Davies, S., T. Pettersson and M. Öberg (2023), “Organized violence 1989–2022, and the return of conflict between states”, Journal of Peace Research, Vol. 60/4, pp. 691-708, https://doi.org/10.1177/00223433231185169.

2. SIPRI (2024), SIPRI Military Expenditure Database, Stockholm International Peace Research Institute, https://doi.org/10.55163/cggc9685.

3. OECD (2023), International Migration Outlook 2023, OECD Publishing, Paris, https://doi.org/10.1787/bf040584-en.

4. IDMC (2024), Global Internal Displacement Database, https://www.internal-displacement.org/database/displacement-data/.

5. OECD (2023), International Migration Outlook 2023, OECD Publishing, Paris, https://doi.org/10.1787/bf040584-en.

6. World Bank (2024), “Age dependency ratio, old” (indicator), https://data.worldbank.org/indicator/SP.POP.DPND.OL?locations=OE-XM-EU-US-JP-XP.

7. Peri, G. (2020), Immigrant Swan Song, https://www.imf.org/en/Publications/fandd/issues/2020/03/can-immigration-solve-the-demographic-dilemma-peri.

8. World Bank (2024), “Trade (% of GDP, indicator)”, https://data.worldbank.org/indicator/NE.TRD.GNFS.ZS (accessed 27 September 2024).

9. Global Trade Alert (2024), Global Trade Alert (database), https://www.globaltradealert.org/global_dynamics/day-to-0515/flow_all (accessed 15 October 2024).

10. IMF et al. (2023), Digital Trade for Development, WTO Publications, https://www.wto.org/english/res_e/booksp_e/tdt2023_e.pdf.

11. Mansfield, E. and J. Pevehouse (2022), “Nationalism, Populism, and Trade Agreements”, International Studies Review, Vol. 24, https://doi.org/10.1093/isr/v iac016.

12. Hemmertlé, Y. et al. (2023), “Aiming better: Government support for households and firms during the energy crisis”, OECD Economic Policy Papers, No. 32, OECD Publishing, Paris, https://doi.org/10.1787/839e3ae1-en.

13. IMF (2024), All Commodity Price Index (indicator), https://data.imf.org/?sk=471ddd8f-d8a7-499a-81ba-5b332c01f8b9 (accessed 30 September 2024).

14. IEA (2024), World Energy Investment 2024, IEA, https://www.iea.org/reports/world-energy-investment-2024.

15. OECD (2023), The Climate Action Monitor 2023: Providing Information to Monitor Progress Towards Net-Zero, OECD Publishing, Paris, https://doi.org/10.1787/60e338a2-en.
```
16 Copernicus (2024), May 2024 marks 12 months of record-breaking global temperatures, https://climate.copernicus.eu/may-2024-marks-12-months-record-breaking-global-temperatures.

17 WMO (2021), WMO Atlas of Mortality and Economic Losses from Weather, Climate, and Water Extremes, WMO, Geneva, https://library.wmo.int/index.php?lvl=notice_display&id=21930#.YS9CMNMzZBx.

18 Nachtigall, D. et al. (2022), “The climate actions and policies measurement framework: A structured and harmonised climate policy database to monitor countries’ mitigation action”, OECD Environment Working Papers, No. 203, OECD Publishing, Paris, https://doi.org/10.1787/60e338a60ce-en.

19 OECD (2023), The Climate Action Monitor 2023: Providing Information to Monitor Progress Towards Net-Zero, OECD Publishing, Paris, https://doi.org/10.1787/60e338a2-en.

20 OECD (forthcoming), Empowered Citizens, Informed Consumers and Skilled Workers: Designing Education and Skills Policies for a Sustainable Future, OECD Publishing, Paris.

21 OECD (2022), "Integrity and security in the global research ecosystem", OECD Science, Technology and Industry Policy Papers, No. 130, OECD Publishing, Paris, https://doi.org/10.1787/1c416f43-en; OECD (2024), Science, Technology and Innovation Scoreboard (Database), https://www.oecd.org/en/data/datasets/science-technology-and-innovation-scoreboard.html.

22 Kowalski, P. and C. Legendre (2023), “Raw materials critical for the green transition: Production, international trade and export restrictions”, OECD Trade Policy Papers, No. 269, OECD Publishing, Paris, https://doi.org/10.1787/6bb598b-en.

23 OECD (2022), "Integrity and security in the global research ecosystem", OECD Science, Technology and Industry Policy Papers, No. 130, OECD Publishing, Paris, https://doi.org/10.1787/1c416f43-en.

24 OECD (2022), "Integrity and security in the global research ecosystem", OECD Science, Technology and Industry Policy Papers, No. 130, OECD Publishing, Paris, https://doi.org/10.1787/1c416f43-en.

TRENDS SHAPING EDUCATION 2025 © OECD 2025
# Work and Progress

This chapter examines how the combined influence of technological advancements, sustainability imperatives, and the lingering influence of the COVID-19 pandemic are transforming the world of work and other social interactions. Technological changes are redefining the very nature of work, including the balance between work and other areas of life, with many seeking greater flexibility and sense of purpose. Labour-market changes related to the green and digital transitions, while still modest overall, are concentrated in specific regions, disrupting local labour markets, and leading to skills mismatches. While offering opportunities for sustainable sectoral and systems change, if unmanaged, these transformations can also exacerbate and add to existing inequalities along social, demographic, and economic lines. Observed shifts are not linear, with progress on gender equality and sustainable behaviours showing both advances and setbacks. These developments challenge education systems to find new ways to support resilience and agility in the face of uncertainty, assisting people in their quest for self-actualisation, while ensuring that the skills they develop are relevant for the future and no one is left behind.

## Diagram

### Education on a Fragile Planet
- **Global Conflict and Co-operation**
- **Work and Progress**
- **Voices and Storytelling**
- **Bodies and Minds**

### Learning in an AI-driven World
- Skill over: mastering the twin transition
- A balancing act: young adults and society in transition
- Them that’s got shall get: economic inequality
- Yes we can? Uneven gender perceptions, participation, and rights
- Home and away: digital dynamics in life and work
- Changing our ways: towards sustainable living

---

**Table: Learning in an AI-driven World**

```json
[
    {
        "Topic": "Skill over: mastering the twin transition"
    },
    {
        "Topic": "A balancing act: young adults and society in transition"
    },
    {
        "Topic": "Them that’s got shall get: economic inequality"
    },
    {
        "Topic": "Yes we can? Uneven gender perceptions, participation, and rights"
    },
    {
        "Topic": "Home and away: digital dynamics in life and work"
    },
    {
        "Topic": "Changing our ways: towards sustainable living"
    }
]
```
# Infographic 3.1. Work and Progress – Chapter highlights

## Mastering the Twin Transition
- **2023:** X2
- **2016:** The share of AI talents has more than doubled in less than a decade, but lack of AI skills remains a barrier.

## Challenges for Younger Generations
- **50%** of 20-29 year-olds: Financial pressures push many young people to live with their parents for longer.

## Economic Inequality
- **2021:** 137%
- **1995:** 150%
    - Bottom 10% income
    - Top 10% income
    - Slower growth in low incomes has widened income gaps in the OECD.

## Uneven Gender Perceptions (2014-2022)
- % change in the share of people agreeing that…
    - If a woman earns more money than her husband, it causes problems: **+6%**
    - Men make better business executives than women do: **-6%**
    - Some discriminatory views are losing traction, while others are becoming more prevalent.

## Digital Dynamics
- The share of job postings for remote/hybrid work continues to rise after COVID-19.
    - **Jan-19:** 2
    - **Jan-20 - Jan-23:** rising to **11** in Dec-23.

## Towards Sustainable Living
- **2010 | 2023:**
    - SUVs - Conventional
    - Cars - Conventional
    - Cars - Electric
    - SUVs - Electric
- Environmental gains from increasing electric car sales are offset by rising SUV sales.

TRENDS SHAPING EDUCATION 2025 © OECD 2025


### Notes:
- No tables were present in the image to convert to JSON format.
- No images could be processed or converted to text content.
- No header or footer information included as per your instructions.
## Skill over: mastering the twin transitions

Global labour markets are undergoing significant transformations due to technological advancements and sustainability imperatives – the twin transitions. The spread of new technologies like artificial intelligence (AI) is set to automate many tasks and create new ones, requiring different skill sets. Similarly, while the demand for green jobs is rising, a skills mismatch could slow the green transition and disrupt local labour markets. How can education at all levels support the skills transition to ensure that no one is left behind?

### Figure 3.1. AI skills are more common and demand for AI labour is rising, but both still low

#### Share of LinkedIn users who are AI talents across 30 countries, by gender; Share of job postings demanding AI skills across 14 countries (2016-2023)

json
{
  "data": [
    {
      "year": 2016,
      "AI_talent_concentration_Female": "0.2%",
      "AI_talent_concentration_Male": "0.4%",
      "AI_job_postings_percentage": "0.5%"
    },
    {
      "year": 2017,
      "AI_talent_concentration_Female": "0.4%",
      "AI_talent_concentration_Male": "0.6%",
      "AI_job_postings_percentage": "0.6%"
    },
    {
      "year": 2018,
      "AI_talent_concentration_Female": "0.6%",
      "AI_talent_concentration_Male": "0.8%",
      "AI_job_postings_percentage": "0.8%"
    },
    {
      "year": 2019,
      "AI_talent_concentration_Female": "0.8%",
      "AI_talent_concentration_Male": "1.0%",
      "AI_job_postings_percentage": "1.0%"
    },
    {
      "year": 2020,
      "AI_talent_concentration_Female": "1.0%",
      "AI_talent_concentration_Male": "1.2%",
      "AI_job_postings_percentage": "1.2%"
    },
    {
      "year": 2021,
      "AI_talent_concentration_Female": "1.2%",
      "AI_talent_concentration_Male": "1.2%",
      "AI_job_postings_percentage": "1.4%"
    },
    {
      "year": 2022,
      "AI_talent_concentration_Female": "1.2%",
      "AI_talent_concentration_Male": "1.4%",
      "AI_job_postings_percentage": "1.5%"
    },
    {
      "year": 2023,
      "AI_talent_concentration_Female": "1.3%",
      "AI_talent_concentration_Male": "1.5%",
      "AI_job_postings_percentage": "1.6%"
    }
  ]
}
```

Note: AI Talent concentration is the portion of LinkedIn users who added AI skills to their profile or work in AI and may be influenced by coverage.  
Source: Maslej et al. (2024), The AI Index 2024 Annual Report, https://aiindex.stanford.edu/report/.

The world of work is evolving. The adoption of AI and other frontier technologies is transforming labour markets. The share of AI job postings and AI talents is growing, though still modest. The AI workforce — i.e., the subset of workers with skills that are necessary for developing and maintaining AI systems, such as statistics, computer science and machine learning — has almost tripled as a share of employment in less than a decade. However, lack of AI skills is still a barrier, with great variance across countries and genders. Progress in AI-specific hiring by firms is thus slower than what might be expected.

Nonetheless, AI is expected to have a momentous effect in other sectors, by reshaping tasks and roles. AI could boost work quality and productivity, mostly in wealthier countries and knowledge-heavy industries, bridge skill gaps and improve worker engagement and safety. But it may also jeopardise well-being, privacy and autonomy. The unprecedented speed of adoption of certain generative AI, such as ChatGPT, attracts diverging reactions: more than half of young people worry that AI will eliminate jobs, yet many others believe technology will make their jobs less boring and more aligned with their private lives. While there is little evidence of major employment effects so far, many workers are estimated to require training soon.

At the same time, the quest for sustainability sees jobs in high-emission industries declining while new opportunities are created in green sectors, and skill needs are changing also in sectors that are neither green nor polluting. Green-driven occupations — i.e., jobs affected by the net-zero transition, even if indirectly — employ about a fifth of workers in the OECD, mostly in the manufacturing, utilities, mining, construction, and transport sectors. Although the share of all green-driven occupations increased by only 2% in European OECD countries and the United States, the sub-category of green “new and emerging”  
```
As the demand for new jobs and skills rises, so do the challenges in meeting these demands. Skills development policies are not keeping pace: only around four in ten adults participate in formal or non-formal learning for job-related reasons on average across the OECD. Upskilling workers and helping them obtain adequate employment opportunities will be essential to ensure they are not left behind — but is the education and training sector ready?

---

### Figure 3.2: New green jobs are rising and polluting jobs declining

Percentage change in the share of green new and emerging occupations and Greenhouse Gas (GHG)-intensive occupations in total employment, Europe and the United States (2011-2022)

| Year      | Green new and emerging occupations (Europe) | Green new and emerging occupations (United States) | GHG-intensive occupations (Europe) | GHG-intensive occupations (United States) |
|-----------|--------------------------------------------|--------------------------------------------------|-----------------------------------|------------------------------------------|
| 2011-15   | 0-15%                                      | 0-15%                                            | -10% to 5%                        | -10% to 5%                               |
| 2015-19   | 0-15%                                      | 0-15%                                            | -10% to 5%                        | -10% to 5%                               |
| 2019-22   | 0-15%                                      | 0-15%                                            | -10% to 5%                        | -10% to 5%                               |

(Note: GHG-intensive occupations are particularly concentrated in high-emission industries.)

---

And education?
- In what ways should curricula, qualifications and programmes be updated to support the skill needs of the twin transitions? How can education provide basic 'AI literacy' to all learners and specialised skills for some? Can AI itself help, for example by personalising learning?
- How can governments best anticipate future skill needs and in how far should they steer education providers or students towards specific pathways according to labour-market needs (e.g., by using quotas or incentives)? How does career guidance need to adapt?
- How can education and training systems diversify post-secondary pathways to adapt to the rising demand for high-skilled workers and for upskilling and reskilling throughout life? How can they meet the needs of students who combine studies with work, e.g., through micro-credentials, online learning and AI? And how can they adapt teacher education and professional learning?
- Technological developments may significantly reduce the need for human labour. What are the implications for education systems, including their social, cultural and identity-shaping roles?



## A balancing act: young adults and society in transition

Younger generations are adapting their consumption, work and lifestyle choices in response to both economic necessity and shifting values. Financial pressures push many to live with their parents for longer or take on a second job. At the same time, with changing priorities, young people often seek hybrid work or reduced work hours. These preferences reflect a growing focus on work-life balance, in line with broader societal trends, as well as a wish for self-actualisation. Can education foster independence and resilience?

### Figure 3.3. Forever nesting? A growing share of young people are still living with their parents

Share of young adults aged 20-29 living with their parents, OECD average and selected countries (2006, 2022)

json
{
  "data": [
    {
      "country": "Korea",
      "2006": 24,
      "2022": 67
    },
    {
      "country": "Italy",
      "2006": 59,
      "2022": 71
    },
    {
      "country": "Spain",
      "2006": 39,
      "2022": 59
    },
    {
      "country": "Portugal",
      "2006": 37,
      "2022": 52
    },
    {
      "country": "France",
      "2006": 30,
      "2022": 47
    },
    {
      "country": "Belgium",
      "2006": 28,
      "2022": 45
    },
    {
      "country": "Netherlands",
      "2006": 32,
      "2022": 43
    },
    {
      "country": "Ireland",
      "2006": 26,
      "2022": 42
    },
    {
      "country": "United States",
      "2006": 23,
      "2022": 31
    },
    {
      "country": "Canada",
      "2006": 27,
      "2022": 30
    },
    {
      "country": "United Kingdom",
      "2006": 24,
      "2022": 30
    },
    {
      "country": "Australia",
      "2006": 23,
      "2022": 29
    },
    {
      "country": "New Zealand",
      "2006": 25,
      "2022": 29
    },
    {
      "country": "Finland",
      "2006": 20,
      "2022": 26
    },
    {
      "country": "Sweden",
      "2006": 20,
      "2022": 25
    },
    {
      "country": "Norway",
      "2006": 16,
      "2022": 24
    },
    {
      "country": "Denmark",
      "2006": 15,
      "2022": 24
    },
    {
      "country": "Greece",
      "2006": 17,
      "2022": 20
    },
    {
      "country": "Iceland",
      "2006": 20,
      "2022": 18
    }
  ]
}
```

In most OECD countries, more than half of people surveyed believe that today’s children will grow up to be worse off than their parents. This sentiment has grown stronger over the past decade and is supported by data showing declining inter-generational income mobility in some countries. The economic fallout from the pandemic, combined with the ongoing cost-of-living crisis, has hit young people particularly hard. Faced with economic pressures, over half of individuals under 40 across 44 countries worldwide reported living paycheck-to-paycheck, with little or no savings for emergencies, periods of unemployment, or housing. As a result, young people are increasingly anxious about the future: over half of those surveyed think it will become harder or impossible to start a family or buy a house.

One coping mechanism is what is known as **nesting**. As young people tend to live in rental housing, with rent prices rising faster than inflation, many opt to stay in the family home. The share of young adults living with their parents has increased in over 20 OECD countries since 2006, reflecting a decline in financial independence. Many young people have also taken on a second job, buy second-hand clothes or choose not to drive a car. Some of these choices align with a growing environmental consciousness among young generations and suggest resilience and agility in the face of changing realities.

Moreover, young people increasingly prioritise work-life balance and flexibility, meaning that less stable work patterns may not deter them. For instance, across 44 countries, most young people in remote or hybrid roles would rather change jobs if asked to work on-site full-time. About half of Gen Z (born 1995-2005) would rather be unemployed than stuck in a job they dislike, and over three-quarters of those under 40 seek more flexible work or reduced working hours. These preferences are in line with broader trends.
```
### Figure 3.4: Seeking equilibrium: work-life balance is improving overall

Average annual hours worked per worker (left axis); Percent of workers working 50 hours a week or longer, by age group (right axis), OECD average, 1988-2023

#### Table Data
json
{
  "averageHoursWorked": {
    "years": [1980, 1982, 1984, 1986, 1988, 1990, 1992, 1994, 1996, 1998, 2000, 2002, 2004, 2006, 2008, 2010, 2012, 2014, 2016, 2018, 2020, 2022],
    "annualHours": [1960, 1950, 1900, 1880, 1860, 1850, 1840, 1820, 1800, 1790, 1780, 1770, 1750, 1740, 1730, 1700, 1680, 1660, 1650, 1640, 1630, 1620],
    "percentWorking50Hours": {
      "25to29years": [],
      "30to34years": [],
      "35to39years": [],
      "40to44years": [],
      "45to49years": []
    }
  }
}
```

And education:
- Can education foster inter-generational understanding, solidarity and fairness? Can it support young people in their quest for flexibility and self-actualisation?
- In an uncertain world and labour market, adaptability matters. How can education ensure the social and emotional development required to build resilience, agility, and independence?
- How attractive is the teaching profession for young people today? How can education policies address teachers’ work-life balance and greater flexibility in their work and lives?
- Shifting priorities among young people mean that, for many, work no longer constitutes a component of their identity, and progress is about more than increased earnings. How can education prepare students for various aspects of life in society? How can it support young people to develop a sense of mission, purpose and personal agency?
```
Them that’s got shall get: economic inequality

Long-standing income inequalities between countries have decreased since the 1980s as emerging economies experienced stronger growth than advanced economies, lifting many out of poverty. Yet within-country economic inequalities are on the rise globally, indicating that the benefits of economic growth have not been distributed equally. Across the OECD, real incomes of low- and middle-earners have increased at slower rates than those of top earners, reflecting growing social inequality and jeopardising social cohesion and stability. Recent increases in energy and food prices also disproportionately affect low-income households. What can education systems do to mitigate and address rising inequalities?

Figure 3.5. Converging world, unequal societies
Income inequality, within and between countries, global (1820-2020)

json
{
  "title": "Income inequality, within and between countries, global (1820-2020)",
  "data": [
    {
      "year": 1820,
      "within_country_inequality": 2,
      "between_country_inequality": 2
    },
    {
      "year": 1840,
      "within_country_inequality": 4,
      "between_country_inequality": 4
    },
    {
      "year": 1860,
      "within_country_inequality": 6,
      "between_country_inequality": 6
    },
    {
      "year": 1880,
      "within_country_inequality": 8,
      "between_country_inequality": 8
    },
    {
      "year": 1900,
      "within_country_inequality": 10,
      "between_country_inequality": 10
    },
    {
      "year": 1920,
      "within_country_inequality": 12,
      "between_country_inequality": 12
    },
    {
      "year": 1940,
      "within_country_inequality": 14,
      "between_country_inequality": 14
    },
    {
      "year": 1960,
      "within_country_inequality": 16,
      "between_country_inequality": 16
    },
    {
      "year": 1980,
      "within_country_inequality": 15,
      "between_country_inequality": 15
    },
    {
      "year": 2000,
      "within_country_inequality": 14,
      "between_country_inequality": 14
    },
    {
      "year": 2020,
      "within_country_inequality": 16,
      "between_country_inequality": 16
    }
  ],
  "note": "Between-country inequality is measured by the ratio T10/B50 between the average incomes of the top 10% and the bottom 50% of individuals. Within-country inequality is measured by the ratio T10/B50 between the average incomes of the top 10% and the bottom 50%."
}
```

Income inequalities between countries, while declining, remain high globally. Within countries, the gap between the incomes of the top 10% and the bottom 50% of individuals has nearly doubled globally since the 1980s. Global wealth inequalities are even starker, with the poorest half of the population owning just 2% of total wealth, while the richest 10% hold 76% of it. These inequalities mean that despite strong economic growth in emerging economies, many societies remain deeply unequal. However, inequality trends vary across countries, suggesting that inequality is preventable through policy choices.

Across the OECD, low and middle incomes have risen at slower rates than higher incomes, with the lowest earners hit hardest during the global financial crisis. Increased labour-market polarisation has meant widening earnings inequalities, while inflation has increased costs for many families, especially food and energy. Consequently, people increasingly feel that economic disparities are too high. Economic inequality can lead to societal fragmentation and increased polarisation, as disparities in wealth and opportunity create divisions within communities and erode trust in institutions. This prompts reflection on how education can best foster social cohesion and resilience, while ensuring that people from all socio-economic backgrounds thrive.
```
economic backgrounds can gain the skills needed to thrive in changing labour markets. With growing income and wealth gaps within societies and between generations, can education be the great equaliser?

Tackling inequality requires resources, yet the redistributive capacity of many states has gotten weaker. Higher levels of public debt in the aftermath of the COVID-19 pandemic further limit governments’ capacity to invest in social services and public infrastructure, including education. Alongside the role of broader cross-sectoral policies in addressing inequality, education has the potential to foster solidarity and improve life chances for students from lower socio-economic backgrounds. Is it doing all it can?

### Figure 3.6. Low and middle incomes have been growing substantially less than higher incomes
json
{
  "Growth in real income by income position": {
    "years": [1995, 2000, 2005, 2010, 2015, 2020],
    "Bottom 10%": [120, 120, 120, 122, 123, 124],
    "Median": [129, 130, 131, 132, 134, 136],
    "Mean": [130, 132, 133, 134, 136, 138],
    "Top 10%": [140, 141, 142, 143, 144, 150]
  }
}
```
**Note**: 1995 = 100%. Calculations based on the OECD Income Distribution Database.  
Source: OECD (2024), Society at a Glance 2024: OECD Social Indicators, https://doi.org/10.1787/918d8db3-en.

---

**And education?**
- How can governments maintain high-quality education with limited public resources? 
- Can education systems engage with research to become more cost-effective? 
- How can societies build consensus around the idea of education as an investment rather than a cost? 
- How can curricula foster an understanding of connections between economic policies, well-being, and the strength of democratic institutions? 
- What policies could help reduce financial burdens on families and increase availability and affordability for all, especially in early childhood education and care, higher education and non-formal education? 
- Can education play a role in addressing people's dissatisfaction with growing wealth disparities? What is the role of curricula, and of teachers, in promoting ethical reasoning, solidarity and social cohesion? 
- How can schools address both the need for raising basic skill levels and their broader mission to cultivate other competencies, values and perspectives?
```

# Foreword

The future of education is shaped by a myriad of economic, social, demographic, and technological trends. The last few years have seen significant global crises, including a rise in armed conflict, and mounting geopolitical tensions, which have implications for public spending, international migration, global health, and national policy priorities. Their implications for education play out in various ways, underscoring the role that education can play in fostering peace and solidarity, but also the necessity of resilience and adaptability in our education systems.

**Trends Shaping Education 2025** is the seventh edition in a series designed to support long-term strategic thinking in education. It offers an overview of historical trends in various fields of life and raises pertinent questions about their impact on education. From the increasing integration of AI-powered technology in daily life to the evolving dynamics of human, animal and environmental health, each chapter provides insights into how these trends might shape the future of education, and how education might shape these developments in turn. By examining global trends, we aim to equip education policymakers and stakeholders with the data and knowledge needed to navigate the complexities of the future educational landscape.

If we have learned one thing from the various iterations of this report, it is that the future will always surprise us. Trends are rarely linear and the future seldom a mere continuation of the past. Therefore, the report combines the analysis of robust trend data and evidence with futures thinking tools and scenarios that are more speculative and imaginative. Each chapter concludes with a foresight section offering alternative scenarios exploring how observed trends might break, bend, accelerate or interact in unexpected ways.

This report offers both continuity and innovation compared with previous titles in the series. It updates trend data in key areas such as demography, economic growth and democratic participation, while offering new perspectives on global conflict and co-operation, voices and storytelling, and bodies and minds. It builds on the foresight exercises developed in previous editions, while also adding a range of new futures thinking tools to inspire both reflection and action.

Within the OECD’s Centre for Educational Research and Innovation (CERI), since 2023, the work on Trends Shaping Education has been led by Deborah Nusche, and this report was co-authored by Jonathan James, Tal Malkin and Deborah Nusche. Sasha Ramirez-Hughes, Sophie Limoges and Rachel Linden contributed to design, editing and communications, and Kebure Assefa and Siziwia Malik Game formatted the document for publication. We are grateful to Andreas Schleicher, Director of Education and Skills, for his oversight and comments on the report. We would also like to thank members of the CERI Governing Board for their continuous encouragement, support and feedback. Above all, the Trends Shaping Education team is deeply grateful to Tia Loukola, Head of CERI, whose lasting vision and guidance were invaluable to the completion of this report and will continue to shine and inform our work in the future.

Covering such a vast range of global trends necessarily relies on collaboration, and this volume has benefited enormously from exchanges with experts inside and outside the OECD, who contributed their ideas, analysis and insights. We are grateful to the following OECD colleagues who offered comments and shared their expertise with us: Willem Adema, Carolin Beck, Joanne Caddy, Jonathan Chaloff, Dexter


Yes we can? Uneven gender perceptions, participation, and rights

Attitudes on gender-related issues evolve over time, but change is not always linear. Recently, some views on gender have shifted towards greater equality, while others have become more traditional, and younger generations present mixed outlooks. Women’s progress in the labour market also reflects uneven trends. And while acceptance of LGBTI rights is improving, major variations remain. How can education promote an environment where everyone, regardless of gender or sexual orientation, feels valued and respected?

### Attitudes about women’s roles are showing both progress and setbacks

Change in attitudes across 36-37 countries between 2014-2022

json
{
  "data": {
    "It is always or sometimes justifiable for a man to beat his wife": -12,
    "Men make better business executives than women do": -10,
    "Men make better political leaders than women do": -8,
    "Being a housewife is just as fulfilling as working for pay": -6,
    "Abortion is not justifiable": -4,
    "When jobs are scarce, men should have more right to a job than women": -2,
    "When a mother works for pay, the children suffer": -2,
    "If a woman earns more than her husband, it causes problems": 6
  }
}
```

Note: For each statement, the figure presents the change in percentage points between the share of the population agreeing with the stated view in 2014 and 2022. Based on the World Values Survey results from waves 6 and 7, of the periods 2010-14 and 2017-22, respectively.  
Source: OECD (2023), SIGI 2023 Global Report: Gender Equality in Times of Crisis, [https://doi.org/10.1787/4607bc7b-en](https://doi.org/10.1787/4607bc7b-en).

Gender differences in education outcomes offer a complex picture. Labour-market indicators show that closing the gender wage gap for women has been slow globally and gender gaps in workforce participation have fluctuated since 2009, with OECD countries showing some improvements in the last decade. Across the OECD, girls are outperforming boys in many educational outcomes and significantly more young women than men have obtained advanced qualifications in recent years. Yet this educational advantage has yet to translate into closing employment gaps. Labour-market equality may be hard to achieve when social attitudes towards women remain unfavorable.

While some discriminatory views towards women have become less prevalent in the past decade, others have gained traction, such as the belief that it is problematic for a woman to earn more than her husband. Similarly, their surveys show increasingly agreement with the view that a man who stays home to care for his children is "less of a man," with nearly a quarter of adults in 31 countries (mostly men) holding this belief in 2024. Interestingly, such traditional views are more common among younger generations than older ones. At the same time, almost half of those under 40 define themselves as feminists (mostly women), far more than older generations do, suggesting a divide within younger groups along gender and ideological lines. The reasons for regressive trends in some areas are very complex and not uniform across countries.

TRENDS SHAPING EDUCATION 2025 © OECD 2025
```
Home and away: digital dynamics in life and work

The rise of digital technologies – e.g., data, communication and AI – is reshaping both our work dynamics and personal lives. We increasingly rely on these tools for our social connections, work, self- and health care, leisure, shopping, learning, and interacting with government services. The rise of remote work is also shifting household dynamics. While many of these innovations are making things better, easier, and quicker, some carry risks or are not equally accessible to everyone. How can education prepare everyone for a safe and productive digital future, without leaving human interaction behind?

More people are using e-gov services

Share of individuals using the Internet for e-government activities in the last 12 months, EU-27 (2008-2021)

json
{
  "data": [
    {
      "year": 2008,
      "interaction_with_public_authorities": 20,
      "downloading_official_forms": 10,
      "obtaining_information": 30,
      "submitting_completed_forms": 5
    },
    {
      "year": 2009,
      "interaction_with_public_authorities": 25,
      "downloading_official_forms": 15,
      "obtaining_information": 35,
      "submitting_completed_forms": 10
    },
    {
      "year": 2010,
      "interaction_with_public_authorities": 30,
      "downloading_official_forms": 20,
      "obtaining_information": 40,
      "submitting_completed_forms": 15
    },
    {
      "year": 2011,
      "interaction_with_public_authorities": 35,
      "downloading_official_forms": 25,
      "obtaining_information": 45,
      "submitting_completed_forms": 20
    },
    {
      "year": 2012,
      "interaction_with_public_authorities": 40,
      "downloading_official_forms": 30,
      "obtaining_information": 50,
      "submitting_completed_forms": 25
    },
    {
      "year": 2013,
      "interaction_with_public_authorities": 42,
      "downloading_official_forms": 32,
      "obtaining_information": 52,
      "submitting_completed_forms": 27
    },
    {
      "year": 2014,
      "interaction_with_public_authorities": 45,
      "downloading_official_forms": 35,
      "obtaining_information": 55,
      "submitting_completed_forms": 30
    },
    {
      "year": 2015,
      "interaction_with_public_authorities": 48,
      "downloading_official_forms": 37,
      "obtaining_information": 60,
      "submitting_completed_forms": 32
    },
    {
      "year": 2016,
      "interaction_with_public_authorities": 50,
      "downloading_official_forms": 40,
      "obtaining_information": 62,
      "submitting_completed_forms": 35
    },
    {
      "year": 2017,
      "interaction_with_public_authorities": 52,
      "downloading_official_forms": 42,
      "obtaining_information": 65,
      "submitting_completed_forms": 37
    },
    {
      "year": 2018,
      "interaction_with_public_authorities": 55,
      "downloading_official_forms": 45,
      "obtaining_information": 67,
      "submitting_completed_forms": 40
    },
    {
      "year": 2019,
      "interaction_with_public_authorities": 57,
      "downloading_official_forms": 47,
      "obtaining_information": 70,
      "submitting_completed_forms": 42
    },
    {
      "year": 2020,
      "interaction_with_public_authorities": 58,
      "downloading_official_forms": 49,
      "obtaining_information": 72,
      "submitting_completed_forms": 45
    },
    {
      "year": 2021,
      "interaction_with_public_authorities": 60,
      "downloading_official_forms": 50,
      "obtaining_information": 75,
      "submitting_completed_forms": 47
    }
  ]
}
```

Digital technology use is now ubiquitous. In interpersonal relationships, more people are using social media, and they are using it for longer hours. In self-care and healthcare, the wellness app sector has seen steady revenue growth, and more people are turning to the Internet for health information. 

As online services become more accessible, the global use of digital platforms to interact with government authorities is rising too. On average across the OECD, about 3 in 4 people use online government services (slightly less than Internet banking), although this varies widely between countries.

The way we work is also changing rapidly. While COVID-19 spurred a shift towards remote work, the trend has now decoupled from the pandemic and become a lasting one. In OECD countries, the share of advertised telework is continuing to grow, and two to three days of teleworking per week are now typical in jobs that allow for it. However, better-paid and more educated workers are likely to enjoy remote learning and providing adequate offline support. Access remains a challenge.

TRENDS SHAPING EDUCATION 2025 © OECD 2025
```
work, meaning opportunities are not even. Telework has the advantages of reducing commuting time, increasing flexibility, and enabling non-mobile workers to participate in paid employment, but can also negatively affect work-life balance and increase isolation. And while both employees and employers seem to agree that some degree of teleworking is positive, the effect of telework on productivity remains contested. At the same time, the rise of telework has also led to an increase in co-working spaces, which could boost local economies and improve the inclusivity of local labour markets. To benefit from the digitalisation of life and work, people need digital literacy and adaptability to an ever-changing environment. Can education institutions and lifelong learning schemes help everyone keep pace?

## Figure 3.10. Telework is here to stay

Share of job postings advertising remote/hybrid work, and government COVID-19 restrictions, average across 20 OECD countries (Jan. 2019 – Dec. 2023)

json
{
  "data": [
    {
      "date": "Jan-19",
      "remote_hybrid_work_ads": 0,
      "government_response_index": 100
    },
    {
      "date": "Jul-19",
      "remote_hybrid_work_ads": 0,
      "government_response_index": 100
    },
    {
      "date": "Jan-20",
      "remote_hybrid_work_ads": 1,
      "government_response_index": 80
    },
    {
      "date": "Jul-20",
      "remote_hybrid_work_ads": 4,
      "government_response_index": 60
    },
    {
      "date": "Jan-21",
      "remote_hybrid_work_ads": 6,
      "government_response_index": 40
    },
    {
      "date": "Jul-21",
      "remote_hybrid_work_ads": 7,
      "government_response_index": 30
    },
    {
      "date": "Jan-22",
      "remote_hybrid_work_ads": 9,
      "government_response_index": 20
    },
    {
      "date": "Jul-22",
      "remote_hybrid_work_ads": 10,
      "government_response_index": 15
    },
    {
      "date": "Jan-23",
      "remote_hybrid_work_ads": 11,
      "government_response_index": 10
    },
    {
      "date": "Jul-23",
      "remote_hybrid_work_ads": 12,
      "government_response_index": 5
    }
  ]
}
```

Note: Share of remote/hybrid ads is the average value of country shares of job postings advertising remote/hybrid work, obtained by aggregating over the different occupations using their shares in a country’s overall job postings as weights. Based on over 1 billion job postings from Indeed job sites in Europe, North America, Japan, Australia and New Zealand, across 55 occupations. The beginning of the pandemic – February 2020. Source: Adjan et al. (2024), “Working from Home after COVID-19: What Do Job Postings Tell Us?”, SSRN Electronic Journal, https://doi.org/10.2139/ssrn.4064191.

And education?
- Can education prepare students for an increasingly digital future by embedding digital literacy into curricula and teachers’ initial and continuing learning? Given rapid change, how can education foster the metacognitive skills needed for lifelong learning?
- While remote work is increasingly common, in-person presence is still required in many roles, often those requiring specialised skills and hands-on experience (e.g., healthcare, trades and technical jobs, hospitality, manufacturing). Can improving the prestige and quality of these roles make them more appealing? How can vocational education and training help prepare a well-rounded and adaptable workforce?
- With less time spent in direct human interaction, is the socio-emotional function of education more important than ever? Can it help maintain a sense of community?
```
Changing our ways: towards sustainable living

In recent years, climate change has dramatically impacted lives worldwide, calling attention to the urgent need to reduce emissions. To be effective, these efforts should be comprehensive, addressing both supply-side and demand-side factors. Behavioural change is critical in all pathways towards net-zero carbon emissions, but recent consumption trends have been mixed. For instance, meat consumption continues to rise, particularly in richer countries, and demand is increasing worldwide for high-emissions SUV cars, although electric vehicles are also becoming more common. What is the role of education in shaping consumption patterns and behaviours for a more sustainable future?

Figure 3.11. Meat consumption is rising overall

Per-capita meat supply, globally by country-income level (1961-2021)

| Year   | High-Income Countries | Upper-Middle-Income Countries | Lower-Middle-Income Countries | Low-Income Countries | World |
|--------|----------------------|-------------------------------|-------------------------------|---------------------|-------|
| 1961   | 70                   | 29                            | 15                            | 10                  | 38    |
| 1964   | 73                   | 28                            | 14                            | 9                   | 39    |
| 1967   | 75                   | 30                            | 16                            | 10                  | 41    |
| 1970   | 77                   | 31                            | 20                            | 11                  | 43    |
| 1973   | 76                   | 33                            | 23                            | 13                  | 45    |
| 1976   | 78                   | 34                            | 25                            | 14                  | 47    |
| 1979   | 78                   | 35                            | 27                            | 13                  | 48    |
| 1982   | 80                   | 36                            | 28                            | 14                  | 50    |
| 1985   | 84                   | 37                            | 29                            | 15                  | 52    |
| 1988   | 86                   | 38                            | 30                            | 16                  | 54    |
| 1991   | 88                   | 39                            | 31                            | 17                  | 56    |
| 1994   | 90                   | 40                            | 32                            | 18                  | 58    |
| 1997   | 92                   | 41                            | 33                            | 19                  | 60    |
| 2000   | 94                   | 43                            | 34                            | 20                  | 62    |
| 2003   | 96                   | 45                            | 35                            | 21                  | 64    |
| 2006   | 98                   | 47                            | 36                            | 22                  | 66    |
| 2009   | 100                  | 50                            | 37                            | 23                  | 68    |
| 2012   | 102                  | 52                            | 40                            | 24                  | 70    |
| 2015   | 105                  | 55                            | 42                            | 25                  | 72    |
| 2018   | 108                  | 58                            | 45                            | 26                  | 74    |
| 2021   | 110                  | 60                            | 48                            | 28                  | 76    |

Note: Data excludes fish and other seafood sources. Figures do not correct for waste at the household/consumption level so may not directly reflect the quantity of food finally consumed by a given individual. 

Source: Adapted from Food and Agriculture Organization of the United Nations – with major processing by Our World in Data (2023), "Per capita consumption of meat - FAO [dataset]", https://ourworldindata.org/grapher/meat-supply-per-person.

Net greenhouse gas (GHG) emissions in OECD countries have gradually declined since 2007, partly due to climate policies and the economic slowdown after the 2008 crisis. However, progress varies significantly across countries. While OECD nations are expected to somewhat reduce emissions by 2030, global emissions are still projected to rise. New technologies may offer hope for mitigating emissions, but achieving net-zero targets will require comprehensive strategies – improving energy efficiency, adopting renewable energy sources, reducing consumption, and cutting transportation and industrial emissions. These strategies require wider policy and structural changes. But shifting consumer behaviour is also key, with living car-free, reducing air travel, moving towards more plant-based diets, and using renewable electricity among the behavioural changes with the highest mitigation potential.

Yet, global meat consumption, for example, has consistently risen, especially in wealthier countries. The largest increases have been in poultry and pork, with total meat production accounting for over half of food emissions. While the impact of meat consumption on emissions is expected to slow due to a shift toward poultry, which carries a smaller footprint, and technological advances that reduce methane emissions, meat consumption remains a significant contributor to emissions.


Passenger car sales also show mixed trends. Overall sales have rebounded post-pandemic, reflecting insufficient development of public transportation and micro-mobility options. Electric car sales have surged, and in countries like Norway, fully electric cars now outsell others. However, this progress is stalled by a sharp global increase in SUV sales. SUVs made up 48% of global car sales in 2023, revealing consumer preferences for larger, status-driven vehicles. As most of the SUVs sold are conventional ones, emitting about 20% more CO₂ than medium-sized cars, these trends present consumers' diverging preferences.

At the same time, the rise of ride-sharing, ride-hailing, and vehicle-sharing platforms over the past decade suggests a shift toward more sustainable transportation, potentially reducing the number of cars per capita. Education plays a crucial role in promoting sustainability and supporting healthier, environmentally friendly lifestyles. Can it also help reshape attitudes toward consumption, materialism, and the value of sharing?

### Figure 3.12. Environmental gains from increasing electric car sales are offset by rising SUV sales 

**New car registrations by size and powertrain, worldwide (2010-2023)**

json
{
  "data": [
    {
      "year": 2010,
      "SUVs_Conventional": 70,
      "SUVs_Electric": 5,
      "Cars_Conventional": 30,
      "Cars_Electric": 2
    },
    {
      "year": 2011,
      "SUVs_Conventional": 75,
      "SUVs_Electric": 6,
      "Cars_Conventional": 32,
      "Cars_Electric": 3
    },
    {
      "year": 2012,
      "SUVs_Conventional": 80,
      "SUVs_Electric": 7,
      "Cars_Conventional": 34,
      "Cars_Electric": 5
    },
    {
      "year": 2013,
      "SUVs_Conventional": 82,
      "SUVs_Electric": 10,
      "Cars_Conventional": 33,
      "Cars_Electric": 4
    },
    {
      "year": 2014,
      "SUVs_Conventional": 85,
      "SUVs_Electric": 15,
      "Cars_Conventional": 35,
      "Cars_Electric": 6
    },
    {
      "year": 2015,
      "SUVs_Conventional": 85,
      "SUVs_Electric": 20,
      "Cars_Conventional": 34,
      "Cars_Electric": 7
    },
    {
      "year": 2016,
      "SUVs_Conventional": 88,
      "SUVs_Electric": 22,
      "Cars_Conventional": 36,
      "Cars_Electric": 9
    },
    {
      "year": 2017,
      "SUVs_Conventional": 90,
      "SUVs_Electric": 25,
      "Cars_Conventional": 38,
      "Cars_Electric": 10
    },
    {
      "year": 2018,
      "SUVs_Conventional": 89,
      "SUVs_Electric": 28,
      "Cars_Conventional": 40,
      "Cars_Electric": 12
    },
    {
      "year": 2019,
      "SUVs_Conventional": 88,
      "SUVs_Electric": 29,
      "Cars_Conventional": 41,
      "Cars_Electric": 15
    },
    {
      "year": 2020,
      "SUVs_Conventional": 87,
      "SUVs_Electric": 32,
      "Cars_Conventional": 43,
      "Cars_Electric": 18
    },
    {
      "year": 2021,
      "SUVs_Conventional": 85,
      "SUVs_Electric": 35,
      "Cars_Conventional": 45,
      "Cars_Electric": 20
    },
    {
      "year": 2022,
      "SUVs_Conventional": 84,
      "SUVs_Electric": 37,
      "Cars_Conventional": 46,
      "Cars_Electric": 23
    },
    {
      "year": 2023,
      "SUVs_Conventional": 83,
      "SUVs_Electric": 39,
      "Cars_Conventional": 47,
      "Cars_Electric": 25
    }
  ]
}
```

### And education?
- How can education enable socio-behavioural change at the massive scale and pace needed for climate change mitigation? How can it promote interdisciplinary approaches and systems thinking, helping individuals situate their own actions within the broader sectoral and systems changes required?
- How can education address the need to change production and consumption patterns? What are good strategies for education institutions to monitor and reduce their own carbon footprints? Can place-based approaches empower learners and communities for action?
- Addressing climate change will require sustainability competences and transversal skills not only among young people, but crucially, also adults. How can this be addressed in formal, non-formal and informal education and training? How can education and training impart good environmental literacy for all, and advance specialised skills for some?
```
## Work and progress – in the future

The world of work is changing with the twin transitions, remote and digital work, changing tenure dynamics and skills and gender gaps. Increased economic inequality threatens social cohesion. Will these trends evolve, transform or break? And how will they impact education in each case? This section explores imagined scenarios – alternative futures – paired with stories highlighting the opportunities and challenges faced by various education stakeholders.

The futures below are not predictions but are designed to inspire reflection and guide action in the present.

### Future 1

- **AI boosts productivity and lowers costs in some regions.** Jobs in the digital and green sectors are unevenly distributed, widening gaps.
  
- **Economic inequality and social polarisation lead to fragmented societies.** Some young people opt to live in communes or participate in riots, frustrated by their prospects and by economic injustice.

- **Legal protections for gender and sexual identity vary across regions.** Workforce participation and gender pay gaps have improved, but women still shoulder most care tasks, with many burning out.

  Gabriel, parent and part-time student:  
  "I joke that we’re all still in school – except my husband. Our oldest son gets a gender equality bursary for training as a nurse, but it isn’t enough for him to move out. I've dropped out for days to study data mining for my marketing job. Nina’s at a local high school, which we picked for its inclusive approach, with many same-sex families like ours there. What a contrast to the traditionalist schools that attract most families nowadays! After graduation, she’ll likely stay with us while exploring the micro-tracks offered by tech companies. No empty nest for us anytime soon! At least Sara, our co-parent, takes some of the load off."

### Future 2

- **Due to advances in digital technologies, AI and robotics,** 86% of work is either automated or done remotely. This aligns with people’s wish for flexibility and autonomy, and employers’ wish to cut costs.
  
- **Poverty is high, with many attaining only partial employment, if any.** The few who work in roles that require physical presence are part of a separate social class.

- **Environmental gains from the massive decrease in work-commute are offset by a rise in energy consumption to upkeep the digital sphere.**

  Alex, HR Manager:  
  "Some of my colleagues say the recent young recruits breeze through their training, treating it like another online module. But in my sector, emotional support for children, I can barely keep up with the demand. Finding young therapists with the socio-emotional skills we need is tough, probably since they grew up with so little real human interaction. When I do find one, they sometimes struggle with the technical side, like using the AI system that’s central to our service. Thankfully, AI translation lets me hire globally now. With more people from diverse backgrounds succeeding with AI-driven education and training, AI-HR offers me a broader talent pool to choose from."

### Future 3

- **All out digital:**  
  Learning at all levels is primarily digital and online, including AI-personalisation and VR immersive experiences, and is distributed in format.  
  Schools do not exist as physical spaces for children over age 9; instead, students join virtual communities. Teachers act as online guides, thus fewer are needed and a 1:85 ratio is common.  
  The rich pay for private face-to-face learning, while others struggle with the extra burden of learning-from-home, and its impact on mental health. Yet, some students flourish in digital settings.
```
Future 3
The green transition disappoints. A lack of raw materials and skilled workers, and slow technological evolution, stalled progress in transport, battery storage and carbon capture.

The tech transition also slowed, with some innovations proving unviable or facing distrust after major disinformation campaigns and cyber-attacks.

Frequent climate disruptions, consumer scares, and cyber-defence costs further weaken economic activity. Job losses are not offset by growth in emerging sectors, leading to high unemployment.

Lelia, vocational trainer: 
"We just had another student drop out, citing overwhelming climate anxiety. Our focus on behavioural shifts—like reducing waste and rethinking consumption—isn’t hitting home when students are struggling with eco-despair. To be honest, I’m finding it tough myself. I try to focus on the progress – for instance, over half of my students are now vegan, and others are following in their footsteps. Our school also won the regional award for reduced emissions, which the government is closely measuring, and my colleagues have been travelling to other schools to explain our emissions and waste programs, of which our students are co-designers."

The twin failure
Tackling climate change now relies heavily on behavioural shifts, which have become a central focus of education.

Declining state revenues in rich nations and reduced development assistance to lower-income countries, have strained education funding globally.

Meanwhile, "climate despair" coupled with financial pressures is creating a mental health catastrophe, affecting both students and teachers, burdening healthcare infrastructure within education systems.

Turning insights into action
What challenges, opportunities and tensions could the trends and futures present for different education stakeholders?

| Name     | Role                           |
|----------|--------------------------------|
| Leon     | 7-year-old student             |
| Priya    | advisor, Ministry of Education  |
| Matteo   | school inspector                |
| Alex     | employer                        |
| Daniel   | school teacher                  |
| Eva      | university professor            |
| Gabriel  | parent and part-time student    |
| Emil     | school principal                |
| Mina     | early childhood director        |
| Noah     | local government official       |
| Lelia    | vocational trainer              |
| Sarah    | university student              |
| Eli      | 14-year-old student            |
| Ren      | 3-year-old child               |

Which elements of the three futures are most probable? 
How would they impact education and training in our system? 
What changes could we make in education now to seize opportunities and manage risks?

Which elements of the three futures are most desirable? 
What changes could we make in education now to move towards that future?

Which elements of the three futures are least desirable? 
What changes could we make in education now to prevent them?
```
## Notes and sources

1. Maslej, N. et al. (2024), *The AI Index 2024 Annual Report*, AI Index Steering Committee, Institute for Human-Centered AI, Stanford University, [aiindex.stanford.edu/report](https://aiindex.stanford.edu/report/); Green, A. and L. Lamby (2023), "The supply, demand and characteristics of the AI workforce across OECD countries", OECD Social, Employment and Migration Working Papers, No. 287, OECD Publishing, Paris, [doi.org/10.1787/bb17314a-en](https://doi.org/10.1787/bb17314a-en); OECD (2024), *OECD Digital Economy Outlook 2024 (Volume 1): Embracing the Technology Frontier*, OECD Publishing, Paris, [doi.org/10.1787/a1689dc5-en](https://doi.org/10.1787/a1689dc5-en), OECD Publishing, Paris, [doi.org/10.1787/08785bba-en](https://doi.org/10.1787/08785bba-en).

2. On worries across 44 countries that AI will eliminate jobs see Deloitte (2024), *2024 Gen Z and Millennial Survey - Living and working with purpose in a transforming world*, [deloitte.com/global/en/issues/work/content/genz-millennialsurvey.html](https://www.deloitte.com/global/en/issues/work/content/genz-millennialsurvey.html), 20; On optimism regarding technology and work see results for OECD countries in OECD (2024), *Risks that matter for young people: Concerns, perceived vulnerabilities and policy preferences*, OECD Publishing, Paris, [doi.org/10.1787/62b44423-en](https://doi.org/10.1787/62b44423-en).

3. Lane, M. (2024), “Who will be the workers most affected by AI?: A closer look at the impact of AI on women, low-skilled workers and other groups”, OECD Artificial Intelligence Papers, No. 26, OECD Publishing, Paris, [doi.org/10.1787/14dc68f9-en](https://doi.org/10.1787/14dc68f9-en); OECD (2024), *Megatrends and the Future of Social Protection*, OECD Publishing, Paris, [doi.org/10.1787/6c92028e-en](https://doi.org/10.1787/6c92028e-en).

4. *OECD Employment Outlook 2024: The Net-Zero Transition and the Labour Market*, OECD Publishing, Paris, [doi.org/10.1787/acb3538-en](https://doi.org/10.1787/acb3538-en); OECD (2023), *Job Creation and Local Economic Development 2023: Bridging the Great Green Divide*, OECD Publishing, Paris, [doi.org/10.1787/21db61c1-en](https://doi.org/10.1787/21db61c1-en).

5. OECD (2021), *OECD Skills Outlook 2021: Learning for Life*, OECD Publishing, Paris, [doi.org/10.1787/0ae365b4-en](https://doi.org/10.1787/0ae365b4-en); OECD (2023), *OECD Skills Outlook 2023: Skills for a Resilient Green and Digital Transition*, OECD Publishing, Paris, [doi.org/10.1787/27452729-en](https://doi.org/10.1787/27452729-en).

6. OECD (2024), *Society at a Glance 2024: OECD Social Indicators*, OECD Publishing, Paris, [doi.org/10.1787/919d8d3-en](https://doi.org/10.1787/919d8d3-en), 27; Social Mobility Commission UK (2022), *State of the Nation 2022: A fresh approach to social mobility*, [doi.org/E02761182](https://doi.org/E02761182), 46.

7. World Economic Forum (2023), *The Future of Jobs Report 2023*, [https://www3.weforum.org/docs/WEF_Future_of_Jobs_2023.pdf](https://www3.weforum.org/docs/WEF_Future_of_Jobs_2023.pdf), 12.

8. Survey results across 44 countries worldwide: Deloitte (2023), *2023 Gen Z and Millennial Survey - Waves of change: acknowledging progress, confronting setbacks*, [https://www2.deloitte.com/cn/en/pages/about-deloitte/articles/genzmillennialsurvey-2023.html](https://www2.deloitte.com/cn/en/pages/about-deloitte/articles/genzmillennialsurvey-2023.html).

9. OECD (2024), *Society at a Glance 2024: OECD Social Indicators*, OECD Publishing, Paris, [doi.org/10.1787/919d8d3-en](https://doi.org/10.1787/919d8d3-en).

10. Survey results across 44 countries worldwide: Deloitte (2023), *2023 Gen Z and Millennial Survey - Waves of change: acknowledging progress, confronting setbacks*, [https://www2.deloitte.com/cn/en/pages/about-deloitte/articles/genzmillennialsurvey-2023.html](https://www2.deloitte.com/cn/en/pages/about-deloitte/articles/genzmillennialsurvey-2023.html). See other.
```
results for OECD countries in OECD (2024), Risks that matter for young people: Concerns, perceived vulnerabilities and policy preferences, OECD Publishing, Paris, https://doi.org/10.1787/62b44423-en.

Survey results across 44 countries worldwide: Deloitte (2023), 2023 Gen Z and Millennial Survey - Waves of change: acknowledging progress, confronting setbacks, https://www2.deloitte.com/cn/en/pages/about-deloitte/articles/genzmillennialsurvey-2023.html; Deloitte (2024), 2024 Gen Z and Millennial Survey - Living and working with purpose in a transforming world, https://www2.deloitte.com/global/en/issues/work/content/genz-millennialsurvey.html.

OECD (2024), “Average annual hours actually worked per worker” and “Incidence of employment by long usual weekly hours worked”, Employment indicators, https://data-explorer.oecd.org/.

OECD (2023), Retaining Talent at All Ages, Ageing and Employment Policies, OECD Publishing, Paris, https://doi.org/10.1787/00bdd06-en; International Labour Organisation (2024), World Employment and Social Outlook: Trends 2024, https://doi.org/10.54394/HQAE1085.

Survey results across 44 countries worldwide: Deloitte (2023), 2023 Gen Z and Millennial Survey - Waves of change: acknowledging progress, confronting setbacks, https://www2.deloitte.com/cn/en/pages/about-deloitte/articles/genzmillennialsurvey-2023.html; Deloitte (2024), 2024 Gen Z and Millennial Survey - Living and working with purpose in a transforming world, https://www2.deloitte.com/global/en/issues/work/content/genz-millennialsurvey.html.

Chancel, L. et al. (2022), World Inequality Report 2022, World Inequality Lab, http://wir2022.wi.world.

OECD (2024), Society at a Glance 2024: OECD Social Indicators, OECD Publishing, Paris, https://doi.org/10.1787/918d8db3-en; OECD (2019), Under Pressure: The Squeezed Middle Class, OECD Publishing, Paris, https://doi.org/10.1787/689afed1-en.

OECD (2021), Does Inequality Matter? : How People Perceive Economic Disparities and Social Mobility, OECD Publishing, Paris, https://doi.org/10.1787/3023e40-en, 20; OECD (2024), Society at a Glance 2024: OECD Social Indicators, OECD Publishing, Paris, https://doi.org/10.1787/918d8db3-en, 86.

World Economic Forum (2024), Global Gender Gap 2024: Insight Report, https://www3.weforum.org/docs/WEF_GGGR_2024.pdf; World Economic Forum (2023), Global Gender Gap Report 2023, https://www3.weforum.org/docs/WEF_GGGR_2023.pdf; OECD (2024) “Employment, entrepreneurship & trade”, OECD Dashboard on Gender Gaps, https://www.oecd.org/en/data/dashboard/gender-dashboard.html#Employment (accessed 8 December 2024).

OECD (2024), Education at a Glance 2024: OECD Indicators, OECD Publishing, Paris, https://doi.org/10.1787/c00cad36-en.

OECD (2023), SIGI 2023 Global Report: Gender Equality in Times of Crisis, Social Institutions and Gender Index, OECD Publishing, Paris, https://doi.org/10.1787/4607b7c7-en.
```
Docherty, Jean-Christophe Dumont, Marc Fuster, Jordan Hill, Michael Koelle, Sebastian Königs, Clarisse Legendre, Molly Lesher, Ana Llena Nozal, Estelle Loiseau, Francisca López, Javier López González, Mauricio Mejía Galván, Veerle Miranda, Cian Montague, Hyeshin Park, Joshua Polchar, Christopher Prinz, Christian Reimsbach-Kounatze, Marcia Rocha, Angelica Salvi Del Pero, Cyrille Schwelnnus, Carthage Smith, Silviia Sorescu, Eric Sutherland, Marie-Anne Valfort. Thank you for your expert advice and collegiality.

We also extend our gratitude to the many external experts who contributed to this work in various ways: Jeroen Backs, Francisco Benavides, Erica Bol, Antoine Dusséaux, Keri Facer, Daniel Faggella, Catrin Finkenauer, Nicole Fournier-Sylvester, Martin Henry, Harold Hislop, Quirine van der Hoeven, Jan Germen Janmaat, Anthony Mackay, Isabell Ortiz, Roderick Parkes, Tom Schuller, Wendy Schultz, Lars Thornberg, Makito Yurita. Your collective wisdom has been invaluable in shaping this report. We also thank students from the M.A. in Comparative Education at University College London (UCL) for their participation in a futures workshop and their perspectives on the trends analysis and scenarios.

# Markdown Conversion

## References

```json
{
  "references": [
    {
      "number": "21",
      "source": "Ipsos (2024)",
      "title": "International Women’s Day 2024: global attitudes towards women’s leadership",
      "link": "https://www.ipsos.com/sites/default/files/tcnews/documents/2024-03/International-Womens-day-2024-report.pdf"
    },
    {
      "number": "22",
      "source": "Pew Research Center (2020)",
      "title": "The Global Divide on Homosexuality Persists: But increasing acceptance in many countries over past two decades",
      "authors": ["Jacob Poushter", "Nicholas O. Kent"],
      "link": "https://www.pewresearch.org/global/wp-content/uploads/sites/2/2020/06/PG_2020.06.25_Global-Views-Homosexuality_FINAL.pdf"
    },
    {
      "number": "23",
      "source": "OECD (2020)",
      "title": "Over the Rainbow? The Road to LGBTI Inclusion",
      "link": "https://doi.org/10.1787/8d2fd148-en"
    },
    {
      "number": "24",
      "source": "OECD (2023)",
      "title": "The COVID-19 Pandemic and the Future of Telemedicine",
      "link": "https://doi.org/10.1787/ac8b0a27-en"
    },
    {
      "number": "25",
      "source": "OECD (2024)",
      "title": "OECD Digital Economy Outlook 2024 (Volume 1): Embracing the Technology Frontier",
      "link": "https://doi.org/10.1787/1689dc5-en"
    },
    {
      "number": "26",
      "source": "UN Department of Economic and Social Affairs (2024)",
      "title": "UN E-Government Survey 2024 - Accelerating Digital Transformation for Sustainable Development",
      "link": "https://desapublications.un.org/sites/default/files/publications/2024-09/%28Web%20version%29-E-Government%20Survey%202024%2013932024.pdf"
    },
    {
      "number": "27",
      "source": "Adrian, P. et al. (2024)",
      "title": "Working from Home after COVID-19: What Do Job Postings Tell Us?",
      "journal": "SSRN Electronic Journal",
      "link": "https://doi.org/10.2139/ssrn.4064191"
    },
    {
      "number": "28",
      "source": "OECD (2023)",
      "title": "The Climate Action Monitor 2023: Providing Information to Monitor Progress Towards Net-Zero",
      "link": "https://doi.org/10.1787/60e3382a-en"
    },
    {
      "number": "29",
      "source": "Ivanova, D. et al. (2020)",
      "title": "Quantifying the potential for climate change mitigation of consumption options",
      "journal": "Environmental Research Letters",
      "volume": "15",
      "issue": "9",
      "page": "093001",
      "link": "https://doi.org/10.1088/1748-9326/ab8589"
    },
    {
      "number": "30",
      "source": "Ritchie, H., P. Rosado and M. Roser (2019)",
      "title": "Meat and Dairy Production",
      "link": "https://ourworldindata.org/meat-production"
    }
  ]
}
```
### Infographic 4.1. Voices and Storytelling – Chapter highlights

#### DEMOCRACY AND ITS DISCONTENTS
Voter turnout has declined across world regions since the 1970s.
- Asia: -5
- Americas: -5
- Africa: -8
- Global: -12
- Oceania: -14
- Europe: -21
- Year: 2020, 1970

#### DIVERSE VOICES IN A GLOBALISED WORLD
Some 71% of Nobel Prize winners in literature have been from Europe.

#### POPULISM AND POLARISATION
Across 31 European countries, the combined vote share of populist, far-left and far-right parties is increasing.
- 1993: 12%
- 2022: 30%
  - Far-right: +18

#### FREEDOM AND FAKE NEWS IN THE DIGITAL AGE
- 2016: 17% involved political figures.
- 2021: 935 cases of disinformation targeting elections are increasing.

#### THE DIGITAL STAGE
- 2020: 38% more likely to become content creators.
- 2008: 10% young, more educated, wealthier.
- A growing share of people in OECD countries are using the Internet to upload self-created content.

#### LOOK WHO'S TALKING!
- 2017 Traditional: +38%
- 2022 Collaborative: +400%
- A growing share of robots installed each year are designed to work with humans.


Democracy and its discontents

Democracies worldwide have witnessed a steady decline in voter turnout since the 1960s, with younger voters often less inclined to participate. This trend mirrors a growing dissatisfaction with the condition of democracy, particularly among younger generations. However, the decline in voter turnout has been accompanied by a wave of protests on issues such as economic justice, climate change, and civil rights. The role that young people have played in leading these movements shows they are far from apathetic. How can education empower people of all ages to effectively address the issues they care about?

**Figure 4.1. Democracy in decline?**  
Voter turnout in parliamentary elections by world region (1960-2023)

| Region   | 1960 | 1970 | 1980 | 1990 | 2000 | 2010 | 2020 |
|----------|------|------|------|------|------|------|------|
| Africa   | 90   |      |      |      |      |      |      |
| Americas |      |      |      |      |      |      |      |
| Asia     |      |      |      |      |      |      |      |
| Europe   |      |      |      |      |      |      | 65   |
| Oceania  |      |      |      |      |      |      |      |
| Global   |      |      |      |      |      |      | 65   |

Note: Each data point represents the smoothed average of all elections in that region in the five years surrounding the tagged year. 2020 includes data for the years 2015-2023.  
Source: International IDEA (2024), “Voter Turnout Database” (Database), https://www.idea.int/data-tools/data/voter-turnout-database.

Voter turnout has steadily declined in across regions since the 1960s. Average global turnout fell by some 12 percentage points between the early 1960s and 2020, when it stood at around 65%. Europe and Oceania saw the sharpest declines, with average turnout falling by over 21 percentage points. Along with income and educational attainment, age remains one of the most robust predictors of turnout, with younger people less likely to vote. In 2020, less than half of eligible 15-29-year-olds surveyed in 37 European countries reported voting in national elections, compared to 72% of those aged 50 and above.

The decline in voter turnout parallels rising dissatisfaction with democracy. Survey data from 77 countries suggests that the share of people who are ‘dissatisfied’ with the condition of democracy rose by almost ten percentage points between 1996 and 2020, from 48% to 58%. Younger generations show higher dissatisfaction than older ones, mirroring the generation gap in voter turnout.

Several sources point to a recent rise in protest worldwide, adding nuance to this story.4 One dataset shows the annual number of major protests increasing from 73 in 2006 to 251 in 2020, with a range of issues featuring as the main grievances. Following the 2008 Global Financial Crisis, economic justice and anti-austerity became dominant themes, reflecting widespread concerns over inequality. From 2016, there is a notable increase in protests for Indigenous, minority, and women’s rights. Other more recent data


show an increase in climate protests. Digital communication technologies have become a key tool for organising protest and have enabled the spread of movements across borders.

The fact that people are protesting more and voting less may suggest that mainstream politics may no longer deliver on its promise to address their concerns. In this sense, young people's apparent disengagement may stem less from apathy and more from a lack of trust in the system or a belief that elections do not lead to meaningful change. Indeed, the share of protests led by youth and student groups increased from 9% between 2006 and 2010 to 15.5% between 2016 and 2020, indicating that younger citizens care deeply about many issues. People who feel they have a voice in government decisions tend to trust institutions more. Participatory and deliberative forms of democracy, which give citizens meaningful input in public decisions, could therefore help to reverse recent declines in trust. Formal learning on civic issues, an open classroom climate that promotes critical thinking, and opportunities to affect change in education settings and communities can also contribute to people's sense that politics matters and that they can make a difference.

Figure 4.2. We shall overcome

Major protests by grievance/demand, worldwide (2006-2020)

| Year | Economic Justice and Anti-austerity | Failure of Political Representation | Global Justice | Civil Rights |
|------|-------------------------------------|------------------------------------|----------------|--------------|
| 2006 | 40                                  | 20                                 | 20             | 20           |
| 2007 | 60                                  | 40                                 | 20             | 20           |
| 2008 | 80                                  | 60                                 | 40             | 30           |
| 2009 | 60                                  | 70                                 | 50             | 40           |
| 2010 | 80                                  | 60                                 | 60             | 50           |
| 2011 | 100                                 | 80                                 | 80             | 60           |
| 2012 | 120                                 | 100                                | 90             | 70           |
| 2014 | 140                                 | 110                                | 100            | 80           |
| 2015 | 160                                 | 120                                | 130            | 90           |
| 2016 | 180                                 | 140                                | 140            | 100          |
| 2017 | 160                                 | 130                                | 140            | 110          |
| 2018 | 140                                 | 120                                | 150            | 120          |
| 2019 | 120                                 | 100                                | 170            | 130          |
| 2020 | 100                                 | 80                                 | 180            | 140          |

Source: Ortiz et al (2021), “An Analysis of World Protests 2006-2020”, https://doi.org/10.1007/978-3-030-88513-7_2

And education?
- How can education promote active and informed citizenship while also acknowledging legitimate concerns about the functioning of democracy? Beyond teaching, how can education institutions help democracy thrive within their walls as well as locally (e.g., by fostering intergenerational and cross-cultural dialogue)?
- How can education help people understand the relationship between formal political processes and grassroots movements or protests? How can educators provide a balanced view of different forms of civic participation while tapping into learners' political interests?
- How does access to civic education and opportunities for student voice and civic engagement vary according to socio-economic status, gender, migration background and disability or special educational needs status? How can these activities be made more inclusive?

TRENDS SHAPING EDUCATION 2025 © OECD 2025
```
Industry’s list of the ten most commercially successful artists performed in English; by 2022, this share had halved. In several European countries, the share of domestic artists in the top of the end-of-year singles charts increased between 2012 and 2022, while English-speaking artists declined.

This shift may be driven by the rise of music streaming, which gives consumers more choice and incentivises global record companies to invest in local talent. However, the streaming landscape remains dominated by large firms from Asia, Europe, and North America, and remuneration models favour big artists, making it difficult for many to earn a sustainable income. This points to the ongoing challenge of creating streaming platforms and revenue models that support smaller and emerging artists.

The English language continues to have an outsized influence, meaning that people will still want to learn, consume and create in it. However, consumers are clearly drawn to content in their own language and, increasingly, to more diverse global voices. Arts and language education play an important role in meeting this demand, ensuring that local cultures continue to thrive through globalisation.

### Figure 4.4. Speaking in tongues
Share of Wikipedia editors by language (2001-2024)

json
{
  "data": {
    "years": [
      2001, 2002, 2003, 2004, 2005, 2006, 2007, 
      2008, 2009, 2010, 2011, 2012, 2013, 2014, 
      2015, 2016, 2017, 2018, 2019, 2020, 2021, 
      2022, 2023, 2024
    ],
    "languages": {
      "English": [
        // data points for English
      ],
      "Spanish": [
        // data points for Spanish
      ],
      "French": [
        // data points for French
      ],
      "German": [
        // data points for German
      ],
      "Italian": [
        // data points for Italian
      ],
      "Russian": [
        // data points for Russian
      ],
      "Japanese": [
        // data points for Japanese
      ],
      "Chinese": [
        // data points for Chinese
      ],
      "Farsi": [
        // data points for Farsi
      ],
      "Hebrew": [
        // data points for Hebrew
      ],
      "Other languages": [
        // data points for Other languages
      ]
    }
  }
}
```

Source: WikiMedia Commons (2024), “Wikipedia editors by language over time”, https://commons.wikimedia.org/wiki/File:Wikipedia_editors_by_language_over_time.png

---

And education?
- Arts, literature and music curricula are often seen to play a crucial role in transmitting a specific cultural heritage, preserving national languages, culture, and identity. How can they do this while addressing historical imbalances, reflecting national minority perspectives, and including diverse voices from around the world?
- How are learners’ online activities and cultural consumption influencing their creativity, self-expression, foreign language choices, and learning methods? How can educators tap into these interests?
- How might advances in AI and translation technologies reshape the teaching and learning of foreign languages? How can educators ensure language learning remains relevant?
```
Divide and conquer? Populism and polarisation

Some expected that globalisation would lead to the spread of liberal and progressive values worldwide. However, there are signs of a growing divide between countries on social issues such as sexual orientation, abortion, and the importance of children’s obedience. We also see increasing values polarisation within countries, with populist, far-left, and far-right parties increasing their vote share in elections. While civic education may help to restore faith in democracy, addressing the social and economic factors driving the rise of populism will be a bigger challenge. Educators also face the task of promoting social cohesion in increasingly divided societies.

### Figure 4.5. A growing ‘values gap’

Mean endorsement of ‘emancipative values’ by world region (1981-2022)

json
{
  "data": [
    {
      "region": "Africa",
      "values": [0.1, 0.2, 0.3, 0.4, 0.5, 0.3, 0.4]
    },
    {
      "region": "Asia",
      "values": [0.1, 0.2, 0.2, 0.3, 0.4, 0.4, 0.5]
    },
    {
      "region": "Europe",
      "values": [0.2, 0.3, 0.3, 0.4, 0.5, 0.5, 0.4]
    },
    {
      "region": "North America",
      "values": [0.3, 0.3, 0.4, 0.5, 0.5, 0.5, 0.5]
    },
    {
      "region": "Oceania",
      "values": [0.2, 0.3, 0.4, 0.4, 0.5, 0.5, 0.3]
    },
    {
      "region": "South America",
      "values": [0.2, 0.3, 0.4, 0.4, 0.4, 0.5, 0.4]
    }
  ],
  "note": "Emancipative values prioritise individual freedom over group conformity. The chart represents the normalised mean endorsement of seven items from the World Values Survey across seven timepoints. All items are coded so that higher scores reflect higher loadings on the index of emancipative values."
}
```

While some predicted that globalisation would see people in different countries increasingly adopt similar positions on social issues, surveys point to a widening gap between world regions regarding support for ‘emancipative values’. These values emphasise individual freedom over group conformity and include views on issues such as sexual orientation, abortion, and whether it is important for children to be obedient. While survey data from Oceania, Europe, and the Americas show growing support for emancipative values, average support has remained relatively stable in Asia and declined in Africa, meaning the ‘values gap’ between these regions has grown.

Shifts in support for political parties point to increasing polarisation within countries. Across 31 European democracies, the combined vote share of populist, far-left, and far-right parties surged from around 12% in the early 1990s to 30% in 2022. Populist parties often see society as divided into two opposing groups – e.g., the ‘pure people’ and the ‘corrupt elite’ – and argue that politics should reflect the general will of ‘the people’. Since the 2015 refugee crisis, there has been a notable increase in votes for far-right populist parties that combine these beliefs with hostility towards migrants and minorities. Far-left populists have also increased their vote share, combining populist ideas and approaches with a critique of prevailing.
```
Education holds the promise of restoring faith in democracy by empowering people to influence decision-making within their community and beyond. However, some issues driving the growth of populism may be harder to solve. In many countries, inter-generational inequalities in housing, jobs, and wages have increased youth support for populists who promise to address these concerns. The education sector plays a crucial role in meeting these complex challenges, which will require action in other policy areas.

In the short term, increasing polarization means educators face the challenge of promoting social cohesion and building consensus across divides while respecting diverse viewpoints and avoiding indoctrination.

### A populist wave

Vote share of parties by category, 31 European countries (1993-2022)

json
{
  "years": [1993, 1995, 1997, 1999, 2001, 2003, 2005, 2007, 2009, 2011, 2013, 2015, 2017, 2019, 2021],
  "far_right": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  "far_right_populist": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  "populist": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  "far_left_populist": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  "far_left": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
}
```

And education?

- How can educators promote social cohesion in a context where students and their families may hold radically opposing social, political, or religious beliefs? What practices can support effective listening and the negotiation of different world views in the classroom?
- What are the realistic limits of education in tackling political polarization and its underlying causes? How can policymakers and education leaders support teachers in reflecting on how their own beliefs influence their teaching?
- How does increasing polarization affect the teaching of issues like gender and sexuality, immigration, or climate action? How might the arrival of populist parties in power influence the way these topics are addressed in national curricula?
```
# Table of Contents

- Foreword 3
- Executive Summary
  - A polarised world 8
  - New forms of progress 9
- 1 Global trends and the future of education in 2025
  - Key trends 10
  - Cross-cutting themes 12
  - Futures thinking 15
- 2 Global conflict and co-operation
  - The cost of global conflict 24
  - Demographics on the move 26
  - Changing dynamics of global trade 28
  - Energy security 30
  - Co-operation on climate change 32
  - Global science collaboration and technological innovation 34
  - Global conflict and co-operation – in the future 36
  - Notes and sources 38
- 3 Work and progress
  - Skill over: mastering the twin transitions 42
  - A balancing act: young adults and society in transition 44
  - Them that’s got shall get: economic inequality 46
  - Yes we can? Uneven gender perceptions, participation, and rights 48
  - Home and away: digital dynamics in life and work 50
  - Changing our ways: towards sustainable living 52
  - Work and progress – in the future 54
  - Notes and sources 56
- 4 Voices and storytelling
  - Democracy and its discontents 62
  - Challenging the canon: diverse voices in a globalised world 64
  - Divide and conquer? Populism and polarisation 66
  - Freedom and fake news in the digital age 68
  - The digital stage: crafting your online persona 70
  - Look who’s talking! 72
```
## Freedom and fake news in the digital age

Recent advances in digital technology have opened democratic debate to new voices. However, this does not necessarily coincide with greater freedom of expression. Press freedom has declined in some countries, with journalists and media organisations facing an increasingly hostile environment. The explosion of social media has also enabled the spread of disinformation and the rise of more polarised forms of journalism. These trends not only sow division in some societies, but also threaten the functioning of democracies. Advancements in artificial intelligence (AI) technologies may intensify these challenges but could also be part of the solution. How can education equip people with the critical skills to distinguish between facts, falsehoods, and opinions in a changing information landscape?

### Figure 4.7. Fading ink: the decline of press freedom

Evolution of ratings on the World Press Freedom Index, OECD countries (2015-2021)

json
{
  "years": ["2015", "2016", "2017", "2018", "2019", "2020", "2021"],
  "ratings": {
    "Good": [60, 50, 50, 50, 45, 40, 35],
    "Satisfactory": [30, 35, 40, 40, 35, 30, 25],
    "Problematic": [7, 12, 8, 8, 15, 20, 25],
    "Difficult": [3, 3, 2, 2, 5, 10, 15]
  }
}
```

While the spread of digital technologies has opened democratic debate to new voices, this expansion has not necessarily led to more freedom of expression. The share of OECD countries with a 'good' rating or for press freedom on the World Press Freedom Index halved between 2015 and 2021. These declines are partly driven by declining public trust in the media and increasing attacks on journalists by politicians. Meanwhile, people’s engagement with social media has enabled the rise of opinion journalism and the spread of mis- and disinformation. These trends are fuelling polarisation in democratic societies.

While misinformation refers to false or misleading content that is made or shared without bad intentions, disinformation is deliberately crafted and spread to deceive. Both have become significant threats to democratic processes. One study found a steady increase in disinformation targeting elections in 53 countries between 2016 and 2021. Examples included false or misleading information about voting procedures, claims of electoral fraud, and attempts to cast doubt on postal or overseas voting. In most cases, the source of disinformation was traced to an unspecified social media user, although their profiles often revealed their political views or suggested they were part of a coordinated campaign. In some 17% of cases, however, political candidates or figures were directly involved in spreading disinformation.

Advances in AI threaten to intensify existing disinformation challenges and further empower authoritarian regimes to monitor citizens and suppress free speech. By 2023, AI had already been used in disinformation.
```
# Disinformation and Democracy

## Cases of disinformation targeting elections across 53 countries (2016-2022)

json
{
  "data": [
    {"year": 2016, "cases_per_year": 50},
    {"year": 2017, "cases_per_year": 100},
    {"year": 2018, "cases_per_year": 150},
    {"year": 2019, "cases_per_year": 250},
    {"year": 2020, "cases_per_year": 200},
    {"year": 2021, "cases_per_year": 150},
    {"year": 2022, "cases_per_year": 0}
  ]
}
```

## And education?
- How is the changing information landscape shaping young people’s civic knowledge and political engagement? How can education foster a culture of responsible digital citizenship that balances freedom of expression with the need for accurate and respectful discourse?
- Many OECD countries have seen declines in student performance in foundational skills like numeracy and literacy, which are essential for more complex skills like media literacy and critical thinking. How can education systems address both sets of skills in a way that complements rather than compromises one for the other?
- What strategies can help to ensure that people who are no longer in formal education also have the skills to distinguish between fact, falsehood, and opinion?
```

The digital stage: crafting your online persona

The ubiquity of the Internet and digital devices like smartphones and tablets has paved the way for new forms of expression. Influencers, podcasters, and self-published authors are expanding their global reach, potentially bringing more voices into global conversations. However, the persistence of digital divides within and between countries means some people are better positioned to become online content creators than others. What role can education play in fostering a more inclusive and democratic digital discourse?

Figure 4.9. The world at your fingertips

Active mobile-broadband subscriptions per 100 inhabitants, worldwide by income group (2009-2022)

|     Year     | High income countries | Upper-middle-income countries | Lower-middle-income countries | World       |
|--------------|-----------------------|-------------------------------|-------------------------------|-------------|
| 2009         | 51                    | 14                            | 8                             | 24          |
| 2010         | 60                    | 17                            | 10                            | 27          |
| 2011         | 67                    | 23                            | 12                            | 30          |
| 2012         | 74                    | 29                            | 15                            | 33          |
| 2013         | 78                    | 35                            | 16                            | 36          |
| 2014         | 82                    | 41                            | 19                            | 39          |
| 2015         | 85                    | 49                            | 22                            | 43          |
| 2016         | 94                    | 58                            | 28                            | 49          |
| 2017         | 100                   | 63                            | 36                            | 55          |
| 2018         | 108                   | 78                            | 46                            | 62          |
| 2019         | 110                   | 85                            | 58                            | 67          |
| 2020         | 113                   | 92                            | 66                            | 74          |
| 2021         | 118                   | 100                           | 70                            | 80          |
| 2022         | 120                   | 104                           | 80                            | 83          |

Source: OECD calculations based on ITU (2024), “Active mobile-broadband subscriptions” (Indicator), https://databuh.itu.int/data/?i=11632.

The number of digitally connected people is growing rapidly, and there has been some progress on closing divides within and between countries. The number of fixed broadband subscriptions per 100 inhabitants worldwide increased from 3.7 in 2005 to 17.8 in 2021. Active mobile-broadband subscriptions soared from 8.3 per 100 inhabitants to 83.5 between 2009 and 2022, reflecting the spread of smartphones and other personal devices.

As connectivity expands, more people are becoming online content creators. On average across OECD countries with available data, the share of individuals reporting they had used the Internet to upload self-created content increased from 10.3% in 2008 to 38.3% in 2020. This includes podcasting, which has grown significantly since the format first appeared in 2003. The number of podcasts launched each year increased twofold between 2009 and 2019, with new launches and listener numbers surging in the early years of the COVID-19 pandemic. The number of self-published books also saw a 264% increase between 2017 and 2022, facilitated by the availability of inexpensive publishing services.

Content creation is becoming more lucrative, with companies paying social media influencers to promote their products and services. Estimates placed the value of the global influencer marketing industry at USD 16.4 billion in 2022, an almost tenfold increase since 2016. The growing returns of the influencer economy may be influencing young people's career choices. Data from the United States suggests some 57% of 13-to-26-year-olds would become an influencer if given the opportunity.

However, there are concerns about influencers and other content creators spreading false and misleading content, promoting unrealistic lifestyles, impacting mental health, and exposing young people to financial...


health and privacy risks. These concerns are significant given the size of their audiences and the lack of vetting from traditional gatekeepers. Disinformation concerns have grown since the COVID-19 pandemic and Russia’s invasion of Ukraine. One study traced 65% of anti-vaccine content on Facebook and Twitter to a handful of influencers, dubbed ‘the Disinformation Dozen.’

Moreover, persistent digital divides mean that not everyone can become an online content creator. In 2022, the average number of mobile-broadband subscriptions per 100 people was over three times higher in high-income countries than in low-income countries. Within countries, rural, remote, and disadvantaged populations often face connectivity gaps. There are also disparities in how people use digital technologies, with younger, wealthier, and more educated individuals more likely to upload self-created content. Education can help to bridge these gaps by equipping people of all ages and backgrounds with the skills to debate and create online, but also with strategies to balance their digital and real-world activities.

### Creative differences

Share of individuals who have used the Internet to upload self-created content in the past three months, OECD average (2008-2023)

json
{
    "years": [
        "2008", "2009", "2010", "2011", "2012", "2013", "2014", 
        "2015", "2016", "2017", "2018", "2019", "2020"
    ],
    "data": {
        "high_level_of_educational_attainment": [
            25, 30, 30, 30, 30, 35, 35, 35, 40, 45, 45, 45, 50
        ],
        "all_16_to_74_year_olds": [
            10, 15, 15, 15, 20, 20, 20, 25, 30, 35, 35, 35, 40
        ],
        "low_level_of_educational_attainment": [
            5, 10, 10, 15, 15, 20, 20, 25, 30, 30, 35, 35, 40
        ]
    }
}
```

**And education?**
- How is the rise of content creation shaping young people’s career aspirations? How can education adapt to these shifts and help students develop realistic and relevant career goals?
- How can education systems help teachers and other staff keep abreast of developments in the online world and the opportunities and risks these present for their students?
- How can education systems adapt to the rapid evolution of AI technologies that impact information consumption and creation? What steps can be taken to ensure students are prepared to critically engage with AI-generated content?
```

Look who’s talking!

Smartphones and laptops are no longer the only connected devices transforming how we interact and share information. More everyday objects are now connected to the Internet and share data seamlessly; from smart TVs and voice assistants to manufacturing robots. Advances in connectivity and AI are driving this growth, promising to optimise how we live, work, and learn. However, these technologies also raise privacy concerns, particularly for children. How can parents and educators leverage their benefits while respecting and protecting children’s privacy?

### Internet of Things (IoT) firm creation, worldwide (1980-2020)

#### JSON Table
json
{
  "years": [1980, 1981, 1982, 1983, 1984, 1985, 1986, 1987, 1988, 1989, 1990,
            1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999, 2000,
            2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010,
            2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020],
  "number_of_firms_created": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                               0, 0, 0, 0, 1, 1, 2, 5, 20, 50,
                               75, 100, 200, 400, 600, 800, 1000,
                               1200, 1300, 1400, 1200, 1300, 1400,
                               1600, 1700, 1800, 1900, 2000, 2100],
  "iot_total_firms_created_percentage": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                          0, 0, 0, 0, 0, 0, 0.5, 1, 1.5, 2,
                                          2.5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
                                          3, 3, 3, 3, 3]
}
```

The Internet of Things (IoT) includes everyday objects connected to the Internet that can send and receive data without human intervention. IoT devices are increasingly common in homes, often used for entertainment (e.g., smart TVs, gaming consoles) or home automation (e.g., virtual assistants). The growth of IoT is also reflected in the surge of new firms specializing in IoT goods and services. 

AI and technological advances are also bringing robots into more aspects of our lives. For example, robots can help in health and education. Researchers are using AI to develop emotion-detecting algorithms to improve robots' roles in health and education. Entertainment robots have already been used to address mental health issues like loneliness and to improve social skills among young people with autism spectrum disorder. Immersive technologies such as virtual reality (VR) offer similar potential. For example, VR allows people to inhabit another body and take on someone else’s.

TRENDS SHAPING EDUCATION 2025 © OECD 2025
```
As connected objects become more embedded in our daily routines and environments, concerns about security and privacy, particularly for children, are growing. Unlike smartphones or computers, IoT devices are always connected, sharing data constantly. As they become more pervasive and interconnected, they may share large amounts of data about children without their or their parents' consent. VR magnifies and extends these risks, routinely collecting data on users’ bodies, responses, and environment. While these technologies can support children's health, safety, and learning, they also risk violating their privacy and autonomy. 

How should education evolve in a world where children may be interacting with voice assistants before they can read or write and will likely collaborate with robots in their future workplaces?

### Annual number of industrial robots installed worldwide (2012-22)

json
{
  "data": [
    {
      "year": 2012,
      "installations": 200
    },
    {
      "year": 2013,
      "installations": 250
    },
    {
      "year": 2014,
      "installations": 300
    },
    {
      "year": 2015,
      "installations": 350
    },
    {
      "year": 2016,
      "installations": 400
    },
    {
      "year": 2017,
      "installations": 450
    },
    {
      "year": 2018,
      "installations": 500
    },
    {
      "year": 2019,
      "installations": 550
    },
    {
      "year": 2020,
      "installations": 580
    },
    {
      "year": 2021,
      "installations": 600
    },
    {
      "year": 2022,
      "installations": 620
    }
  ]
}
```

**And education?**
- How can the education sector balance the potential benefits of technological innovation with the duty to protect students? How can policymakers engage learners, caregivers, educators, and the tech sector in developing regulatory frameworks that address this balance?
- Many people lack knowledge of privacy issues and often agree to terms of service without reading them. How can educators partner with caregivers to improve digital literacy and address these challenges in both classrooms and homes?
- What skills are needed to harness the potential of robots in the workplace, and how well is education and training currently meeting these needs? What are the implications for primary and secondary education curricula, as well as more specialised and vocational pathways?
```
## Voices and storytelling – in the future

Democracies are grappling with declining voter turnout, rising unrest, and growing polarisation. Digital technologies have transformed communication and cultural expression but intensify concerns about false and misleading information, privacy, and surveillance. How might these trends evolve or change course and what are the implications for education? This section explores potential futures for 2040, accompanied by stories that illustrate the opportunities, challenges, and tensions experienced by education stakeholders.

The futures below are not predictions but are designed to inspire reflection and guide action in the present.

### Future 1 - Culture in conflict

- Political parties of the early 21st century have faded, replaced by movements reflecting polarised worldviews. Policies on issues like climate and immigration vary widely across OECD countries.
- The digital world is deeply fragmented, with distinct devices, platforms, and augmented reality spaces catering to different political identities.
- Cultural industries in Asia, Africa, and Latin America dominate, offering diverse content that has shifted power from Hollywood and Europe.

**Excerpt from Elias, 14-year-old student:**

I thought we were all on the same page until people in my class started saying stupid things about immigration—friends I’ve known since primary school! And some teachers would just change the subject because they don’t know how to handle it. But some people have changed for the better. A lot of my friends on the DiasporaWeb network give advice on how to handle debates in class, and I’ve shared tonnes of videoclips that our teachers let us discuss. And there’s also a lot more interest in learning Yorùbá, mostly because people love the music and films, but it’s also made them more curious about where my family is from.

### Future 2 - No representation without participation

- Democracies worldwide have embraced participatory and deliberative practices. Citizens serve on local assemblies for six months each year, reducing the need for elected officials.
- Citizens chosen by lottery conduct national policy reviews, presenting balanced evidence to inform public votes on proposals.
- Growing distrust of technology firms has led to the emergence of user-owned social networks founded through means-tested contributions.

**Excerpt from Mina, early childhood director:**

I thought this ‘distributed leadership’ business would lighten my load, but it often feels like managing more voices. The more affluent parents had plenty to say in Council, but some immigrant parents barely spoke. The local university helped us design a more inclusive parent participation model, which is making a difference. Luckily, a few parents in finance have taken on the budget work that used to eat up my time. I worried our kids would struggle in a democratic classroom. With parents’ influence, it’s hard to know if kids' views are really their own, but they’ve done a great job establishing classroom rules, and they’re better at following them than before.



Notes and sources
1. International IDEA (2024), Voter Turnout Database (database), [link](https://www.idea.int/data-tools/data/voter-turnout-database).
2. Dezelan, T. (2023), “Young people’s participation in European democratic processes”, [link](https://www.europarl.europa.eu/ReqData/etudes/STUD/2023/745820/IPOL_STU(2023)745820_EN.pdf).
3. Foa, S. et al. (2020), Global Satisfaction with Democracy 2020, Centre for the Future of Democracy, [link](https://www.cam.ac.uk/system/files/report2020_003.pdf); Foa, R. et al. (2020), Youth and Satisfaction with Democracy: Reversing the Democratic Disconnect, Centre for the Future of Democracy, [link](https://www.cam.ac.uk/system/files/youth_and_satisfaction_with_democracy.pdf).
4. OECD (2021), Perspectives on Global Development 2021: From Protest to Progress?, OECD Publishing, Paris, [link](https://doi.org/10.1787/405e4c32-en).
5. Carnegie (n.d.), Carnegie Endowment for International Peace’s Climate Protest Tracker, [link](https://carnegieendowment.org/features/climate-protest-tracker?lang=en).
6. Ortiz, I. et al. (2021), “An Analysis of World Protests 2006–2020”, in World Protests, Springer International Publishing, Cham, [link](https://doi.org/10.1007/978-3-030-88513-7_2).
7. Ortiz, I. et al. (2021), “An Analysis of World Protests 2006–2020”, in World Protests, Springer International Publishing, Cham, [link](https://doi.org/10.1007/978-3-030-88513-7_2).
8. OECD (2024), OECD Survey on Drivers of Trust in Public Institutions – 2024 Results: Building Trust in a Complex Policy Environment, OECD Publishing, Paris, [link](https://doi.org/10.1787/9a20554b-en).
9. Schultz, W. et al. (2023), Education for Citizenship in Times of Global Challenge: IEA International Citizenship Education Study 2022 International Report, IEA, [link](https://www.iea.nl/sites/default/files/2024-02/ICCS-2022-International-Report-Revised.pdf).
10. The Nobel Prize (2024), “All Nobel Prizes in Literature”, [link](https://www.nobelprize.org/prizes/lists/all-nobel-prizes-in-literature/).
11. Dusseaux, A. (2021), “The Rise of the Rest”, [link](https://www.adssx.com/p/the-rise-of-the-rest); WikiMedia Commons (2024), [link](https://commons.wikimedia.org/wiki/File:Wikipedia_editors_by_language_over_time.png).
12. IFPI (2023), Global Music Report 2023, IFPI, [link](https://www.ifpi.org/wp-content/uploads/2020/03/Global_Music_Report_2023_State_of_The_Industry.pdf).
13. Page, W. and C. Dalla Riva (2023), “‘Glocalisation’ of Music Streaming within and across Europe”, London School of Economics, [link](https://www.lse.ac.uk/european-institute/Assets/Documents/LEQSDiscussion-Papers/EIQPaper182.pdf).
14. Page, W. and C. Dalla Riva (2023), “‘Glocalisation’ of Music Streaming within and across Europe”, London School of Economics, [link](https://www.lse.ac.uk/european-institute/Assets/Documents/LEQSDiscussion-Papers/EIQPaper182.pdf).


15. UNESCO (2022), Revenue distributions and transformation in the music streaming value chain, [source](https://www.unesco.org/creativity/sites/default/files/medias/fichiers/2023/01/2-policy_perspectives_music_en-web.pdf).

16. Jackson, J. and D. Medvedev (2024), “Worldwide divergence of values”, Nature Communications, Vol. 15/1, [source](https://doi.org/10.1038/s41467-024-46581-5).

17. The concept of populism is subject to significant theoretical debate. The definitions used here are drawn from Roodujin, M. et al. (2023), “The PopulList: A Database of Populist, Far-Left, and Far-Right Parties Using Expert-Informed Qualitative Comparative Classification (EiQCC)”, British Journal of Political Science, Vol. 54/3, pp. 969-978, [source](https://doi.org/10.1017/s0007123423000431).

18. Foa, R. et al. (2020), Youth and Satisfaction with Democracy: Reversing the Democratic Disconnect, Centre for the Future of Democracy, [source](https://www.cam.ac.uk/system/files/youth_and_satisfaction_with_democracy.pdf).

19. Reporters Without Borders (2024), World Press Freedom Index, [source](https://rsf.org/en/index).

20. OECD (2024), “The OECD Truth Quest Survey: Methodology and findings”, OECD Digital Economy Papers, No. 369, OECD Publishing, Paris, [source](https://doi.org/10.1787/92a94c0f-en).

21. International IDEA (2023), The Information Environment Around Elections, [source](https://www.idea.int/theme/information-communication-and-technology-electoral-processes/information-environment-around-elections).

22. Frank, A., A. Shahbaz and K. Vestensso (2023), Freedom on the Net 2023: The Repressive Power of Artificial Intelligence, Freedom House, [source](https://freedomhouse.org/report/freedom-net/2023/repressive-power-artificial-intelligence).

23. Costello, T. et al. (2024), “Durably reducing conspiracy beliefs through dialogues with AI”, Science, Vol. 385, No.6714, [source](https://doi.org/10.1126/science.adq1814).

24. ITU (2024), “Active mobile-broadband subscriptions” (indicator), [source](https://datahub.itu.int/data/?i=11632).

25. OECD (2024), ICT Access and Usage by Individuals (database), [source](https://doi.org/10.1787/b9823565-en).

26. Listen Notes (2024), “Podcast Stats: How many podcasts are there?”, [source](https://www.listennotes.com/podcast-stats/) (accessed 14 October 2024).

27. Dollwet, S. (2024), “Capitalizing On Self-Publishing In Today’s Market”, [source](https://www.forbes.com/councils/forbesbusinesscouncil/2024/02/02/capitalizing-on-self-publishing-intodays-market/).

28. Influencer Marketing Hub (2024), The State of Influencer Marketing 2024, [source](https://influencermarketinghub.com/influencer-marketing-benchmark-report/).

29. Briggs, E. (2023), “Gen Zers Still Really Want to Be Influencers”, [source](https://pro.morningconsult.com/analysis/gen-z-interest-influencer-marketing).
```
# Bodies and Minds

## Mind matters: mental health concerns
- Quick fixes? Addictions old and new
- In it together: One Health and environmental health threats
- Later, Baby! Fertility and reproductive health
- Tech ability: disability and advances in medicine and technology
- Who cares? Paid and unpaid care work
- Bodies and minds – in the future

## Figures
json
{
  "Figures": [
    {
      "Figure": "1.1",
      "Title": "Trends Shaping Education 2025: Overview of chapters and sub-chapters",
      "Page": 12
    },
    {
      "Figure": "1.2",
      "Title": "Future scenarios developed in this report",
      "Page": 16
    },
    {
      "Figure": "1.3",
      "Title": "Exploring implications for different education stakeholders",
      "Page": 17
    },
    {
      "Figure": "1.4",
      "Title": "Exploring implications for different levels and areas of education",
      "Page": 18
    },
    {
      "Figure": "1.5",
      "Title": "Futures wheel example",
      "Page": 19
    },
    {
      "Figure": "1.6",
      "Title": "Stress testing example",
      "Page": 20
    },
    {
      "Figure": "2.1",
      "Title": "Global conflict on the rise",
      "Page": 24
    },
    {
      "Figure": "2.2",
      "Title": "An end to the peace dividend?",
      "Page": 25
    },
    {
      "Figure": "3.1",
      "Title": "Labour migration and asylum applications on the rise",
      "Page": 26
    },
    {
      "Figure": "3.2",
      "Title": "Diverging dependencies",
      "Page": 27
    },
    {
      "Figure": "3.3",
      "Title": "Global trade slowing, restrictions rising",
      "Page": 28
    },
    {
      "Figure": "3.4",
      "Title": "The digital dynamics of trade",
      "Page": 29
    },
    {
      "Figure": "2.7",
      "Title": "An energy shock",
      "Page": 30
    },
    {
      "Figure": "2.8",
      "Title": "The energy transition",
      "Page": 31
    },
    {
      "Figure": "2.9",
      "Title": "Burning up",
      "Page": 32
    },
    {
      "Figure": "2.10",
      "Title": "Joining forces",
      "Page": 33
    },
    {
      "Figure": "2.11",
      "Title": "Rising research collaboration",
      "Page": 34
    },
    {
      "Figure": "2.12",
      "Title": "Export restrictions on critical raw materials are increasing",
      "Page": 35
    },
    {
      "Figure": "3.1",
      "Title": "All skills are more common and demand for AI labour is rising, but both still low",
      "Page": 42
    },
    {
      "Figure": "3.2",
      "Title": "New green jobs are rising and polluting jobs declining",
      "Page": 43
    },
    {
      "Figure": "3.3",
      "Title": "Forever nesting? A growing share of young people are still living with their parents",
      "Page": 44
    },
    {
      "Figure": "3.4",
      "Title": "Seeking equilibrium: work-life balance is improving overall",
      "Page": 45
    },
    {
      "Figure": "3.5",
      "Title": "Converging world, unequal societies",
      "Page": 46
    },
    {
      "Figure": "3.6",
      "Title": "Low and middle incomes have been growing substantially less than higher incomes",
      "Page": 47
    },
    {
      "Figure": "3.7",
      "Title": "Attitudes about women’s roles are showing both progress and setbacks",
      "Page": 48
    },
    {
      "Figure": "3.8",
      "Title": "Social acceptance of homosexuality is improving overall",
      "Page": 49
    },
    {
      "Figure": "3.9",
      "Title": "More people are using e-gov services",
      "Page": 50
    },
    {
      "Figure": "3.10",
      "Title": "Telework is here to stay",
      "Page": 51
    },
    {
      "Figure": "3.11",
      "Title": "Meat consumption is rising overall",
      "Page": 52
    },
    {
      "Figure": "4.1",
      "Title": "Democracy in decline?",
      "Page": 62
    },
    {
      "Figure": "4.2",
      "Title": "We shall overcome",
      "Page": 63
    },
    {
      "Figure": "4.3",
      "Title": "Challenging the canon",
      "Page": 64
    },
    {
      "Figure": "4.4",
      "Title": "Speaking in tongues",
      "Page": 65
    },
    {
      "Figure": "4.5",
      "Title": "A growing 'values gap'",
      "Page": 66
    },
    {
      "Figure": "4.6",
      "Title": "A populist wave",
      "Page": 67
    },
    {
      "Figure": "4.7",
      "Title": "Reading linked: the decline of press freedom",
      "Page": 68
    },
    {
      "Figure": "4.8",
      "Title": "Disinformation and democracy",
      "Page": 69
    },
    {
      "Figure": "4.9",
      "Title": "The world at your fingertips",
      "Page": 70
    },
    {
      "Figure": "4.10",
      "Title": "Creative differences",
      "Page": 71
    },
    {
      "Figure": "4.11",
      "Title": "The next big thing",
      "Page": 72
    }
  ]
}
```
```
30 CCDH (2021), “The Disinformation Dozen: Why Platforms Must Act on Twelve Leading Online Anti-Vaxxers”, Centre for Countering Digital Hate, https://pro.morningconsult.com/analysis/gen-z-interest-influencer-marketing.

31 ITU (2024), “Active mobile-broadband subscriptions” (indicator), https://databuh.itu.int/data/?i=11632.

32 Possible explanations for the observed decrease in IoT firm creation include the consolidation of the IoT market through mergers and acquisitions, growing security concerns, and challenges with interoperability between platforms and ecosystems. See OECD (2023), Measuring the Internet of Things, OECD Publishing, Paris, https://doi.org/10.1787/021333b7-en; La Fors, K. (2022), Why the future of connected IoT in homes is child-centric, https://www.weforum.org/agenda/2022/08/why-the-future-of-connected-iot-in-homes-is-children-centric/.

33 La Fors, K. (2022), Why the future of connected IoT in homes is child-centric, https://www.weforum.org/agenda/2022/08/why-the-future-of-connected-iot-in-homes-is-children-centric/.

34 Maslej, N. et al. (2024), The AI Index 2024 Annual Report, AI Index Steering Committee, Institute for Human-Centered AI, Stanford University, https://aiindex.stanford.edu/wp-content/uploads/2024/05/HAI_AI-Index-Report-2024.pdf.

35 Nolan, A. (2021), “Making life richer, easier and healthier: Robots, their future and the roles for public policy”, OECD Science, Technology and Industry Policy Papers, No. 117, OECD Publishing, Paris, https://doi.org/10.1787/5ea15d01-en.

36 OECD (2024), OECD Digital Economy Outlook 2024 (Volume 1): Embracing the Technology Frontier, OECD Publishing, Paris, https://doi.org/10.1787/a1689dc5-en.

37 Haber, E. (2020), “The internet of children: Protecting children’s privacy in a hyper-connected world”, University of Illinois Law Review, Vol. 2020/4; La Fors, K. (2022), Why the future of connected IoT in homes is child-centric, https://www.weforum.org/agenda/2022/08/why-the-future-of-connected-iot-in-homes-is-children-centric.

38 OECD (2024), OECD Digital Economy Outlook 2024 (Volume 1): Embracing the Technology Frontier, OECD Publishing, Paris, https://doi.org/10.1787/a1689dc5-en.

39 TRENDS SHAPING EDUCATION 2025 © OECD 2025
```
## Infographic 5.1. Bodies and Minds – Chapter highlights

### Mental Health Concerns
- **Rank**: 
  - 3rd place (2018) 
  - 1st place (2024)
- **Insight**: People increasingly identify mental health as the biggest health problem.

### Addictions Old and New
- **Insight**: Smoking is decreasing, but opioid-related deaths are increasing, and concerns heighten around problematic digital use.

### Environmental Health Threats
- **Elements**: 
  - Microplastics 
  - Humans 
  - Animals 
  - Environment 
  - Allergies & asthma 
  - Antimicrobial resistance
- **Insight**: Health challenges increasingly stem from interconnected socio-ecological factors.

### Fertility and Reproductive Health
- **Data**:
  - 27.5 (1990)
  - 28.1 (1996)
  - 28.8 (2002)
  - 29.4 (2008)
  - 30.9 (2022)
- **Insight**: Mother's average age at childbirth is rising steadily across the OECD.

### Advances in Medicine and Technology
- **Data**:
  - 5 (2015)
  - 139 (2022)
- **Insight**: Number of AI medical devices approved by the United States FDA increased dramatically.

### Paid and Unpaid Care Work
- **Data**:
  - 1h28' (2015)
  - 4h23' (2015)
  - 1h34' (2023)
  - 4h16' (2023)
- **Insight**: Women still spend longer hours per day than men on unpaid care and domestic work.

### Table Representation as JSON
json
{
  "Mental Health Concerns": {
    "Rank": {
      "2018": "3rd place",
      "2024": "1st place"
    },
    "Insight": "People increasingly identify mental health as the biggest health problem."
  },
  "Addictions Old and New": {
    "Insight": "Smoking is decreasing, but opioid-related deaths are increasing, and concerns heighten around problematic digital use."
  },
  "Environmental Health Threats": {
    "Elements": [
      "Microplastics",
      "Humans",
      "Animals",
      "Environment",
      "Allergies & asthma",
      "Antimicrobial resistance"
    ],
    "Insight": "Health challenges increasingly stem from interconnected socio-ecological factors."
  },
  "Fertility and Reproductive Health": {
    "Data": {
      "1990": 27.5,
      "1996": 28.1,
      "2002": 28.8,
      "2008": 29.4,
      "2022": 30.9
    },
    "Insight": "Mother's average age at childbirth is rising steadily across the OECD."
  },
  "Advances in Medicine and Technology": {
    "Data": {
      "2015": 5,
      "2022": 139
    },
    "Insight": "Number of AI medical devices approved by the United States FDA increased dramatically."
  },
  "Paid and Unpaid Care Work": {
    "Data": {
      "2015": {
        "Men": "1h28'",
        "Women": "4h23'"
      },
      "2023": {
        "Men": "1h34'",
        "Women": "4h16'"
      }
    },
    "Insight": "Women still spend longer hours per day than men on unpaid care and domestic work."
  }
}
```
```
Mind matters: mental health concerns

As medicine continues to advance and life expectancy rises, modern life presents new health challenges. Since the COVID-19 pandemic, mental health has risen sharply as a major health concern. Today, symptoms of mental distress are more prevalent than they were before the pandemic, and mental health medication consumption is constantly increasing. Global suicide rates continue to decline, though some countries are not doing as well as others. How can education contribute to human flourishing by enhancing mental health and addressing distress among students and staff?

### Figure 5.1. Mental health has become a top health concern

Biggest health problem according to survey respondents across 31 countries (2018-2024)

| Year   | Mental Health | Cancer | Stress | Obesity | Drug Abuse | Coronavirus |
|--------|---------------|--------|--------|---------|------------|-------------|
| 2018   | 30            | 20     | 25     | 15      | 5          | 2           |
| 2019   | 32            | 22     | 26     | 16      | 4          | 3           |
| 2020   | 40            | 25     | 20     | 18      | 6          | 5           |
| 2021   | 50            | 30     | 22     | 20      | 8          | 10          |
| 2022   | 60            | 28     | 23     | 22      | 7          | 9           |
| 2023   | 70            | 29     | 25     | 23      | 10         | 12          |
| 2024   | 80            | 31     | 27     | 25      | 12         | 15          |

Note: Share of respondents who chose a condition as the biggest health problem facing people in their country today in a survey among 23,667 online adults under the age of 75 across 31 countries, last interviewed in summer 2024.

Source: IPSOS (2024). Ipsos Health Service Report 2024, https://www.ipsos.com/en/ipsos-health-service-report.

Globally, age-standardised rates of mental disorders remained relatively stable in the decades leading up to the COVID-19 pandemic, though they were consistently higher for women and for people with low socio-economic status. A troubling increase among those under 20 was noted in some high-income countries, especially for girls. During the pandemic, population’s mental health fluctuated across OECD countries, but post-pandemic levels of mental ill-health remain elevated. Notably, symptoms of depression and anxiety were more prevalent in 2022 than in 2019, likely due to the combined effects of various crises, such as the cost-of-living crisis, the climate crisis, and geopolitical tensions. People also worry about mental health: while men are less concerned than women, it remains the leading health concern for both sexes, with the level of concern rising by 17 percentage points since 2018.

The consumption of mental health medications has surged in the last decades. Global sales of psychotropic drugs increased, with the largest absolute increases in high-income countries, and in antidepressants. Consumption of medications for Attention Deficit Hyperactivity Disorder has also seen a sharp rise in high-income countries. Such trends could reflect improved access to care or diagnosis and declining stigma around mental health, or a lack of other treatment options. Recently, rapid advances in machine learning and artificial intelligence (AI) have raised hopes that such technologies could enhance the precision of mental health diagnoses, prognoses, and treatment options. Better understanding of neurodiversity, such as ADHD and autism, challenges education systems to adapt learning environments.
```
and meet diverse needs. This raises questions about how to best create inclusive settings that support all learners, including those with mental health issues or neurodiversity, and leverage their unique strengths?

While poor mental health is a known risk factor for suicide, global rates of death by suicide are decreasing. The trend downward before the pandemic has continued, on average, through the first two years of the pandemic. However, suicide rates vary almost six-fold between OECD countries, and in some, such as the United States, they have been rising for much of the last two decades, with worrying trends among youth aged 10-24. Deaths by suicide are much higher for men than women, but when examining suicidal intent and behavior the gender gap is far smaller, and in some areas even reversed. Given these trends, how can education enhance learners' mental health and resilience, and support their sense of purpose?

{
  "Table": {
    "Year": [1990, 1995, 2000, 2005, 2010, 2015, 2020, 2021],
    "Global": [19, 17, 16, 15, 14, 13, 9, 8],
    "High SDI": [13, 12, 11, 10, 9, 8, 7, 7],
    "High-middle SDI": [16, 15, 14, 13, 12, 11, 10, 10],
    "OECD": [11, 10, 9, 9, 8, 8, 7, 7]
  }
}

And education:
- How can education support mental health resilience, e.g., through curricula, pedagogy, or socio-emotional learning? What is education’s role in the timely identification and mitigation of mental health issues? How can whole-school approaches help to identify signs of distress, such as bullying, violence, truancy and early school leaving, and offer tailored support?
- How should teacher professional development and support staff resourcing be updated to raise awareness and address growing concerns about mental health? How can education institutions strengthen liaisons with healthcare and support teachers suffering mental distress themselves?
- Systemic factors worsen the risk of mental health challenges for specific groups. How does the intersection of poverty, minority status, gender, and disability impact mental health outcomes? What strategies could support at-risk students effectively and how to resource them?


## Quick fixes? Addictions old and new

Substance addictions that were common in the 20th century, such as smoking and alcoholism, are in decline, but new addictions are emerging, such as the increasing use of synthetic opioids. In recent years, other addictive patterns have surfaced, such as obsessive or compulsive use of digital media. Although the growing use of digital devices, the Internet, and social media can bring significant benefits, overuse can lead to addictive behaviour with adverse effects. How can education discourage risky behaviour and support positive digital use?

### Figure 5.3. Share of daily smokers has mostly gone down

#### Share of population aged 15 and over who are daily smokers, selected countries (2013 or nearest; 2023 or latest)

json
{
  "data": [
    {"country": "Iceland", "percentage": 5, "year": "2023"},
    {"country": "Norway", "percentage": 6, "year": "2023"},
    {"country": "Sweden", "percentage": 8, "year": "2023"},
    {"country": "United States", "percentage": 9, "year": "2023"},
    {"country": "Australia", "percentage": 10, "year": "2023"},
    {"country": "United Kingdom", "percentage": 11, "year": "2023"},
    {"country": "Canada", "percentage": 12, "year": "2023"},
    {"country": "Germany", "percentage": 15, "year": "2023"},
    {"country": "France", "percentage": 17, "year": "2023"},
    {"country": "Spain", "percentage": 22, "year": "2023"},
    {"country": "Italy", "percentage": 23, "year": "2023"},
    {"country": "Poland", "percentage": 26, "year": "2023"},
    {"country": "Hungary", "percentage": 27, "year": "2023"},
    {"country": "Lithuania", "percentage": 29, "year": "2023"},
    {"country": "Turkey", "percentage": 30, "year": "2023"},
    {"country": "Greece", "percentage": 34, "year": "2023"},
    {"country": "New Zealand", "percentage": 20, "year": "2023"}
  ]
}
```

Source: OECD (2024), "Tobacco consumption", Risk factors for Health, https://data-explorer.oecd.org (accessed 1 August 2024).

Smoking, a major addictive behaviour of the 20th century and a leading cause of numerous diseases, has seen a significant decline across OECD countries, with an average 23% decrease between 2011 and 2021. This trend has continued through the COVID-19 pandemic in most nations. However, the decline has not been uniform across countries and has often been accompanied by a rise in regular vaping among young people, though overall vaping rates remain low (3.2%). Similarly, alcohol use disorder has declined globally since the early 2000s, though rates in high-income countries have remained relatively stable.

While drug use disorders have remained relatively stable globally over the past three decades, opioid-related deaths have increased by an average of 20% across the OECD since 2010, driven by the rising consumption of synthetic opioids. The United States, Lithuania, Türkiye, and Canada have seen increases of more than 70%. While both sexes are affected, men have been impacted more significantly. A key trend in illicit synthetic drug markets is the rapid expansion of online platforms, especially on the dark web.

New addictive behaviours are emerging, especially around digital overuse. While moderate digital use offers many benefits, such as peer interaction, skill development, self-experimentation, and social support, problematic use—excessive and compulsive use of digital media—can negatively affect the user’s life. It is linked to hostility and mental health issues like depression and anxiety and may manifest in loss of control, withdrawal symptoms, neglect of other activities, reduced sleep, and lower self-reliance.

There is no consensus that problematic digital use amounts to addiction, and no major diagnostic system has yet included it as a diagnosable mental health issue, yet scholars note its similarities to other addictive behaviours.
```
behaviours. The past two decades have seen a rise in problematic digital use – although definitions differ – which worsened dramatically during the pandemic. Features like autopilot and infinite scroll are said to contribute to excessive use. In 2022, over 80% of Americans aged 13–17 reported feeling "addicted" to their smartphones. Although evidence is still inconclusive, concerns are growing over the effects on attention span (coined "TikTok Brain") and the link between increased social media use and worsening mental health among young people. However, distinguishing between healthy and harmful digital use is challenging. The same media content can affect children differently depending on their individual characteristics, such as their social and emotional skills, and on how and why the content is used. How can education help learners balance their digital and offline lives?

### Figure 5.4. Digital addictions are on the rise globally

#### Prevalence estimates of digital addictions by period of publication, meta-analysis of studies, global (2004-2021)

| Addiction Type          | 2000-2004 | 2005-2009 | 2010-2014 | 2015-2019 | 2020-2021 |
|------------------------|-----------|-----------|-----------|-----------|-----------|
| Internet Addiction     | 10        | 15        | 20        | 25        | 30        |
| Game Addiction         | 5         | 10        | 15        | 20        | 25        |
| Smartphone Addiction    | 0         | 5         | 10        | 15        | 30        |
| Social Media Addiction  | 0         | 5         | 10        | 20        | 35        |

**Note:** Using the source article’s categorisation of addictions.  
**Source:** Data from Meng et al. (2022), "Global prevalence of digital addiction in general population: A systematic review and meta-analysis", https://www.sciencedirect.com/science/article/abs/pii/S0272735822000137, © Elsevier (2022).  

### And education?
- Smoking, alcoholism and drug addictions, although declining, remain important problems, especially for young people. What are the responsibilities of schools, in collaboration with families, communities and other partners, to address risky and addictive behaviour?
- Should teacher professional development be updated to address the identification of and response to addictive behaviours? What are the respective roles of teachers and other professionals when these behaviours arise?
- How can education institutions promote beneficial use of digital technologies among learners? What practices, regulations and approaches would support these efforts? How could curricula address self-regulation, responsible digital use, and critical thinking? How could schools encourage breaks from screens, and outdoor, physical activity, as well as mindfulness practice?


In it together: One Health and environmental health threats

In an increasingly interconnected world, health challenges form a complex web impacting humans, animals, and the environment. Over the past two decades, the One Health approach has gained importance by recognizing the interconnection of natural and human systems, and promoting coordinated action across human and animal health, agrifood systems, and the environment. Plastic waste, asthma, allergies, and antimicrobial resistance are key examples of One Health issues. Can education institutions teach better understanding of socio-environmental challenges? And is education equipped to address rising ill-health among students and staff?

## Figure 5.5. Accumulated plastic stock in water bodies is rising

Plastics leakage to oceans, rivers and lakes in million tonnes, OECD and other countries and regions (1990-2019)

| Year | China | Other Africa | Other EU | India | Other Eurasia | Other non-OECD Asia | Latin America | MENA | OECD |
|------|-------|--------------|----------|-------|----------------|---------------------|---------------|------|------|
| 1990 | 40    | 10           | 15       | 5     | 3              | 8                   | 2             | 0    | 7    |
| 1992 | 50    | 12           | 20       | 7     | 4              | 9                   | 3             | 1    | 8    |
| 1994 | 60    | 15           | 25       | 10    | 5              | 10                  | 4             | 1    | 9    |
| 1996 | 70    | 20           | 30       | 12    | 6              | 12                  | 5             | 2    | 10   |
| 1998 | 75    | 25           | 32       | 15    | 7              | 15                  | 6             | 2    | 11   |
| 2000 | 80    | 30           | 35       | 20    | 8              | 18                  | 7             | 3    | 12   |
| 2002 | 85    | 35           | 38       | 22    | 9              | 20                  | 8             | 4    | 13   |
| 2004 | 90    | 40           | 40       | 25    | 10             | 22                  | 10            | 4    | 14   |
| 2006 | 95    | 50           | 45       | 27    | 11             | 25                  | 12            | 5    | 15   |
| 2008 | 100   | 60           | 50       | 30    | 12             | 28                  | 14            | 5    | 16   |
| 2010 | 110   | 70           | 55       | 35    | 13             | 30                  | 15            | 6    | 18   |
| 2012 | 120   | 80           | 60       | 40    | 14             | 32                  | 18            | 7    | 19   |
| 2014 | 125   | 85           | 62       | 42    | 15             | 34                  | 20            | 8    | 20   |
| 2016 | 130   | 90           | 65       | 45    | 16             | 36                  | 22            | 9    | 21   |
| 2018 | 140   | 95           | 70       | 48    | 17             | 38                  | 25            | 10   | 22   |

Source: Agnelli and Tortora (2022), The role of development co-operation in tackling plastic pollution, OECD Environment Working Papers, No. 207, http://dx.doi.org/10.1787/721355cb-en.

One Health is an integrated, multisectoral approach that seeks to sustainably balance and improve the health of people, animals and ecosystems, recognizing them to be closely linked and interdependent. For instance, the presence of plastics in oceans has widespread negative effects on marine ecosystems, human health, animal welfare, and urban infrastructure, including drainage systems. For humans, the risks include ingesting microplastics through contaminated food (e.g., seafood), increased risk of cancer and respiratory diseases from plastics that are unsafely burned or buried, and inhalation of airborne particles and fibres. Alarmingly, the volume of plastic waste entering the world’s oceans rises each year. Only 9% of the growing plastic waste is recycled, while the majority (69%) is landfilled or incinerated, and over a fifth is inadequately disposed of. Although plastic use is highest in OECD countries, most plastic leakage occurs in some developing nations, though improvements have been noted. This situation underscores the need for international co-operation on plastic waste management and policies to reduce consumption.

Another interrelated challenge and a looming public health threat is Antimicrobial Resistance – the ability of microbes to resist antimicrobial agents. The consumption of antibiotics both in humans and animals has risen high. Despite policy efforts to curb this trend, average sales of antibiotics for human use have increased by nearly 2% since 2000. Consequently, Antimicrobial Resistance is high – one in every five infections is now caused by resistant superbugs. In the absence of stronger One Health action, levels are projected to remain high, claiming many lives and exerting additional pressure on health systems.


Asthma and allergy are also influenced by the health status of the environment. The global prevalence of allergic diseases including asthma, allergic rhinitis, atopic dermatitis, and food allergy has been rising for more than 50 years. In the OECD, the increase in asthma has been especially evident among children and youth. Allergy surges are the result of complex gene-environment interactions. Worsening air pollution and climate change, as well as lifestyle changes (such as an increase in saturated fats and sugars in the diet, antibiotic use, and a more sterile, urbanised environment) could all increase the likelihood of developing allergies. Air pollutants, such as fine particulates (respirable particles) also raise the odds of developing asthma. While exposure to particulate matter is declining in most OECD countries, it remains above WHO air quality guidelines.

**Asthma is increasing in developed economies for children and youth**

- Asthma prevalence rate per 100,000 people, OECD and countries in the upper quintile on the socio-demographic index (SDI), by age (2000-2021)

json
{
  "asthma_prevalence": {
    "years": [
      2000,
      2002,
      2004,
      2006,
      2008,
      2010,
      2012,
      2014,
      2016,
      2018,
      2020
    ],
    "OECD_age_standardised": [
      6500,
      6600,
      6700,
      6800,
      6900,
      7000,
      7100,
      7200,
      7300,
      7400,
      7500
    ],
    "High_SDI_age_standardised": [
      6600,
      6700,
      6800,
      6900,
      7000,
      7100,
      7200,
      7400,
      7600,
      7800,
      8000
    ],
    "OECD_under_20s": [
      6700,
      6800,
      6900,
      7000,
      7200,
      7400,
      7600,
      7700,
      7800,
      7900,
      8000
    ],
    "High_SDI_under_20s": [
      6600,
      6800,
      6900,
      7000,
      7300,
      7500,
      7700,
      7800,
      7900,
      8100,
      8300
    ]
  }
}
```

Note: The Socio-demographic Index (SDI), developed at the Institute for Health Metrics and Evaluation (IHME).

And education?

- Moving away from a human-centred view of the world is challenging. How can education help to develop understanding of One Health challenges? How can it foster systems thinking and interdisciplinary approaches in age-appropriate ways, offering increasing levels of complexity?
- How can education institutions help to enhance connectedness to nature, raise awareness of socio-ecological challenges and change behaviours within their communities at large? Can outdoor, experiential and collaborative learning help?
- The human health trends associated with the environment mean that education institutions will have more students and staff with allergies and other health conditions. How can policy makers and education leaders ensure their safety and inclusion?
```# Markdown Conversion

### Figures
```plaintext
- Figure 4.12. I, Robot
- Figure 5.1. Mental health has become a top health concern
- Figure 5.2. Suicide mortality rates are falling
- Figure 5.3. Share of daily smokers has mostly gone down
- Figure 5.4. Digital addictions are on the rise globally
- Figure 5.5. Accumulated plastic stock in water bodies is rising
- Figure 5.6. Asthma is increasing in developed economies for children and youth
- Figure 5.7. Women are giving birth later, and less
- Figure 5.8. Contraception prevalence is rising globally but with variance between countries
- Figure 5.9. Rising share of people with disabilities
- Figure 5.10. AI is boosting medical technologies
- Figure 5.11. Rise in professional migration to address persisting shortages in medical staff
- Figure 5.12. With only minor progress, women bear the brunt of unpaid care and domestic work
```

### Infographics
```json
{
  "Infographics": [
    {
      "id": "2.1",
      "title": "Global Conflict and Co-operation – Chapter highlights",
      "page": 23
    },
    {
      "id": "3.1",
      "title": "Work and Progress – Chapter highlights",
      "page": 41
    },
    {
      "id": "4.1",
      "title": "Voices and Storytelling – Chapter highlights",
      "page": 61
    },
    {
      "id": "5.1",
      "title": "Bodies and Minds – Chapter highlights",
      "page": 81
    }
  ]
}
```
Later, Baby! Fertility and reproductive health

On average across OECD countries, people are having children later, or not at all, and fertility rates are falling. These choices are related to labour-market and social changes, the increased educational attainment and empowerment of women, and improved access to contraception, but also to shifting preferences and anxieties about the future. At the same time, more people are turning to fertility treatments. These trends are changing the composition of families and households. Are education systems prepared for the demographic changes underway? And what is their role in supporting the reproductive health and rights of students?

**Figure 5.7. Women are giving birth later, and less**

Total fertility rate and mother’s mean age at childbirth, OECD average (1990-2022)

| Year | Total Fertility Rate (OECD-38) | Mother's Mean Age at Childbirth (OECD-33) |
|------|-------------------------------|------------------------------------------|
| 1990 | 1.6                           | 27                                       |
| 1991 | 1.7                           | 28                                       |
| 1992 | 1.8                           | 29                                       |
| 1993 | 1.8                           | 30                                       |
| 1994 | 1.9                           | 31                                       |
| 1995 | 2.0                           | 31                                       |
| 1996 | 1.9                           | 32                                       |
| 1997 | 1.8                           | 30                                       |
| 1998 | 1.7                           | 29                                       |
| 1999 | 1.8                           | 28                                       |
| 2000 | 1.7                           | 28                                       |
| 2001 | 1.6                           | 30                                       |
| 2002 | 1.6                           | 31                                       |
| 2003 | 1.7                           | 29                                       |
| 2004 | 1.6                           | 31                                       |
| 2005 | 1.5                           | 30                                       |
| 2006 | 1.5                           | 31                                       |
| 2007 | 1.5                           | 29                                       |
| 2008 | 1.6                           | 30                                       |
| 2009 | 1.5                           | 32                                       |
| 2010 | 1.6                           | 31                                       |
| 2011 | 1.7                           | 30                                       |
| 2012 | 1.6                           | 29                                       |
| 2013 | 1.6                           | 31                                       |
| 2014 | 1.7                           | 30                                       |
| 2015 | 1.7                           | 31                                       |
| 2016 | 1.6                           | 32                                       |
| 2017 | 1.8                           | 30                                       |
| 2018 | 1.7                           | 29                                       |
| 2019 | 1.6                           | 28                                       |
| 2020 | 1.5                           | 29                                       |
| 2021 | 1.5                           | 30                                       |
| 2022 | 1.5                           | 27                                       |

Note: The Total Fertility Rate is defined as the total number of children that would be born to each woman if she were to live to the end of her childbearing years and give birth to children in alignment with the prevailing age-specific fertility rates. OECD averages are unweighted averages.  
Source: OECD (2024), Society at a Glance 2024: OECD Social Indicators, http://dx.doi.org/10.1787/91d8d83-en.

The average total fertility rate across OECD countries has more than halved since 1960, reaching a record low of 1.5 in 2022. This reflects a trend of fewer women having children, with marked increases in childlessness among younger cohorts, and women who do have children are doing so later in life and having fewer ones. Over the past two decades, births among women in their 20s have sharply declined, while rising for those in their 30s and early 40s. Births among adolescent girls have also dropped. Declining fertility is linked to greater access to contraception, higher female educational attainment, and challenges in balancing work and family life. It may also stem from uncertainty about the future, with concerns over climate, economic, housing, and job insecurities influencing social norms and personal preferences. These include investing more time and money in each child or pursuing self-actualisation outside parenthood.

While having fewer or no children is a choice for some, it’s not the case for everyone. With people starting families later in life, they are more often faced with fertility issues. As a result, the use of assisted reproduction technologies (ART) has steadily grown. ART has also enabled single people and same-sex couples to become parents, contributing to the growing diversity of family structures and households, including unmarried, adoptive, step- and same-sex-parent families. However, millions worldwide still lack access to fertility care.
```
Fertility rates correlate with access to contraception. While contraception use has risen globally, significant disparities remain across regions and economic levels. Though the unmet need for family planning is gradually shrinking, a gap persists between women's reproductive intentions and their contraceptive behaviours. Globally, unintended pregnancies have decreased over the past three decades, yet about half remain unplanned. Greater social and economic development, along with gender equality, is strongly associated with fewer unintended pregnancies, and empowering young women has been shown to improve contraceptive use. How can education institutions educate about reproductive health and adapt to new demographic trends, including the rise of more diverse family structures?

#### Figure 5.8. Contraception prevalence is rising globally but with variance between countries

Median percentages of contraception prevalence among 15-49-year-old women, worldwide by country-income group (1990; 2000; 2008; 2016; 2024)

json
{
  "data": [
    {
      "year": "1990",
      "world": 10,
      "low_income": 5,
      "lower_middle_income": 10,
      "upper_middle_income": 20,
      "high_income": 60
    },
    {
      "year": "2000",
      "world": 20,
      "low_income": 10,
      "lower_middle_income": 15,
      "upper_middle_income": 30,
      "high_income": 65
    },
    {
      "year": "2008",
      "world": 30,
      "low_income": 15,
      "lower_middle_income": 25,
      "upper_middle_income": 40,
      "high_income": 70
    },
    {
      "year": "2016",
      "world": 40,
      "low_income": 20,
      "lower_middle_income": 35,
      "upper_middle_income": 50,
      "high_income": 75
    },
    {
      "year": "2024",
      "world": 50,
      "low_income": 25,
      "lower_middle_income": 45,
      "upper_middle_income": 60,
      "high_income": 80
    }
  ]
}
```

Note: Contraception prevalence is the percentage of women of reproductive age who are currently using any method of contraception.

---
#### And education?
- What are the structural implications of declining birth rates for school systems, e.g., in terms of school size, regrouping and clustering of schools, class size and age grouping, and access to education in rural areas with lower population density?
- Private expenditure on education is high in some countries, acting as a disincentive to having (more) children. What is the role of education policy with regard to demographic considerations?
- Later births and changing household makeup mean students have older parents and more diverse families. At the same time, teachers' parental leave and family responsibilities may become less common or happen later in their careers. What are the implications at the system, classroom, and institutional level?
- What is the role of different levels of education in informing and empowering students for better reproductive and sexual health?
```
Tech ability: disability and advances in medicine and technology

Approximately one in six people across OECD countries live with a disability. While the rise in disability prevalence in some regions is partly due to an ageing population, there has also been a notable increase among young people, mostly due to a rise in mental health-related conditions. Despite progress in education and employment for people with disabilities, substantial gaps persist, and many continue to face daily challenges. Advances in medicine and technology, including artificial intelligence, offer new opportunities to bridge these gaps. However, inequities threaten to limit access to these benefits. How can education become more inclusive while also fostering broader societal inclusion?

Figure 5.9. Rising share of people with disabilities

- Evolution of disability prevalence, EU-20 (2005-2018)

| Year          | Controlling by age and education | Controlling by age | Observed |
|---------------|----------------------------------|--------------------|----------|
| 2005          | 100                              | 100                | 100      |
| 2006          | 105                              | 106                | 102      |
| 2007          | 110                              | 109                | 104      |
| 2008          | 112                              | 110                | 105      |
| 2009          | 114                              | 111                | 107      |
| 2010          | 116                              | 113                | 108      |
| 2011          | 117                              | 115                | 110      |
| 2012          | 118                              | 116                | 111      |
| 2013          | 120                              | 117                | 112      |
| 2014          | 121                              | 119                | 113      |
| 2015          | 122                              | 121                | 114      |
| 2016          | 123                              | 122                | 115      |
| 2017          | 124                              | 123                | 116      |
| 2018          | 125                              | 124                | 117      |

Note: 2005=100%. Data cover persons aged 15-69 and show the weighted average of 20 European countries. To control by age, the prevalence of disability was generated using five-year age groups in 2006 and applied to the following years to simulate the number of people with disabilities that would have existed if the same prevalence by age group and age proportions were maintained. Disability is defined as people who (1) declared to suffer from any chronic illness or condition and (2) with moderate to severe activity limitation due to health problems.
Source: OECD (2022), Disability, Work and Inclusion: Mainstreaming in All Policies and Practices, http://dx.doi.org/10.1787/lea5e9c-en.

Disabilities can result from a variety of factors, including physical, mental, sensory, or cognitive impairments, and the environmental and social factors that interact with these impairments. Most disabilities are invisible to others. Cross-country comparisons of disability prevalence are challenging due to cultural variations, stigma, and measurement discrepancies. Nonetheless, recent data show that disability prevalence in Europe is rising, driven by an ageing population. A notable rise among young adults was also found, largely due to a rise in mental health-related conditions. Globally, disability rates are higher for women than men, and for those in high-income countries than in low-income ones. This reflects both higher rates of certain health conditions in wealthier nations and under-diagnosis in low-income settings.

While the employment rate for people with disabilities has improved slightly over the past decade across OECD countries, people with disabilities face persistent difficulties in the labour market. Important employment gaps remain, with only 40% of people with disabilities having a job on average across OECD countries and many encountering discrimination and inequities in access to public services, education, and work. Accelerated by international efforts, many countries have implemented more robust legislation and support.
```
policies to support the rights and inclusion of persons with disabilities, including in education and work, though at varying rates. Companies are also increasingly investing in inclusive hiring practices.

Innovations in technology, from assistive devices to accessible public spaces, play a crucial role in breaking down barriers and easing daily challenges for people with disabilities at home and work. These include wearable sensors, automated captioning and translation to plain language, AI-based pattern, object and voice recognition, and voice-controlled devices. AI innovations can also support healthcare professionals in diagnostics and care. Over the past few years, AI systems have tripled their performance in clinical knowledge and accuracy, expanding potential applications in healthcare. AI also has the potential to create more inclusive work environments by addressing various disabilities simultaneously, scaling accessibility faster, and offering personalised, less stigmatised solutions. Accordingly, investors have increased equity funding in healthcare AI. However, the digital divide may hinder access for some, and persisting labour-market gaps suggest that people with disabilities are not benefiting from these tools as much as they could. How can education foster inclusive attitudes and ensure it is itself inclusive?

### JSON Table

json
{
  "title": "AI is boosting medical technologies",
  "data": [
    {"year": 2012, "number_of_devices": 0},
    {"year": 2013, "number_of_devices": 0},
    {"year": 2014, "number_of_devices": 0},
    {"year": 2015, "number_of_devices": 0},
    {"year": 2016, "number_of_devices": 0},
    {"year": 2017, "number_of_devices": 0},
    {"year": 2018, "number_of_devices": 10},
    {"year": 2019, "number_of_devices": 40},
    {"year": 2020, "number_of_devices": 60},
    {"year": 2021, "number_of_devices": 100},
    {"year": 2022, "number_of_devices": 120}
  ],
  "source": "Maslej et al. (2024), The AI Index 2024 Annual Report"
}
```

And education?
- Alongside ethical arguments for inclusion, empirical evidence has found improved outcomes from educating learners with special educational needs and disabilities (SEND) in mainstream settings while providing additional supports and accommodations. What kind of leadership is necessary to address attitudinal barriers to inclusion and shift the focus from access to quality?
- Teachers report a high level of need for professional learning geared towards teaching students with SEND. What kind of protocols, resources, staff and skills are needed to enhance educators’ self-belief, efficacy, and collaboration in responding to different learner needs?
- Do education institutions take full advantage of technological advances that could support students, teachers, and other staff with disabilities? Which funding models can ensure adequate resourcing for inclusive education? How can integrated health, education, and employment services support this?
```

# Who cares? Paid and unpaid care work

As populations age in OECD countries, the demand for care workers continues to rise. The COVID-19 pandemic has both exposed and worsened longstanding challenges in attracting sufficient staff to the care sector. Similarly, shortages in medical professions have led countries to recruit foreign-trained doctors and nurses. The caring professions are predominantly filled by women, who also spend nearly three times as much time on unpaid care and domestic work compared to men. How can education best develop the socio-emotional competencies needed for care work, and address the gender gap in caregiving?

## Figure 5.11. Rise in professional migration to address persisting shortages in medical staff

json
{
  "title": "Rise in professional migration to address persisting shortages in medical staff",
  "data": [
    {"country": "Italy", "foreign_trained_doctors": 60},
    {"country": "Poland", "foreign_trained_doctors": 54},
    {"country": "Sweden", "foreign_trained_doctors": 45},
    {"country": "Colombia", "foreign_trained_doctors": 32},
    {"country": "Chile", "foreign_trained_doctors": 29},
    {"country": "Lithuania", "foreign_trained_doctors": 28},
    {"country": "Latvia", "foreign_trained_doctors": 25},
    {"country": "Czech Republic", "foreign_trained_doctors": 23},
    {"country": "Slovakia", "foreign_trained_doctors": 20},
    {"country": "Luxembourg", "foreign_trained_doctors": 19},
    {"country": "Finland", "foreign_trained_doctors": 18},
    {"country": "Germany", "foreign_trained_doctors": 15},
    {"country": "Ireland", "foreign_trained_doctors": 14},
    {"country": "United Kingdom", "foreign_trained_doctors": 13},
    {"country": "Canada", "foreign_trained_doctors": 10},
    {"country": "New Zealand", "foreign_trained_doctors": 5},
    {"country": "OECD Average", "foreign_trained_doctors": 30}
  ]
}
```

Source: Adapted from OECD (2024), “Health Workforce Migration”, OECD Health Statistics 2023, https://doi.org/10.1787/1497601f-en.

Care needs will continue to rise as populations age, more individuals require long-term care, and the availability of community-based non-professional caregivers declines. At the same time, many countries face chronic shortages of long-term care workers. Recruitment is challenging, as care work is often characterized by low wages, high physical and mental risks, limited recognition, and non-standard employment (including temporary, part-time, on-call, and agency work). While the share of long-term care workers in total employment increased by 12% over the past decade, this growth has not kept pace with rising demand. In most OECD countries, becoming a personal care worker is relatively accessible. Yet, low qualifications and skills relative to the complex tasks required can jeopardize the quality of care. This underlines the role of education and training systems in expanding the pool of trained carers. 

Technological advancements, such as AI-enhanced tools for detecting falls, managing medication regimens, or voice assistants, can facilitate independent living for older people, reducing the need for constant supervision by carers.

Over a fifth of long-term care workers across the OECD are foreign-born. Recruiting doctors and nurses from abroad has also become a common solution to address shortages that exist in the medical professions. With one-third of doctors and one-fourth of nurses in OECD countries over the age of 55 in 2023 and nearing retirement, migration to fill these gaps is likely to increase. However, this trend can worsen shortages of quality health resources in countries of origin, highlighting the need for a net increase in health workers.
```


Care work is predominantly performed by women. Women also take on 75% of unpaid care and domestic duties globally – work that is typically overlooked in economic measures like GDP. The significant gender gap in unpaid care work has only slightly narrowed over time, reflecting the persistence of social norms assigning men and women separate roles within the household. In OECD countries, women spend an average of 4 hours per day on unpaid work (often coined the 'second shift'), while men spend 1.9 hours, with the pattern reversed for paid work. More broadly, women’s roles as primary caregivers for both children and the elderly explain why they are more likely than men to work part-time, work from home, and earn less or retire earlier. While some caregiving aligns with personal preferences, intensive caregiving is linked to negative effects on women’s mental health. 

Can education foster a more equal sharing of care responsibilities and help shift traditional gender roles?

json
{
  "title": "Figure 5.12. With only minor progress, women bear the brunt of unpaid care and domestic work",
  "description": "Percentage of time spent on unpaid care and domestic work by sex, estimates of global average (2015-2023)",
  "data": {
    "years": ["2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023"],
    "gap": [16, 16, 16, 16, 16, 16, 16, 16, 16],
    "female": [18, 18, 17, 18, 17, 19, 19, 19, 19],
    "male": [2, 2, 2, 2, 2, 2, 2, 2, 2]
  },
  "note": "Unpaid care and domestic work refers to all non-market, unpaid activities carried out in households – including both direct care of persons, such as children or elderly, and indirect care, such as cooking, cleaning or fetching water.",
  "source": "Adapted from Hanna et al. (2023), Forecasting time spent in unpaid care and domestic work - Technical brief.",
  "link": "https://data.unwomen.org/publications/forecasting-time-spent-unpaid-care-and-domestic-work."
}
```

And education?
- Are higher education and training systems equipped to address the rising need for training in the care and medical professions? How can systems address gaps in knowledge and skills of professionals certified in different countries?
- How can education challenge ideas about gender roles and foster in more students, specifically boys, the competencies needed for caregiving? Can education systems contribute to enhancing the gender balance in HEAL fields (health, education, administration, literacy) and in care work?
- How can education systems accommodate the needs of teachers with care responsibilities?
- Access to affordable high-quality Early Childhood Education and Care could reduce the time spent on care duties. How can education systems improve access?
```
## Future 3: Inter-connected health crises

Frequent crop failures induce surges of hunger in middle- and low-income communities. Malnutrition and heat waves degrade human immune systems and increase vulnerability to infectious diseases.

As antimicrobial resistance heightens, incurable outbreaks arise. Greater animal presence in cities (pets, support animals) affects disease proliferation.

Male sperm counts reach record low, affected by environmental causes. The new global market for quality sperm reverses fertility maps, with richer nations boasting higher fertility rates.

Education faces recurring outbreaks of diseases, with mass non-attendance of students and staff or complete closure due to social distancing rules. Hunger among students and staff is common, and education budgets are stretched to provide basic nutrition to all, while also financing cooling solutions.

Shifting cohort sizes in some areas requires the restructuring of school systems. School communities polarise over access to animals, for fear of infection.

---

We're navigating uncharted waters in education policy! The unpredictability of health crises has made planning virtually impossible. Funding constraints challenge our ability to implement necessary interventions, especially as all ministries are under budgetary pressures. The ongoing pressure to adapt to shifting circumstances and fluctuating demographics complicates our decision-making. There’s a growing need to balance immediate health concerns with long-term educational goals, and it’s clear that traditional models won’t suffice. Building community trust in our initiatives is also becoming increasingly difficult.

---

### Turning insights into action

What challenges, opportunities and tensions could the trends and futures present for different education stakeholders?

- Leon, 7-year-old student
- Priya, advisor, Ministry of Education
- Matteo, school inspector
- Alex, employer
- Daniel, school teacher
- Eva, university professor
- Gabriel, parent and part-time student
- Emi, school principal
- Mina, early childhood director
- Noah, local government official
- Leila, vocational trainer
- Sarah, university student
- Eli, 14-year-old student
- Ren, 3-year-old child

Which elements of the three futures are the most probable? How would they impact education and training in our system? What changes could we make in education now to seize opportunities and manage risks?

Which elements of the three futures are most desirable? What changes could we make in education now to move towards that future?

Which elements of the three futures are the least desirable? What changes could we make in education now to prevent them?


# Notes and sources

1. IHME (2024), Global Burden of Disease Results 2021, [vizhub.healthdata.org](https://vizhub.healthdata.org/gbd-results/) (accessed 11 December 2024).

2. OECD (2023), *Health at a Glance 2023: OECD Indicators*, OECD Publishing, Paris, https://doi.org/10.1787/7a7afb35-en; OECD (2021), “Tackling the mental health impact of the COVID-19 crisis: An integrated, whole-of-society response”, OECD Policy Responses to Coronavirus (COVID-19), OECD Publishing, Paris, https://doi.org/10.1787/0ccaf0b-en; OECD (forthcoming) *Understanding and addressing inequalities in mental health*, OECD Health Working Paper.

3. IPSOS (2024), *Ipsos Health Service Report 2024: Mental Health seen as the biggest Health issue*, [ipsos.com](https://www.ipsos.com/en/ipsos-health-service-report) (accessed 10 October 2024).

4. Brauer, R. et al. (2021), “Psychotropic medicine consumption in 65 countries and regions, 2008–19: a longitudinal study”, *The Lancet Psychiatry*, Vol. 8/12, pp. 1071-1082, https://doi.org/10.1016/s2215-0366(21)00292-3; Chan, A. et al. (2023), “Attention-deficit/hyperactivity disorder medication consumption in 64 countries and regions from 2015 to 2019: a longitudinal study”, *eClinicalMedicine*, Vol. 58, p. 10780, https://doi.org/10.1016/j.eclinm.2022.101780; Koutsouleris, N. et al. (2022), “From promise to practice: towards the realisation of AI-informed mental health care”, *The Lancet Digital Health*, Vol. 4/11, pp. e829-e840, https://doi.org/10.1016/s2589-7500(22)00153-4.

5. OECD (2023), *Health at a Glance 2023: OECD Indicators*, OECD Publishing, Paris, https://doi.org/10.1787/7a7afb35-en; OECD/European Commission (2024), *Health at a Glance: Europe 2024: State of Health in the EU Cycle*, OECD Publishing, Paris, https://doi.org/10.1787/b3704e14-en; Garnett M. F. and S. C. Curtin (2023), *Suicide Mortality in the United States, 2001–2021*, NCHS Data Briefs, National Center for Health Statistics (U.S.), https://doi.org/10.15620/cdc:125705; OECD (forthcoming) *Understanding and addressing inequalities in mental health*, OECD Health Working Paper.

6. OECD (2023), *Health at a Glance 2023: OECD Indicators*, OECD Publishing, Paris, https://doi.org/10.1787/7a7afb35-en; IHME (2024), *Global Burden of Disease Results 2021*, [vizhub.healthdata.org](https://vizhub.healthdata.org/gbd-results/) (accessed 10 October 2024).

7. OECD (2023), *Health at a Glance 2023: OECD Indicators*, OECD Publishing, Paris, https://doi.org/10.1787/7a7afb35-en; Eligh, J. (2024), *Global Synthetic Drug Markets: The Present and Future*, The Global Initiative Against Transnational Organized Crime, [globalinitiative.net](https://globalinitiative.net/wp-content/uploads/2024/03/Jason-Eligh-Global-synthetic-drug-markets-The-present-and-future-GI-TOC-March-2024.pdf).

8. Basel, A. et al. (2020), “Defining digital addiction: Key features from the literature”, *Psihologija*, Vol. 53/3, pp. 237-253, https://doi.org/10.2298/psi191209017a; OECD (2024), *OECD Digital Economy Outlook 2024 (Volume 1): Embracing the Technology Frontier*, OECD Publishing, Paris, https://doi.org/10.1787/16896db5-en.

9. Meng, S. et al. (2022), “Global prevalence of digital addiction in general population: A systematic review and meta-analysis”, *Clinical Psychology Review*, Vol. 92, p. 102128, https://doi.org/10.1016/j.cpr.2022.102128; Burns, T. and F. Gottschalk (eds.) (2019), *Educating 21st Century Children: Emotional Well-being in the Digital Age*, Educational Research and Innovation, OECD Publishing, Paris, https://doi.org/10.1787/b733425-en; Bickham, D. et al. (2024), *Adolescents Media Use: Attitudes, Effects, and Online Experiences - Pulse Survey*, [digitalwellnesslab.org](https://digitalwellnesslab.org/wp).

TRENDS SHAPING EDUCATION 2025 © OECD 2025

