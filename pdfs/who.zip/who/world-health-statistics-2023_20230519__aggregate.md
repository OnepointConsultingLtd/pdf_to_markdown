To respond to these challenges, and to meet the SDG targets by 2030, it is crucial to scale up efforts and accelerate progress. Global, regional, and national priorities should be set and interventions targeted to end deaths from preventable injuries and deaths of mothers and children, to further postpone NCD deaths by lowering their underlying risk factors, and to increase equitable access to essential health services while containing the risks of facing catastrophic costs. It is critical to have timely, reliable, and disaggregated data, estimates, and forecasts to inform policy and guide actions at all levels in order to maximize health gains and eliminate inequalities.
| Country and area                           | Total population ('000s) | Life expectancy at birth (years) | Healthy life expectancy at birth (years) |
|--------------------------------------------|---------------------------|---------------------------------|------------------------------------------|
|                                            |                           | Male    | Female  | Both sexes | Male    | Female | Both sexes |
| Singapore                                  | 3 107                     | 81.0   | 85.5   | 83.2      | 74.4   | 73.7  |          |
| Slovakia                                   | 2 660                     | 74.8   | 81.4   | 78.2      | 66.2   | 70.8  | 68.5      |
| Slovenia                                   | 1 065                     | 78.6   | 84.4   | 81.3      | 69.0   | 72.5  | 70.7      |
| Solomon Islands                            | 362                       | 62.9   | 67.6   | 65.2      | 56.5   | 59.1  | 57.8      |
| Somalia                                    | 8 556                     | 54.0   | 59.2   | 56.5      | 48.3   | 51.3  | 49.7      |
| South Africa                               | 28 895                    | 62.2   | 68.3   | 65.3      | 54.6   | 57.7  | 56.2      |
| South Sudan                                | 11 321                    | 60.8   | 68.4   | 64.8      | 62.8   | 62.9  | 62.9      |
| Spain                                      | 23 272                    | 66.7   | 73.8   | 70.7      | 67.9   | 71.3  | 70.1      |
| Sri Lanka                                  | 10 490                    | 73.8   | 79.8   | 76.9      | 65.1   | 69.0  | 67.0      |
| Sudan                                      | 22 815                    | 67.6   | 70.8   | 69.1      | 69.1   | 59.6  | 60.3      |
| Suriname                                   | 305                       | 74.6   | 75.6   | 75.1      | 60.7   | 64.2  | 62.4      |
| Sweden                                      | 5 273                     | 80.8   | 84.0   | 82.4      | 71.7   | 72.1  | 71.9      |
| Switzerland                                | 4 314                     | 81.0   | 81.8   | 81.2      | 72.2   | 72.8  | 72.5      |
| Syrian Arab Republic                       | 10 681                    | 71.2   | 74.3   | 72.7      | 62.5   | 63.9  | 62.9      |
| Tajikistan                                 | 4 906                     | 67.6   | 71.5   | 69.0      | 62.6   | 62.0  | 62.0      |
| Thailand                                   | 34 790                    | 74.4   | 81.7   | 77.4      | 67.0   | 69.6  | 68.5      |
| Timor-Leste                                | 674                       | 69.6   | 71.4   | 70.5      | 59.8   | 62.0  | 60.9      |
| Togo                                        | 6 700                     | 60.8   | 61.3   | 61.0      | 54.2   | 57.8  | 56.2      |
| Tonga                                      | 52                        | 69.8   | 75.1   | 72.6      | 62.7   | 65.4  | 64.0      |
| Trinidad and Tobago                        | 1 013                     | 72.5   | 79.9   | 76.9      | 64.0   | 71.4  | 66.2      |
| Tunisia                                    | 6 507                     | 79.2   | 79.2   | 79.2      | 66.1   | 67.9  | 67.0      |
| Türkiye                                    | 42 490                    | 76.4   | 80.7   | 78.6      | 67.9   | 69.0  | 68.4      |
| Tuvalu                                     | 11                        |      -   |       -   |     -       |         -   |     -    |    -         |
| Uganda                                     | 22 701                    | 63.2   | 66.7   | 65.4      | 56.0   | 60.4  | 58.2      |
| Ukraine                                    | 20 147                    | 73.0   | 73.4   | 73.2      | 60.6   | 67.8  | 64.3      |
| United Arab Emirates                       | 6 512                     | 78.6   | 80.6   | 79.6      | 76.1   | 68.2  | 66.0      |
| United Kingdom                             | 33 299                    | 80.7   | 78.8   | 79.8      | 81.4   | 69.0  | 75.1      |
| United Republic of Tanzania                | 31 318                    | 65.4   | 69.3   | 67.5      | 67.5   | 59.3  | 65.1      |
| United States of America                   | 166 490                   | 75.8   | 76.3   | 76.0      | 78.5   | 62.5  | 70.6      |
| Uruguay                                    | 1 659                     | 73.5   | 80.6   | 77.7      | 71.1   | 63.5  | 67.6      |
| Uzbekistan                                 | 17 052                    | 70.8   | 75.2   | 73.0      | 63.3   | 65.7  | 64.7      |
| Vanuatu                                    | 161                       | 62.7   | 68.3   | 65.3      | 65.6   | 59.4  | 57.8      |
| Venezuela (Bolivarian Republic of)        | 13 957                    | 78.2   | 79.3   | 79.0      | 67.1   | 68.4  | 67.8      |
| Viet Nam                                   | 48 136                    | 69.6   | 74.8   | 72.5      | 62.4   | 68.3  | 65.4      |
| Yemen                                      | 16 668                    | 64.1   | 68.9   | 66.6      | 59.5   | 58.2  | 57.5      |
| Zambia                                     | 9 609                     | 59.5   | 65.4   | 62.5      | 52.5   | 56.3  | 54.4      |
| Zimbabwe                                   | 7 544                     | 85.9   | 75.9   | 78.7      | 63.6   | 60.7  | 61.2      |
| **Global**                                 | 3 973 370                 | 70.8   | 75.9   | 73.3      | 62.5   | 64.9  | 63.7      |
```
{
  "table": [
    {
      "Country": "Afghanistan",
      "Probability of dying from any of CVD, cancer, diabetes, CRD between age 30 and exact age 70 (%)": [35.3, 4.1, "<01"],
      "Suicide mortality rate (per 100 000 population)": [15.9, 42.1, 62.1],
      "Total alcohol (L per capita (≥ 15 years of age) consumption (litres of pure alcohol))": [0.0, 0.0, 0.0],
      "Road traffic mortality rate (per 100 000 population)": [-, 0.0, 0.0],
      "Proportion of women reproductive age who have their need for family planning satisfied with modern methods (%)": [42.1, 62.1, 0],
      "Adolescent birth rate (per 1000 women aged 15–19 years)": [621]
    },
    {
      "Country": "Albania",
      "Probability of dying from any of CVD, cancer, diabetes, CRD between age 30 and exact age 70 (%)": [11.4, 4.3, 5.1],
      "Suicide mortality rate (per 100 000 population)": [11.7, 6.3, 13.2],
      "Total alcohol (L per capita (≥ 15 years of age) consumption (litres of pure alcohol))": [17.6, 20.9, 0.0],
      "Road traffic mortality rate (per 100 000 population)": [4.9, 0.0, 0.0],
      "Proportion of women reproductive age who have their need for family planning satisfied with modern methods (%)": [66.3, 0.0, 0.0],
      "Adolescent birth rate (per 1000 women aged 15–19 years)": [132]
    },
    {
      "Country": "Algeria",
      "Probability of dying from any of CVD, cancer, diabetes, CRD between age 30 and exact age 70 (%)": [13.9, 2.5, 0.6],
      "Suicide mortality rate (per 100 000 population)": [20.9, 66.3, 12.0],
      "Total alcohol (L per capita (≥ 15 years of age) consumption (litres of pure alcohol))": [-, -, -],
      "Road traffic mortality rate (per 100 000 population)": [-, -, -],
      "Proportion of women reproductive age who have their need for family planning satisfied with modern methods (%)": [66.3, 0.0, 0.0],
      "Adolescent birth rate (per 1000 women aged 15–19 years)": [12.0]
    },
    ...
    {
      "Country": "Dominica",
      "Probability of dying from any of CVD, cancer, diabetes, CRD between age 30 and exact age 70 (%)": ["-", "-", "-"],
      "Suicide mortality rate (per 100 000 population)": ["-", "-", "-"],
      "Total alcohol (L per capita (≥ 15 years of age) consumption (litres of pure alcohol))": ["-", "-", "-"],
      "Road traffic mortality rate (per 100 000 population)": ["-", "-", "-"],
      "Proportion of women reproductive age who have their need for family planning satisfied with modern methods (%)": ["-", "-", "-"],
      "Adolescent birth rate (per 1000 women aged 15–19 years)": ["-", "-", "-"]
    }
  ]
}
```
| Adolescent birth rate* (per 1000 women aged 10–14 years) | UHC: Service coverage index* | Population with household expenditures on health > 10% of total household expenditure or income* (%) | Population with household expenditures on health > 25% of total household expenditure or income* (%) | Age-standardized mortality rate attributed to household and ambient air pollution* (per 100 000 population) | Mortality rate attributed to exposure to unsafe WASH services* (per 100 000 population) | Mortality rate from unintentional poisoning* (per 100 000 population) |
|----------------------------------------------------------|-------------------------------|----------------------------------------------------------|----------------------------------------------------------|--------------------------------------------------------------------------|-------------------------------------------------------------------------|--------------------------------------------------|
| Primary data                                            | Primary data                  | Primary data                                            | Primary data                                            | Comparable estimates                                                   | Comparable estimates                                                   | Comparable estimates                               |
| 2013–2021                                              | 2021                          | 2013–2021                                              | 2019                                                      | 2019                                                                     | 2019                                                                   | 2019                                               |
| 0.2                                                      | 41                            | 261                                                      | 8.0                                                      | 2657                                                                     | 166                                                                   | 10                                               |
| 0.0                                                      | 74                            | 497                                                      | 1.4                                                      | 92                                                                       | 3.2                                                                   | 0.3                                               |
| 0.0                                                      | 79                            | -                                                        | -                                                        | 4.1                                                                      | 0.7                                                                   | -                                                 |
| 10.7                                                     | 37.5                          | 35.5                                                     | 12.5                                                     | 142.8                                                                    | 489                                                                   | 2.0                                               |
| 0.3                                                      | 76                            | 193                                                      | 25                                                       | 0.7                                                                      | -                                                                     | -                                                 |
| 1.2                                                      | 79                            | 9.6                                                      | 2.5                                                      | 297                                                                      | 114                                                                   | 0.4                                               |
| <1                                                       | 68                            | 199                                                      | 59                                                       | 74.5                                                                     | 58                                                                    | 0.7                                               |
| 0.1                                                      | 87                            | 2.5                                                      | 0.4                                                      | 98                                                                       | 19                                                                    | 0.1                                               |
| <1                                                       | 85                            | 175                                                      | 20                                                       | 0.2                                                                      | -                                                                     | -                                                 |
| 0.0                                                      | 66                            | -                                                        | 1252                                                     | 36.9                                                                     | -                                                                     | -                                                 |
| 0.3                                                      | 77                            | 10.4                                                     | 0.2                                                      | -                                                                        | -                                                                     | -                                                 |
| <1                                                       | 76                            | 4.9                                                      | 14                                                       | 681                                                                      | 182                                                                   | 0.3                                               |
| 0.9                                                      | 52                            | 24.4                                                     | 8.5                                                      | 1439                                                                     | 182                                                                   | 0.3                                               |
| 0.1                                                      | 79                            | 16.4                                                     | 3.8                                                      | 258                                                                      | 16                                                                    | 3.3                                               |
| 0.1                                                      | 86                            | 158                                                      | -                                                        | -                                                                        | 0.4                                                                   | -                                                 |
| 0.9                                                      | 68                            | 6.2                                                      | 31                                                       | 410                                                                      | 4.3                                                                   | 0.4                                               |
| 1.8                                                      | 43.0                          | 14.3                                                     | 3.0                                                      | 2018                                                                     | 602                                                                   | 26                                                |
| -                                                        | 60                            | 4.0                                                      | 18                                                       | 9.3                                                                       | 157                                                                   | 0.2                                               |
| -                                                        | 57                            | 12                                                       | 771                                                      | 4.9                                                                      | 19                                                                    | 0.6                                               |
| <1                                                       | 66                            | 8.2                                                      | 14                                                       | 18.9                                                                     | 19                                                                    | 0.4                                               |
| 0.3                                                      | 55                            | 4.3                                                      | 10                                                       | 140.7                                                                    | 268                                                                   | 18                                                |
| 2.3                                                      | 80                            | 118.9                                                   | 29                                                       | 66                                                                       | 0.1                                                                   | -                                                 |
| 0.3                                                      | 78                            | -                                                        | 196                                                      | 17                                                                       | <1                                                                    | -                                                 |
| 13.73                                                    | 213                           | 31.6                                                     | 29                                                       | 0.5                                                                      | -                                                                     | -                                                 |
| 12.0                                                    | 40                            | 84                                                       | 18                                                       | 2013                                                                     | 609                                                                   | 31                                                |
| 0.7                                                      | 41                            | 4.8                                                      | 0.9                                                      | 2059                                                                     | 533                                                                   | 32                                                |
| 0.4                                                      | 71                            | 91                                                       | 121                                                      | 0.4                                                                      | -                                                                     | -                                                 |
| 0.1                                                      | 58                            | 179                                                      | 4.9                                                      | 1633                                                                     | 171                                                                   | 0.5                                               |
| 2.9                                                      | 44                            | 107                                                      | 18                                                       | 2067                                                                     | 473                                                                   | 26                                                |
| <1                                                       | 91                            | 3.5                                                      | 0.8                                                      | 81                                                                       | 23                                                                    | 0.3                                               |
| 80.0                                                    | 32                            | 3051                                                     | 970                                                      | 29.8                                                                     | -                                                                     | -                                                 |
| 3.9                                                      | 29.3                          | 14                                                       | 2274                                                     | 992.5                                                                    | -                                                                     | -                                                 |
| 0.5                                                      | 82                            | 14.6                                                     | 21                                                       | 179                                                                      | 23                                                                    | 0.4                                               |
| -                                                        | 81                            | 24.3                                                     | 69                                                       | 953                                                                      | 22                                                                    | 18                                                |
| -                                                        | -                             | -                                                        | -                                                        | -                                                                        | -                                                                     | -                                                 |
| -                                                        | -                             | -                                                        | -                                                        | -                                                                        | -                                                                     | -                                                 |
| -                                                        | -                             | -                                                        | -                                                        | -                                                                        | -                                                                     | -                                                 |
| 2.6                                                      | 80                            | 82.2                                                     | 2.2                                                      | 313                                                                      | 3.4                                                                   | 0.1                                               |
| 2.5                                                      | 41                            | 8.8                                                      | 16                                                       | 164.6                                                                   | 438                                                                   | 24                                                |
| 0.3                                                      | 46                            | 0.1                                                      | <1                                                       | 170.4                                                                    | 264                                                                   | 13                                                |
| 1.1                                                      | 81                            | 74                                                       | 11                                                       | 178                                                                      | 2.9                                                                   | 0.1                                               |
| 50.0                                                    | 43                            | 83.0                                                     | 0.6                                                      | 1865                                                                     | 470                                                                   | 25                                                |
| <1                                                       | 80                            | -                                                        | 313                                                      | 2.7                                                                      | 0.4                                                                   | -                                                 |
| 1.2                                                      | 80                            | -                                                        | 419                                                      | 97                                                                       | 0.2                                                                   | -                                                 |
| 0.2                                                      | 81                            | 14.7                                                     | 16                                                       | 158                                                                      | 16                                                                    | 0.3                                               |
| 0.1                                                      | 84                            | 4.6                                                      | 0.8                                                      | 32.5                                                                     | 41                                                                    | 14                                                |
| -                                                        | -                             | 68                                                       | 212.8                                                    | 4.1                                                                      | 14                                                                    | -                                                 |
| 34.4                                                    | 42                            | 2098                                                     | 523                                                      | 2.0                                                                      | -                                                                     | -                                                 |
| <1                                                       | 82                            | 12.9                                                     | 41                                                       | <0.1                                                                     | -                                                                     | -                                                 |
| 0.4                                                      | 15                            | 0.3                                                      | 1779                                                     | 376                                                                      | 25                                                                    | -                                                 |
| -                                                        | 49                            | -                                                        | -                                                        | -                                                                        | -                                                                     | -                                                 |


| Country and areas                     | 3.4 | 3.5 | 3.6 | 3.7 |
|---------------------------------------|-----|-----|-----|-----|
|                                       | Comparable estimates | Comparable estimates | Comparable estimates | Primary data |
|                                       | 2019 | 2019 | 2019 | 2013-2021 |
| Dominican Republic                    | 191 | 49  | 68.6 | 74  | 424  |
| Ecuador                               | 110 | 76  | 33  | 201 | 825 581 |
| Egypt                                 | 28.0 | 3.0 | 0.1 | 80.0 | 469  |
| El Salvador                           | 107 | 6.0 | 3.3 | 209 | 80.0 | 50.1 |
| Equatorial Guinea                     | 221 | 79  | 69 | 272 | -   |
| Eritrea                               | 268 | 10.9 | 12 | 379 | -   |
| Estonia                               | 149 | 14.9 | 113 | 4.5 | 79  |
| Eswatini                              | 352 | 294 | 81 | 335 | 829 871 |
| Ethiopia                              | 171 | 54  | 34 | 282 | 62.6 | 73.5 |
| Fiji                                   | 377 | 9.0 | 3.4 | 135 | -   |
| Finland                               | 96  | 153 | 92  | 39  | -   |
| France                                | 106 | 138 | 113 | 51  | 5.7 |
| Gabon                                 | 213 | 48  | 73 | 239 | -   |
| Gambia                                | 211 | 4.8 | 11 | 296 | 64.8 |
| Georgia                               | 24.9 | 92  | 14.3 | 124.5 | 272 |
| Germany                               | 121 | 123 | 12.2 | 38 | 65 |
| Ghana                                 | 225 | 66  | 4.5 | 257 | 780 |
| Greece                                | 125 | 51  | 71 | 85  | -   |
| Grenada                               | 23.3 | 0.7 | 81 | 80  | 359 |
| Guatemala                             | 165 | 59  | 16 | 229 | 661 588 |
| Guinea                                | 24.9 | 70  | 0.5 | 297 | 377 |
| Guinea-Bissau                         | 24.9 | 70  | 41 | 322 | 600 84.6 |
| Haiti                                 | 313 | 96  | 3.5 | 188 | 454 548 |
| Honduras                              | 187 | 21  | 32 | 791 | 971 |
| Hungary                               | 227 | 166 | 106 | 79.0 | 214 |
| Iceland                               | 87  | 119 | 81 | 20  | 33 |
| India                                 | 219 | 127 | 4.9 | 156 | 28.7 | 10.6 |
| Indonesia                             | 24.8 | 24  | 0.1 | 113| 770 | 361 |
| Iran (Islamic Republic of)           | 14.8 | 52  | 0.7 | 15.1 | 245 |
| Iraq                                  | 335 | 36  | 0.2 | 273 | 538 700 |
| Ireland                               | 97  | 96  | 117 | 31  | 4 |
| Israel                                | 88  | 53  | 30 | 39  | -   |
| Italy                                 | 9.0 | 67.0 | 8.0 | 53 | - | 33 |
| Jamaica                               | 16.9 | 24.36 | 36 | 25  | 359 |
| Japan                                 | 83  | 153 | 67 | 36 | 25 |
| Jordan                                | 153 | 16 | 0.3 | 170 | 567 | 270 |
| Kazakhstan                            | 224 | 176 | 4.5 | 127 | 732 | 229 |
| Kenya                                 | 210 | 61 | 29 | 283 | 771 | 730 |
| Kiribati                              | 508 | 283 | 0.8 | 19 | 531 | 506 |
| Kuwait                                | 119 | 29 | 0.0 | 154 | 52 |
| Kyrgyzstan                            | 203 | 74 | 50 | 127 | 64.6 | 326 |
| Lao People’s Democratic Republic      | 26.8 | 54 | 115 | 179 | 72.3 | 834 |
| Latvia                                | 216 | 201 | 131 | 81 | 100 |
| Lebanon                               | 19.9 | 28 | 1.5 | 164 | - |
| Lesotho                               | 427 | 724 | 4.5 | 319 | 828 | 84.5 |
| Liberia                               | 178 | 44 | 3.6 | 389 | 477 | 1281 |
| Libya                                 | 18.6 | 4.5 | <0.1 | 24.0 | 109 |
| Lithuania                             | 193 | 261 | 118 | 8  | 2 |
| Luxembourg                            | 97 | 113 | 115 | 41 | 39 |
| Madagascar                            | 260 | 55 | 10 | 292 | 656. | 1430 |
| Malawi                                | 226 | 54 | 32 | 334 | 773 | 1356 |
| Malaysia                              | 184 | 57 | 0.8 | 225 | 78 |
| Maldives                              | 116 | 27 | 14 | 16 | 292 | 51 |
| Mali                                  | 223 | 41 | 4.3 | 227 | 412 | 163.6 |
```
| Adolescent birth rate* (per 1000 women aged 10–14 years) | UHC: Service coverage index* | Population with household expenditures on health > 10% of total household expenditure or income (%) | Population with household expenditures on health > 25% of total household expenditure or income (%) | Age-standardized mortality rate attributed to household and ambient air pollution* (per 100 000 population) | Mortality rate attributed to exposure to unsafe WASH services* (per 100 000 population) | Mortality rate from unintentional poisoning* (per 100 000 population) |
|---------------------------------------------------------|------------------------------|-------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------|
| Primary data                                            | Comparable estimates         | Primary data                                                                                          | Primary data                                                                                           | Comparable estimates                                                                                              | Comparable estimates                                                                                       | Comparable estimates                                                                                     |
| 2013–2021                                              | 2013–2021                   | 2019                                                                                                  | 2019                                                                                                   | 2019                                                                                                            | 2019                                                                                                      | 2019                                                                                                     |
| 10                                                      | 77                           | 8.2                                                                                                   | 09                                                                                                     | 413                                                                                                             | 58                                                                                                        | 04                                                                                                       |
| 2.2                                                    | 77                           | 10.3                                                                                                  | 24                                                                                                     | 281                                                                                                             | 4.7                                                                                                       | 0.3                                                                                                      |
| 21                                                      | 78                           | 4.1                                                                                                   | 14                                                                                                     | 40.3                                                                                                           | 6.1                                                                                                       | 0.2                                                                                                      |
| -                                                       | 46                           | -                                                                                                     | -                                                                                                      | 1657                                                                                                           | 297                                                                                                       | 16                                                                                                       |
| 1.2                                                    | 79                           | 5.0                                                                                                   | 13                                                                                                     | 1737                                                                                                           | 465                                                                                                       | 3.3                                                                                                      |
| 0.5                                                    | 35                           | 3.5                                                                                                   | 0.6                                                                                                     | 1425                                                                                                           | 407                                                                                                       | 3.3                                                                                                      |
| 0.0                                                    | 58                           | 1187                                                                                                   | 108                                                                                                     | 0.3                                                                                                            | 0.3                                                                                                       | 0.3                                                                                                      |
| <01                                                    | 86                           | 6.7                                                                                                   | 0.7                                                                                                     | 74                                                                                                            | 0.8                                                                                                       | 0.4                                                                                                      |
| 01                                                      | 85                           | 100                                                                                                   | 34                                                                                                     | 0.3                                                                                                            | 0.3                                                                                                       | 0.3                                                                                                      |
| -                                                       | 49                           | 3.8                                                                                                   | 0.7                                                                                                     | 78.3                                                                                                           | 175                                                                                                       | 1.3                                                                                                      |
| 01                                                      | 68                           | 0.2                                                                                                   | <01                                                                                                     | 2205                                                                                                           | 295                                                                                                       | 18                                                                                                       |
| 01                                                      | 68                           | 314.8                                                                                                 | 9.8                                                                                                     | 9.2                                                                                                            | 3.3                                                                                                       | 6                                                                                                        |
| 0.7                                                    | 48                           | 13                                                                                                    | 0.1                                                                                                     | 1936                                                                                                           | 252                                                                                                       | 17                                                                                                       |
| 0.4                                                    | 77                           | 16.9                                                                                                  | 16                                                                                                      | 230                                                                                                            | 76                                                                                                        | 0.2                                                                                                      |
| 0.0                                                    | 59                           | 11.5                                                                                                  | 3.8                                                                                                     | 910                                                                                                            | 153                                                                                                       | 16                                                                                                       |
| 44                                                      | 40                           | 15                                                                                                    | <01                                                                                                     | 2380                                                                                                           | 578                                                                                                       | 2.3                                                                                                      |
| 16                                                      | 37                           | 51                                                                                                    | 0.4                                                                                                     | 2288                                                                                                           | 494                                                                                                       | 23                                                                                                       |
| 13                                                      | 76                           | 957                                                                                                   | 86                                                                                                      | <01                                                                                                           |                                                                                                           |                                                                                                          |
| 13                                                      | 54                           | 11.5                                                                                                  | 4.0                                                                                                     | 2064                                                                                                           | 259                                                                                                       | 14                                                                                                       |
| 25                                                      | 64                           | 112.5                                                                                                  | 71                                                                                                      | 0.5                                                                                                            |                                                                                                           |                                                                                                          |
| <01                                                    | 79                           | 12.3                                                                                                  | 0.9                                                                                                     | 42.3                                                                                                           | 26                                                                                                        | 0.5                                                                                                      |
| 0.0                                                    | 89                           | -                                                                                                     | 82                                                                                                      | 24                                                                                                            | 10                                                                                                       | 0.5                                                                                                      |
| 0.2                                                    | 63                           | 17.5                                                                                                  | 6.7                                                                                                     | 139.3                                                                                                          | 364                                                                                                       | 0.3                                                                                                      |
| 0.3                                                    | 55                           | 20                                                                                                    | 0.4                                                                                                     | 961                                                                                                            | 158                                                                                                       | 0.3                                                                                                      |
| 0.4                                                    | 74                           | 154.37                                                                                                 | 581                                                                                                      | 29                                                                                                            | 10                                                                                                       |                                                                                                          |
| 16                                                      | 59                           | 19.6                                                                                                  | 4.2                                                                                                     | 897                                                                                                            | 44                                                                                                        | 0.2                                                                                                      |
| <01                                                    | 83                           | 12.8                                                                                                  | 27                                                                                                      | 0.3                                                                                                            |                                                                                                           |                                                                                                          |
| 0.0                                                    | 85                           | 12.8                                                                                                  | 26                                                                                                      | 1.61                                                                                                           | 20                                                                                                        | <01                                                                                                       |
| 0.0                                                    | 84                           | -                                                                                                     | 150                                                                                                      | 30                                                                                                            | 0.3                                                                                                       |                                                                                                          |
| 0.0                                                    | 74                           | 359                                                                                                   | -                                                                                                       | <01                                                                                                           |                                                                                                           |                                                                                                          |
| <01                                                    | 83                           | 111                                                                                                   | 20                                                                                                      | 84                                                                                                            | 0.2                                                                                                       |                                                                                                          |
| 04                                                      | 65                           | 64                                                                                                    | 387                                                                                                      | 19                                                                                                            | 10                                                                                                       |                                                                                                          |
| <01                                                    | 80                           | 37                                                                                                    | 0.2                                                                                                     | 83.4                                                                                                           | 19                                                                                                        |                                                                                                          |
| 20                                                      | 53                           | 52                                                                                                    | 14                                                                                                      | 1319                                                                                                           | 20                                                                                                        | 24                                                                                                       |
| 1.8                                                    | 48                           | -                                                                                                     | 2466                                                                                                      | 374                                                                                                           | 2.6                                                                                                       |                                                                                                          |
| 0.0                                                    | 78                           | -                                                                                                     | 452                                                                                                      | 0.8                                                                                                           | 0.4                                                                                                       |                                                                                                          |
| <01                                                    | 69                           | 4.9                                                                                                   | 0.8                                                                                                     | 124.9                                                                                                          | 23.9                                                                                                      | 0.9                                                                                                      |
| 2.6                                                    | 52                           | 6.8                                                                                                   | 3.0                                                                                                     | 195.3                                                                                                           | 20.5                                                                                                       | 0.6                                                                                                      |
| 0.0                                                    | 75                           | 214                                                                                                   | 57                                                                                                      | 401                                                                                                            | 26                                                                                                        | 12                                                                                                       |
| 0.0                                                    | 73                           | -                                                                                                     | 586                                                                                                      | 24                                                                                                            | 0.6                                                                                                       |                                                                                                          |
| 01                                                      | 53                           | 288.3                                                                                                  | 1081                                                                                                      | 52                                                                                                            |                                                                                                           |                                                                                                          |
| 3.8                                                    | 45                           | 6.8                                                                                                   | 11                                                                                                      | 1527                                                                                                           | 34.6                                                                                                       | 17                                                                                                       |
| 0.0                                                    | 62                           | -                                                                                                     | 539                                                                                                      | 2.2                                                                                                            | 0.8                                                                                                       | 17                                                                                                       |
| <01                                                    | 75                           | 38.8                                                                                                  | 26                                                                                                      | 17                                                                                                            |                                                                                                           |                                                                                                          |
| 0.0                                                    | 83                           | 4.3                                                                                                   | 0.2                                                                                                     | 12.5                                                                                                           | 19.0                                                                                                      | 20.3                                                                                                      |
| 71                                                      | 35                           | 2080                                                                                                  | 401                                                                                                      | 21                                                                                                            |                                                                                                           |                                                                                                          |
| 21                                                      | 48                           | 29                                                                                                    | 0.4                                                                                                     | 148.5                                                                                                           | 30.8                                                                                                       | 17                                                                                                       |
| 01                                                      | 76                           | 15                                                                                                    | 1.5                                                                                                     | 765                                                                                                            | 14.0                                                                                                       | 07                                                                                                       |
| 01                                                      | 61                           | 10.3                                                                                                  | 4.1                                                                                                     | 320                                                                                                            | 23                                                                                                        | <01                                                                                                       |
| 6.8                                                    | 41                           | 17                                                                                                    | 01                                                                                                      | 1671                                                                                                           | 661                                                                                                       | 29                                                                                                       |


## Data Summary

### Table Data
json
[
    {
        "Country": "Malta",
        "2019 Probability of dying from CVD, cancer, diabetes, CRD between age 30 and exact age 90 (%)": 10.5,
        "2019 Suicide mortality rate (per 100 000 population)": 61,
        "2019 Total alcohol per capita consumption (litres of pure alcohol)": 8.5,
        "2019 Road traffic mortality rate (per 100 000 population)": 4.1,
        "2013-2021 Proportion of women of reproductive age who have their need for family planning satisfied with modern methods (%)": 110,
        "Adolescent birth rate (per 1000 women aged 15–19 years)": "-"
    },
    {
        "Country": "Marshall Islands",
        "2019 Probability of dying from CVD, cancer, diabetes, CRD between age 30 and exact age 90 (%)": 16.1,
        "2019 Suicide mortality rate (per 100 000 population)": 31,
        "2019 Total alcohol per capita consumption (litres of pure alcohol)": 0.0,
        "2019 Road traffic mortality rate (per 100 000 population)": 256,
        "2013-2021 Proportion of women of reproductive age who have their need for family planning satisfied with modern methods (%)": 224,
        "Adolescent birth rate (per 1000 women aged 15–19 years)": 896
    },
    {
        "Country": "Mauritania",
        "2019 Probability of dying from CVD, cancer, diabetes, CRD between age 30 and exact age 90 (%)": 23.2,
        "2019 Suicide mortality rate (per 100 000 population)": 95,
        "2019 Total alcohol per capita consumption (litres of pure alcohol)": 7.5,
        "2019 Road traffic mortality rate (per 100 000 population)": 122,
        "2013-2021 Proportion of women of reproductive age who have their need for family planning satisfied with modern methods (%)": 419,
        "Adolescent birth rate (per 1000 women aged 15–19 years)": 207
    },
    {
        "Country": "Mexico",
        "2019 Probability of dying from CVD, cancer, diabetes, CRD between age 30 and exact age 90 (%)": 15.6,
        "2019 Suicide mortality rate (per 100 000 population)": 53,
        "2019 Total alcohol per capita consumption (litres of pure alcohol)": 57,
        "2019 Road traffic mortality rate (per 100 000 population)": 12.2,
        "2013-2021 Proportion of women of reproductive age who have their need for family planning satisfied with modern methods (%)": 831,
        "Adolescent birth rate (per 1000 women aged 15–19 years)": 507
    },
    {
        "Country": "Micronesia (Federated States of)",
        "2019 Probability of dying from CVD, cancer, diabetes, CRD between age 30 and exact age 90 (%)": 46.3,
        "2019 Suicide mortality rate (per 100 000 population)": 28.2,
        "2019 Total alcohol per capita consumption (litres of pure alcohol)": 2.1,
        "2019 Road traffic mortality rate (per 100 000 population)": 0.2,
        "2013-2021 Proportion of women of reproductive age who have their need for family planning satisfied with modern methods (%)": "-",
        "Adolescent birth rate (per 1000 women aged 15–19 years)": "-"
    },
    {
        "Country": "Monaco",
        "2019 Probability of dying from CVD, cancer, diabetes, CRD between age 30 and exact age 90 (%)": 35.0,
        "2019 Suicide mortality rate (per 100 000 population)": 79,
        "2019 Total alcohol per capita consumption (litres of pure alcohol)": 210,
        "2019 Road traffic mortality rate (per 100 000 population)": 636,
        "2013-2021 Proportion of women of reproductive age who have their need for family planning satisfied with modern methods (%)": 269,
        "Adolescent birth rate (per 1000 women aged 15–19 years)": "-"
    },
    {
        "Country": "Montenegro",
        "2019 Probability of dying from CVD, cancer, diabetes, CRD between age 30 and exact age 90 (%)": 223,
        "2019 Suicide mortality rate (per 100 000 population)": 210,
        "2019 Total alcohol per capita consumption (litres of pure alcohol)": 103,
        "2019 Road traffic mortality rate (per 100 000 population)": 76,
        "2013-2021 Proportion of women of reproductive age who have their need for family planning satisfied with modern methods (%)": 329,
        "Adolescent birth rate (per 1000 women aged 15–19 years)": 95
    }
]
```
```
| Countries and areas                    | Probability of dying from any CVD, cancer, diabetes, CRD between age 30 and exact age  60 (%) | Suicide mortality rate* (per 100 000 population) | Total alcohol consumption* (per capita (≥ 15 years of age) (litres of pure alcohol) | Road traffic mortality rate* (per 100 000 population) | Proportion of women of reproductive age who have their need for family planning satisfied with modern methods (%) | Adolescent birth rate* (per 1000 women aged 15–19 years) | Primary data |
|----------------------------------------|-------------------------------------------------------------------------------------------------------|----------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|-----------------------------------------------------|----------------------------------------------------------------------------------------------------------------|---------------------------------------------------------|-------------|
| Slovenia                               | 114                                                                                                   | 198                                                | 110                                                                                                             | 51                                                  | 38                                                                                                             | 779                                                     | 4           |
| Solomon Islands                        | 39.2                                                                                                  | 14.7                                               | 16.5                                                                                                           | 38                                                  | -                                                                                                              | -                                                       | -           |
| Somalia                                | 304                                                                                                   | 79                                                 | 0                                                                                                               | 274                                                 | 21                                                                                                             | 1159                                                    | -           |
| South Africa                           | 241                                                                                                   | 235                                               | 8.8                                                                                                            | 222                                                 | 79.7                                                                                                           | 40.7                                                    | -           |
| South Sudan                            | 168                                                                                                   | 39                                                 | 367                                                                                                            | -                                                   | -                                                                                                              | -                                                       | -           |
| Spain                                  | 9.6                                                                                                   | 7.2                                                | 10.9                                                                                                           | -                                                   | 5.3                                                                                                            | -                                                       | -           |
| Sri Lanka                              | 132                                                                                                   | 14.0                                               | 28                                                                                                             | 191                                                 | 74.3                                                                                                           | 16.5                                                    | -           |
| Sudan                                  | 22.8                                                                                                  | 38                                                 | <0.1                                                                                                           | 268                                                 | 30.2                                                                                                           | 868                                                     | -           |
| Suriname                               | 227                                                                                                   | 254                                               | 6.6                                                                                                            | 15.3                                                 | 575                                                                                                            | 4.91                                                    | -           |
| Sweden                                 | 84                                                                                                    | 14.7                                               | 93                                                                                                             | 31                                                  | 867                                                                                                            | 24                                                      | -           |
| Switzerland                            | 79                                                                                                    | 14.5                                               | 104                                                                                                            | 2                                                   | 13                                                                                                             | -                                                       | -           |
| Syrian Arab Republic                  | 221                                                                                                   | 20                                                 | 0.2                                                                                                            | 14.9                                                 | -                                                                                                              | -                                                       | -           |
| Tajikistan                             | 283                                                                                                   | 4.3                                                | 0.9                                                                                                            | 157                                                 | 521                                                                                                            | 417                                                     | -           |
| Thailand                               | 187                                                                                                   | 88                                                 | 78                                                                                                             | 322                                                 | 882                                                                                                            | 274                                                     | -           |
| Timor-Leste                            | 19.9                                                                                                  | 37.4                                               | 0.4                                                                                                            | 419                                                 | 459                                                                                                            | 419                                                     | -           |
| Togo                                   | 239                                                                                                   | 88                                                 | 14                                                                                                             | 287                                                 | 789                                                                                                            | -                                                       | -           |
| Tonga                                  | 24.8                                                                                                  | 38                                                 | 0.4                                                                                                            | 330                                                 | 499                                                                                                            | -                                                       | -           |
| Trinidad and Tobago                   | 171                                                                                                   | 87                                                 | 6.1                                                                                                            | -                                                   | -                                                                                                              | -                                                       | -           |
| Tunisia                                | 157                                                                                                   | 33.2                                               | 20.5                                                                                                           | 165                                                 | 627                                                                                                            | 4.0                                                     | -           |
| Türkiye                                | 156                                                                                                   | 24                                                 | 18                                                                                                             | 602                                                 | 152                                                                                                            | 152                                                     | -           |
| Turkmenistan                           | 277                                                                                                   | 57                                                 | 29                                                                                                             | 12                                                  | 796                                                                                                            | 29.5                                                    | -           |
| Tuvalu                                 | 212                                                                                                   | 4.6                                                | 12                                                                                                             | 462                                                 | 403                                                                                                            | -                                                       | -           |
| Ukraine                                | 255                                                                                                   | 216                                               | 87                                                                                                             | 102                                                 | -                                                                                                              | 14.5                                                    | -           |
| United Arab Emirates                   | 18.5                                                                                                  | 64                                                 | 24                                                                                                             | 89                                                  | -                                                                                                              | 4.9                                                     | -           |
| United Kingdom                         | 103                                                                                                   | 79                                                 | 108                                                                                                            | 3.2                                                 | 10.0                                                                                                           | -                                                       | -           |
| United Republic of Tanzania            | 17.4                                                                                                  | 4.3                                                | 10.4                                                                                                           | 311                                                 | 551                                                                                                            | 1389                                                    | -           |
| United States of America               | 136                                                                                                   | 161                                               | 96                                                                                                             | 127                                                 | 78.4                                                                                                           | 151                                                     | -           |
| Uruguay                                | 16.5                                                                                                  | 212                                               | 55                                                                                                             | 1.8                                                 | -                                                                                                              | 291                                                     | -           |
| Uzbekistan                             | 253                                                                                                   | 80                                                 | 26                                                                                                             | 11.7                                                | -                                                                                                              | 34.3                                                    | -           |
| Vanuatu                                | 397                                                                                                   | 18                                                 | 19                                                                                                             | 14.9                                                 | 50.7                                                                                                           | 811                                                     | -           |
| Venezuela (Bolivarian Republic of)       | 14.8                                                                                                  | 20                                                 | 3.0                                                                                                            | 39.0                                                 | -                                                                                                              | 811                                                     | -           |
| Viet Nam                               | 212                                                                                                   | 75                                                 | 93                                                                                                             | 306                                                 | 721                                                                                                            | 290                                                     | -           |
| Yemen                                  | 276                                                                                                   | 58                                                 | <0.1                                                                                                           | 29.4                                                 | 405                                                                                                            | -                                                       | -           |
| Zambia                                 | 24.6                                                                                                  | 73                                                 | 3.9                                                                                                            | 205                                                 | 659                                                                                                            | 134.6                                                   | -           |
| Zimbabwe                               | 28.4                                                                                                  | 141                                               | 36                                                                                                             | 412                                                 | 84.8                                                                                                           | 1079                                                    | -           |
| Global                                 | 17.8                                                                                                  | 9.2                                                | 5.5                                                                                                            | 16.7                                                | 775                                                                                                            | 419                                                     | -           |


| Country/Area                         | 2020 | 2021 | 2021 | 2021 | 2021 | 2021 | 2021 | 2012-2019 |
|--------------------------------------|------|------|------|------|------|------|------|-----------|
| Afghanistan                          | 23.3 | 66   | 44   | 65   | -    | -    | 350     |
| Albania                              | 22.4 | 98   | 92   | 89   | -    | -    | 943     |
| Algeria                              | 21.0 | 91   | 77   | 91   | -    | -    | 0.53    |
| Andorra                              | 31.8 | -    | 99   | 97   | 95   | 83   | -       |
| Angola                               | -    | 45   | 32   | 34   | -    | -    | 2.26    |
| Antigua and Barbuda                  | -    | 76   | 79   | 74   | -    | -    | 53.102  |
| Argentina                            | 25.5 | 93   | 94   | 93   | -    | -    | 4.03    |
| Australia                            | 26.4 | 96   | 94   | 96   | -    | -    | 66      |
| Austria                              | 26.4 | -    | 88   | -    | -    | -    | -       |
| Azerbaijan                           | 26.6 | 89   | 90   | 90   | -    | -    | 0.34    |
| Bahamas                              | 10.6 | 75   | 82   | 82   | -    | -    | -       |
| Bahrain                              | 14.9 | 98   | 99   | 99   | -    | -    | -       |
| Bangladesh                           | 34.7 | 98   | 93   | 99   | -    | -    | 4.89    |
| Barbados                             | 8.5  | 82   | 70   | 83   | 28   | -    | 2.26    |
| Belarus                              | -    | -    | -    | -    | -    | -    | -       |
| Belgium                              | 23.4 | 98   | 85   | 94   | 70   | -    | 12.01   |
| Belize                               | 85.5 | 83   | 77   | -    | -    | -    | -       |
| Benin                                | -    | -    | -    | -    | -    | -    | -       |
| Bhutan                               | -    | 91   | 95   | 88   | 14.38| -    | -       |
| Bolivia (Plurinational State of)    | 1.2  | 70   | 56   | 70   | 36   | -    | 12.80   |
| Bosnia and Herzegovina               | 35.0 | 73   | 76   | 90   | -    | -    | 17.40   |
| Botswana                             | 19.4 | 95   | 70   | 22   | 341  | -    | -       |
| Brazil                               | 12.8 | 68   | 46   | 69   | 67   | -    | 0.83    |
| Brunei Darussalam                   | 16.2 | -    | 99   | 99   | -    | -    | -       |
| Bulgaria                             | 39.0 | 89   | 86   | 86   | -    | -    | 3       |
| Burkina Faso                        | 14.3 | 91   | 71   | 66   | -    | -    | 0.0     |
| Burundi                              | 11.8 | 94   | 85   | 86   | -    | -    | 0.0     |
| Cabo Verde                           | 114  | 93   | 86   | -    | -    | -    | 10.68   |
| Cambodia                             | 211  | 71   | 90   | -    | -    | -    | 521     |
| Cameroon                             | 73.9 | 69   | 35   | 67   | 5.3  | -    | 3.00    |
| Canada                               | 13.0 | 83   | 84   | 87   | -    | -    | -       |
| Central African Republic             | 42.0 | 42   | 40   | -    | -    | -    | -       |
| Chad                                 | -    | -    | 58   | -    | -    | -    | 360     |
| Chile                                | 29.2 | 95   | 58   | 92   | 57   | -    | 364.0   |
| China                                | 25.6 | 99   | 99   | -    | -    | -    | 0.08    |
| China, Hong Kong SAR                | -    | -    | -    | -    | -    | -    | -       |
| China, Macao SAR                    | 8.5  | 86   | 86   | 84   | 11   | -    | 3.34    |
| Comoros                              | 20.3 | 85   | 19   | -    | -    | -    | 49.05   |
| Congo                                | 14.5 | 77   | 31   | 75   | -    | -    | 2.97    |
| Cook Islands                         | 24.0 | 98   | 98   | -    | -    | -    | -       |
| Costa Rica                          | 8.8  | 69   | 92   | 59   | 2.85 | -    | -       |
| Côte d'Ivoire                        | 94   | 76   | 1    | 57   | 41   | -    | -       |
| Croatia                              | 36.9 | 92   | 90   | 75   | -    | -    | -       |
| Cuba                                 | 17.9 | 96   | 88   | 81   | -    | -    | 136     |
| Cyprus                               | 31.5 | 96   | 92   | 88   | -    | -    | -       |
| Czechia                              | 30.7 | 94   | 90   | -    | -    | -    | -       |
| Democratic People's Republic of Korea| 17.4 | -    | -    | 41   | 41   | -    | 0.03    |
| Democratic Republic of the Congo     | 12.8 | 65   | 63   | -    | -    | -    | 3.95    |
| Denmark                              | 17.5 | 97   | 94   | 96   | 80   | -    | 8.04    |
| Djibouti                             | -    | 59   | 48   | 59   | -    | -    | -       |
```
| Density of medical doctors* (per 10 000 population) | Density of nursing and midwifery personnel* (per 10 000 population) | Density of dentists* (per 10 000 population) | Density of pharmacists* (per 10 000 population) | Average of 15 International Health Regulations core capacity scores* | Percentage of bloodstream infections due to methicillin-resistant Staphylococcus aureus (%) | Percentage of bloodstream infections due to Escherichia coli resistant to 3rd-generation cephalosporin (%) | Domestic general government health expenditure (GGHE-D) as percentage of general government expenditure (GGE) (%) |
|------------------------------------------------------|---------------------------------------------------------------------|------------------------------------------------|-------------------------------------------------|---------------------------------------------------------------------|------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Primary data 2013–2021                                | Primary data 2013–2021                                             | Primary data 2013–2021                          | Primary data 2013–2021                            | Primary data 2013–2021                                             | Primary data 2022                                                                   | Primary data 2020                                                                                     | Primary data 2020                                                                                                                                                          |
| 25                                                   | 4.5                                                             | 0.7                                            | 0.3                                             | 40                                                                  | 4.3                                                                                        | -                                                                                                                  | -                                                                                                                                                                      |
| 188                                                  | 583                                                             | 103                                            | 91                                              | -                                                                   | 9.0                                                                                        | -                                                                                                                  | -                                                                                                                                                                      |
| 173                                                  | 15.6                                                            | 37.4                                           | 4.5                                             | 72                                                                  | -                                                                                          | -                                                                                                                  | 10.7                                                                                                                                                                   |
| 363                                                  | 437                                                             | 89.1                                           | -                                               | -                                                                   | -                                                                                          | -                                                                                                                  | 15.2                                                                                                                                                                   |
| 21                                                   | 4.0                                                             | 0.5                                            | 0.7                                             | 58                                                                  | -                                                                                          | -                                                                                                                  | 5.4                                                                                                                                                                    |
| 290                                                  | 9.58                                                            | 0                                           | 54                                              | -                                                                   | 12.6                                                                                       | -                                                                                                                  | -                                                                                                                                                                      |
| 390                                                  | 54.5                                                            | 79                                             | 5.0                                            | 67                                                                  | 38                                                                                         | 21                                                                                                                   | 15.7                                                                                                                                                                   |
| 455                                                  | 50.3                                                            | 57                                             | 0.5                                            | 84                                                                  | 21                                                                                         | 15                                                                                                                   | 17.5                                                                                                                                                                   |
| 410                                                  | 148.2                                                           | 63                                             | 10.4                                           | 89                                                                  | 18                                                                                         | 13                                                                                                                   | 17.2                                                                                                                                                                   |
| 54.6                                                 | 107.7                                                           | 5.8                                            | 73                                              | 69                                                                  | 5                                                                                          | 9                                                                                                                   | 15.4                                                                                                                                                                   |
| 311                                                  | 628.2                                                           | 27.9                                           | 19                                            | 81                                                                  | -                                                                                          | -                                                                                                                  | -                                                                                                                                                                      |
| 185                                                  | 438.2                                                           | 25.0                                           | 16                                            | 34                                                                  | 59                                                                                         | -                                                                                                                  | 83                                                                                                                                                                     |
| 67                                                   | 61.0                                                            | 17                                             | 0.7                                            | 68                                                                  | 71                                                                                         | 31                                                                                                                   | -                                                                                                                                                                      |
| 255                                                  | 314                                                             | 32                                             | 70                                            | -                                                                   | 11.2                                                                                       | -                                                                                                                  | -                                                                                                                                                                      |
| 443                                                  | 107.1                                                           | 61.5                                           | 3.5                                            | 95                                                                  | -                                                                                          | -                                                                                                                  | -                                                                                                                                                                      |
| 62.6                                                 | 205.3                                                           | 113                                            | 203                                           | 7                                                                   | 10.4                                                                                       | -                                                                                                                  | 14.8                                                                                                                                                                   |
| 10.8                                                 | 23.5                                                            | 14.6                                           | 63                                            | 46                                                                  | -                                                                                          | -                                                                                                                  | 12.6                                                                                                                                                                   |
| 0.61                                                 | 29.0                                                            | 0.1                                            | 0.3                                            | 12                                                                  | 54.0                                                                                       | -                                                                                                                  | 14.9                                                                                                                                                                   |
| 5.6                                                  | 221                                                             | 10                                             | 0.2                                            | 11                                                                  | 12                                                                                         | 11                                                                                                                  | -                                                                                                                                                                      |
| 210                                                  | 560                                                             | 23                                             | 13                                            | 36                                                                  | 23                                                                                         | 24                                                                                                                   | 14.9                                                                                                                                                                   |
| 3.5                                                  | 502.2                                                           | 0.7                                            | 20                                            | 42                                                                  | 12.0                                                                                       | -                                                                                                                  | -                                                                                                                                                                      |
| 214                                                  | 551                                                             | 67                                             | 34                                            | 69                                                                  | 10.8                                                                                       | -                                                                                                                  | -                                                                                                                                                                      |
| 191                                                  | 671                                                             | 24                                             | 2                                             | 13                                                                  | 17                                                                                         | -                                                                                                                  | 12.1                                                                                                                                                                   |
| 417                                                  | 474                                                             | 13                                             | 82.2                                           | 12                                                                  | 100                                                                                        | -                                                                                                                  | 12.1                                                                                                                                                                   |
| 0.9                                                  | 9.0                                                             | <0.01                                          | 57                                            | 100                                                                 | 64.0                                                                                       | 64                                                                                                                   | 115                                                                                                                                                                    |
| 0.6                                                  | 76                                                              | 0.1                                            | 0.2                                            | 42                                                                  | 8.3                                                                                        | -                                                                                                                  | -                                                                                                                                                                      |
| 79                                                   | 124                                                             | 21                                             | 30                                            | 62                                                                  | 10.4                                                                                       | -                                                                                                                  | -                                                                                                                                                                      |
| 21                                                   | 102                                                             | 0.9                                            | 0.3                                            | 60                                                                  | 68                                                                                         | 74                                                                                                                   | 74                                                                                                                                                                     |
| 12                                                   | 19                                                              | <0.01                                          | 40                                            | -                                                                   | 37                                                                                         | -                                                                                                                  | -                                                                                                                                                                      |
| 246                                                  | 1027                                                            | 66                                            | 105                                           | 96                                                                  | 18.3                                                                                       | -                                                                                                                  | -                                                                                                                                                                      |
| 0.7                                                  | 23                                                              | <0.01                                          | 34                                            | -                                                                   | 4.8                                                                                        | -                                                                                                                  | -                                                                                                                                                                      |
| 6.0                                                  | 2.0                                                             | <0.01                                          | 0.1                                            | 40                                                                  | -                                                                                          | -                                                                                                                  | 4.9                                                                                                                                                                    |
| 297                                                  | 460                                                             | 14.8                                           | 63                                            | 78                                                                  | 18.8                                                                                       | -                                                                                                                  | -                                                                                                                                                                      |
| 239                                                  | 330                                                             | 4.5                                            | 32                                            | 93                                                                  | -                                                                                          | -                                                                                                                  | 84                                                                                                                                                                     |
| 236                                                  | 14.5                                                            | 8.3                                            | 17                                            | 73                                                                  | -                                                                                          | -                                                                                                                  | 19.5                                                                                                                                                                   |
| 28                                                   | 159                                                             | 0.4                                            | 0.7                                            | 41                                                                  | -                                                                                          | -                                                                                                                  | 4.1                                                                                                                                                                    |
| 10                                                   | 9.3                                                             | 0.1                                            | 0.3                                            | 47                                                                  | -                                                                                          | -                                                                                                                  | 8.2                                                                                                                                                                    |
| 13.5                                                  | 81.9                                                            | 3.5                                            | 0.6                                            | 71                                                                  | -                                                                                          | -                                                                                                                  | -                                                                                                                                                                      |
| 277                                                  | 306                                                             | 10.6                                           | 117                                           | 65                                                                  | -                                                                                          | -                                                                                                                  | 25.2                                                                                                                                                                   |
| 16                                                   | 6.4                                                             | 0.1                                            | 0.4                                            | 53                                                                  | 72                                                                                         | 90                                                                                                                   | 6.7                                                                                                                                                                     |
| 347                                                  | 809                                                             | 122                                            | 72                                            | 76                                                                  | 50                                                                                         | 18                                                                                                                   | 17                                                                                                                                                                      |
| 84.3                                                 | 757                                                             | 167                                            | 29                                            | 164                                                                 | -                                                                                          | -                                                                                                                  | -                                                                                                                                                                      |
| 538                                                  | 463                                                             | 86                                             | 133                                           | 68                                                                  | 50                                                                                         | 52                                                                                                                   | 14.1                                                                                                                                                                   |
| 547                                                  | 920                                                             | 75                                             | 72                                            | 77                                                                  | 9                                                                                          | 13                                                                                                                   | 17.1                                                                                                                                                                   |
| 367                                                  | 44.3                                                            | 22                                             | 4.0                                            | 76                                                                  | -                                                                                          | -                                                                                                                  | -                                                                                                                                                                      |
| 3.6                                                  | 10.7                                                            | <0.01                                          | 0.2                                            | 48                                                                  | -                                                                                          | -                                                                                                                  | 6.3                                                                                                                                                                    |
| 426                                                  | 1054                                                            | 72                                             | 44                                            | 97                                                                  | 2                                                                                          | 7                                                                                                                   | 167                                                                                                                                                                     |
| 20                                                   | 66.0                                                            | 2                                             | 21                                            | 40                                                                  | 0                                                                                          | 0                                                                                                                   | 4.3                                                                                                                                                                    |


| Country and Area                    | 2020 Comparable Estimates | 2021 Comparable Estimates | 2021 Comparable Estimates | 2021 Comparable Estimates | 2021 Comparable Estimates | 2021 Primary Data | 2012-2019 Primary Data |
|-------------------------------------|---------------------------|---------------------------|---------------------------|---------------------------|---------------------------|-------------------|-----------------------|
| Dominica                            | 92                        | 88                        | 68                        | 74                        | 8                         | 21.70             | -                     |
| Dominican Republic                  | 10.6                      | 84                        | 60                        | 71                        | 8                         | 21.70             | -                     |
| Ecuador                             | 11.3                      | 72                        | 58                        | 62                        | 2                         | 500.0             | -                     |
| Egypt                               | 24.3                      | 96                        | 96                        | -                         | -                         | -                 | -                     |
| El Salvador                         | 79.9                      | 79                        | 94                        | 24                        | 4.79                      | -                 | -                     |
| Equatorial Guinea                   | 7.5                       | 95                        | 85                        | 95                        | 2.75                      | -                 | -                     |
| Estonia                             | 29.7                      | 90                        | 84                        | 57                        | -                         | -                 | -                     |
| Eswatini                            | 92.0                      | 77                        | 69                        | 63                        | 6.24                      | -                 | -                     |
| Ethiopia                            | 51.5                      | 65                        | 61                        | 75                        | 1.75                      | -                 | -                     |
| Fiji                                | 23.1                      | 99                        | 94                        | 99                        | -                         | -                 | -                     |
| Finland                             | 216.0                     | 89                        | 93                        | 82                        | -                         | -                 | -                     |
| France                              | 33.4                      | 96                        | 86                        | 92                        | -                         | -                 | -                     |
| Gabon                               | 111                       | 82                        | 67                        | 78                        | 30                        | 16.03             | -                     |
| Gambia                              | 111                       | 82                        | 67                        | 78                        | 30                        | 16.03             | -                     |
| Georgia                             | 85                        | 81                        | 82                        | 47                        | 4.48                      | -                 | -                     |
| Germany                             | 22.0                      | 91                        | 93                        | 82                        | 47                        | 4.48                      | -                     |
| Ghana                               | 33.5                      | 98                        | 83                        | 89                        | -                         | 12.5**            | -                     |
| Greece                              | 33.5                      | 99                        | 83                        | 96                        | -                         | -                 | -                     |
| Grenada                             | 47                        | 7                         | 67                        | -                         | -                         | -                 | -                     |
| Guatemala                           | 10.9                      | 79                        | 72                        | 15                        | 2.48                      | -                 | -                     |
| Guinea-Bissau                       | 9.0                       | 67                        | 67                        | -                         | -                         | -                 | -                     |
| Guyana                              | 121                       | 91                        | 83                        | 99                        | 2                         | 5.10              | -                     |
| Haiti                               | 77                        | 51                        | 41                        | 51                        | -                         | -                 | -                     |
| Honduras                            | 7.9                       | 77                        | 75                        | 77                        | 53                        | 2.68              | -                     |
| Hungary                             | 318.0                     | 99                        | 99                        | 99                        | 82                        | -                 | -                     |
| Iceland                             | 12.0                      | 92                        | 10                        | 92                        | 90                        | -                 | -                     |
| India                               | 27.2                      | 75                        | 82                        | 25                        | 0.22                      | -                 | -                     |
| Indonesia                           | 67                        | 50                        | 1                         | 5                         | 1                         | 5                 | 1.26                  |
| Iran (Islamic Republic of)         | 13.6                      | 98                        | 98                        | 1                         | 0.83                      | -                 | -                     |
| Iraq                                | 18.5                      | 78                        | 84                        | 0                         | 0.94                      | -                 | -                     |
| Ireland                             | 20.8                      | 94                        | 85                        | 71                        | -                         | -                 | -                     |
| Israel                              | 212.0                     | 98                        | 93                        | 55                        | -                         | -                 | -                     |
| Italy                               | 231.1                     | 94                        | 86                        | 91                        | -                         | -                 | -                     |
| Jamaica                             | 21.9                      | 90                        | 85                        | 2                         | 2.94                      | -                 | -                     |
| Japan                               | 20.1                      | 96                        | 95                        | -                         | -                         | -                 | -                     |
| Jordan                              | 34.8                      | 77                        | 90                        | -                         | -                         | -                 | -                     |
| Kazakhstan                          | 23.2                      | 95                        | 96                        | 93                        | -                         | 0.64              | -                     |
| Kenya                               | 111                       | 91                        | 57                        | 44                        | 3.79                      | -                 | -                     |
| Kiribati                            | 40.6                      | 91                        | 56                        | 58                        | 72.18                    | -                 | -                     |
| Kuwait                              | 17.9                      | 94                        | 94                        | -                         | -                         | -                 | -                     |
| Kyrgyzstan                          | 25.4                      | 89                        | 97                        | 90                        | -                         | 4.79              | 0.00**               |
| Lao People's Democratic Republic     | 31.8                      | 75                        | 50                        | 74                        | 42                        | 12.59             | 25.3                 |
| Latvia                              | 37.0                      | 94                        | 85                        | 92                        | 42                        | 2278              | 52.5                 |
| Lebanon                             | 38.2                      | 67                        | 59                        | 70                        | 22.78                    | 52.5              | -                     |
| Lesotho                             | 24.3                      | 87                        | 82                        | 87                        | -                         | 4.41              | -                     |
| Liberia                             | 22.6                      | 35                        | 65                        | 30                        | 10.04                    | -                 | -                     |
| Libya                               | 7.2                       | 73                        | 73                        | 73                        | -                         | 5.01              | -                     |
| Lithuania                           | 32.0                      | 90                        | 88                        | 66                        | -                         | -                 | -                     |
| Luxembourg                          | 211                       | 90                        | 90                        | 96                        | -                         | -                 | -                     |
| Madagascar                          | 27.8                      | 55                        | 24                        | 3.25                      | -                         | -                 | -                     |
| Malawi                              | 10.8                      | 93                        | 74                        | 93                        | 12                        | 12.79             | -                     |
| Malaysia                            | 22.5                      | 95                        | 84                        | 14                        | 0.66                      | -                 | -                     |


| Year          | Density of medical doctors (per 10,000 population) | Density of nursing and midwifery personnel (per 10,000 population) | Density of dentists (per 1,000 population) | Density of pharmacists (per 10,000 population) | Average of 15 International Health Regulations core capacity scores | Percentage of bloodstream infections due to methicillin-resistant Staphylococcus aureus (%) | Percentage of bloodstream infections due to Escherichia coli resistant to 3rd-generation cephalosporins (%) | Domestic general government health expenditure (GGHE-D) as percentage of general government expenditure (GGE) (%) |
|---------------|------------------------------------------------------|---------------------------------------------------------------------|---------------------------------------------|------------------------------------------------|------------------------------------------------------------------|--------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| 2013-2018     | 112                                                  | 651                                                                 | 11                                          | 61                                             | -                                                               | 5.4                                                                                           | -                                                                                                    | 14.7                                                                                                           |
| 2013-2021     | 223                                                  | 252                                                                 | 3                                           | 12                                             | 62                                                               | -                                                                                             | -                                                                                                    | 13.9                                                                                                           |
| 2013-2021     | 71                                                   | 183                                                                 | 19                                          | 4                                              | 87                                                               | 100                                                                                          | 90                                                                                                   | 52                                                                                                             |
| 2013-2021     | 291                                                  | 264                                                                 | 8.5                                         | 54                                             | 92                                                               | -                                                                                             | -                                                                                                    | 17.8                                                                                                           |
| 2013-2021     | 3.5                                                  | 2.7                                                                 | 0.1                                         | 43                                             | 87                                                               | -                                                                                             | -                                                                                                    | 5.3                                                                                                             |
| 2013-2021     | 0.8                                                  | 14.4                                                                | 0.5                                         | 13                                             | 58                                                               | -                                                                                             | -                                                                                                    | 2.4                                                                                                             |
| 2013-2021     | 386.6                                                | 1118                                                                | 101                                         | 74                                             | 75                                                               | -                                                                                             | -                                                                                                    | 13.0                                                                                                           |
| 2013-2021     | 14                                                   | 247                                                                 | 0.2                                         | 0.4                                            | 44                                                               | 2                                                                                             | -                                                                                                    | 10.0                                                                                                           |
| 2013-2021     | 10                                                   | 77                                                                  | <1                                          | <1                                            | 60                                                               | 67                                                                                           | -                                                                                                    | 6.8                                                                                                             |
| 2013-2021     | 81                                                   | 384                                                                 | 12                                          | 10                                             | 48                                                               | 7                                                                                             | -                                                                                                    | 13.7                                                                                                           |
| 2013-2021     | 332                                                  | 122.2                                                               | 6.6                                         | 10.6                                          | 81                                                               | 12                                                                                             | -                                                                                                    | 10.5                                                                                                           |
| 2013-2021     | 59                                                   | 26.8                                                                | 0.1                                         | 0.6                                            | 42                                                               | -                                                                                             | -                                                                                                    | 9.6                                                                                                             |
| 2013-2021     | 8.9                                                  | 8.8                                                                 | <1                                          | <1                                            | 44                                                               | 81                                                                                           | -                                                                                                    | 10.6                                                                                                           |
| 2013-2021     | 540.87                                               | 452.123                                                             | 8.5                                         | 6.7                                            | 87                                                               | 6                                                                                             | 10                                                                                                    | 19.8                                                                                                           |
| 2013-2021     | 16                                                    | 350.0                                                               | 0.2                                         | 0.4                                            | 52                                                               | 64                                                                                           | -                                                                                                    | 6.9                                                                                                             |
| 2013-2021     | 631                                                  | 370.0                                                               | 13.0                                        | 109                                           | 68                                                               | 41                                                                                           | 25                                                                                                   | 8.4                                                                                                             |
| 2013-2021     | 131                                                  | 575.178                                                            | 18                                          | 6.3                                            | 35                                                               | -                                                                                             | -                                                                                                    | 8.4                                                                                                             |
| 2013-2021     | 128                                                  | 231.26                                                              | 2                                           | 12                                             | 41                                                               | -                                                                                             | -                                                                                                    | 11.9                                                                                                           |
| 2013-2021     | 22                                                   | 57                                                                  | 1.1                                         | 20                                             | 51                                                               | -                                                                                             | -                                                                                                    | 6.2                                                                                                             |
| 2013-2021     | 2.24                                                 | 10.5                                                               | <1                                          | <1                                            | 40                                                               | 28                                                                                          | -                                                                                                    | 1.8                                                                                                             |
| 2013-2021     | 14.0                                                 | 34.8                                                                | 0.7                                         | 0.6                                            | 54                                                               | -                                                                                             | -                                                                                                    | 1.31                                                                                                          |
| 2013-2021     | 2.4                                                  | 4.0                                                                 | 0.2                                         | 0.3                                            | 56                                                               | 4.1                                                                                           | -                                                                                                    | 4.1                                                                                                             |
| 2013-2021     | 4.9                                                  | 71                                                                  | 0.3                                         | 0.3                                            | 59                                                               | -                                                                                             | -                                                                                                    | 12.3                                                                                                           |
| 2013-2021     | 329                                                  | 660.67                                                             | 67.7                                         | 78.7                                           | 70                                                               | -                                                                                             | -                                                                                                    | 10.1                                                                                                           |
| 2013-2021     | 389                                                  | 1633.79                                                            | 79.5                                         | 57.7                                           | 77                                                               | -                                                                                             | -                                                                                                    | 15.7                                                                                                           |
| 2013-2021     | 73                                                   | 173                                                                | 16                                          | 86.5                                           | 65                                                               | 87                                                                                           | -                                                                                                    | 3.3                                                                                                             |
| 2013-2021     | 70                                                   | 112                                                                | 12                                          | 3                                            | 72                                                               | 36                                                                                           | -                                                                                                    | 10.1                                                                                                           |
| 2013-2021     | 151                                                  | 198.43                                                              | 2.8                                         | 86                                             | 44                                                               | 69                                                                                           | -                                                                                                    | 22.1                                                                                                           |
| 2013-2021     | 91                                                   | 226.33                                                              | 3.9                                         | 66.86                                          | 95                                                               | -                                                                                             | -                                                                                                    | 6.86                                                                                                           |
| 2013-2021     | 406                                                  | 1490.66                                                             | 6.6                                         | 137                                            | 56                                                               | 14                                                                                             | 11                                                                                                    | 20.5                                                                                                           |
| 2013-2021     | 365                                                  | 563.89                                                              | 8.9                                         | 84.86                                          | 70                                                               | 37                                                                                             | 29                                                                                                    | 12.9                                                                                                           |
| 2013-2021     | 413                                                  | 655.86                                                              | 12.4                                        | 70                                             | 37                                                               | 29                                                                                             | 12.9                                                                                                           | 9.0                                                                                                             |
| 2013-2021     | 261                                                  | 124.5                                                               | 20.0                                        | 99                                             | 36                                                               | 21                                                                                             | 20.6                                                                                                           |
| 2013-2021     | 251                                                  | 316.74                                                              | 9.8                                         | 60                                             | 58                                                               | 65                                                                                           | -                                                                                                    | 10.8                                                                                                           |
| 2013-2021     | 403                                                  | 719.29                                                              | 2.9                                         | 80                                             | 80                                                               | 10.2                                                                                         | -                                                                                                    | 0.0                                                                                                             |
| 2013-2021     | 23                                                   | 12.0                                                                | 0.3                                         | 0.2                                            | 45                                                               | 25                                                                                           | 0.0                                                                                                    | 8.2                                                                                                             |
| 2013-2021     | 19                                                   | 362.07                                                              | 0.3                                         | 0.4                                            | 35                                                               | -                                                                                             | -                                                                                                    | 8.4                                                                                                             |
| 2013-2021     | 229                                                  | 549.66                                                              | 4.8                                         | 92                                             | 100                                                              | 100                                                                                          | 100                                                                                                   | 8.7                                                                                                             |
| 2013-2021     | 217                                                  | 568.19                                                              | 0.4                                         | 48                                             | -                                                                | -                                                                                             | -                                                                                                    | 6.9                                                                                                             |
| 2013-2021     | 118                                                  | 0.8                                                                | 2.3                                         | 50                                             | 51                                                               | -                                                                                             | -                                                                                                    | 6.2                                                                                                             |
| 2013-2021     | 335                                                  | 440.72                                                              | 8.8                                         | 68                                             | 14                                                               | 33                                                                                           | 10.9                                                                                                   | -                                                                                                             |
| 2013-2021     | 262                                                  | 193.18                                                              | 14.9                                        | 72                                             | 35                                                               | 56                                                                                           | 13                                                                                                    | 13.4                                                                                                           |
| 2013-2021     | 4                                                    | 312.0                                                               | 2.2                                         | 18                                             | 40                                                               | -                                                                                             | -                                                                                                    | 111                                                                                                         |
| 2013-2021     | 0.5                                                  | 703.19                                                              | <1                                          | 22                                             | 58                                                               | -                                                                                             | -                                                                                                    | 4.5                                                                                                             |
| 2013-2021     | 216                                                  | 674.91                                                              | 6.2                                         | 53                                             | 83                                                               | 62                                                                                           | 10                                                                                                    | 12.1                                                                                                           |
| 2013-2021     | 299                                                  | 1208.97                                                             | 70                                          | 67                                             | 3                                                                | 11.0                                                                                         | -                                                                                                    | 10.8                                                                                                           |
| 2013-2021     | 19                                                   | 2.9                                                                | 0.2                                         | 0.1                                            | 48                                                               | -                                                                                             | -                                                                                                    | 8.8                                                                                                             |
| 2013-2021     | 0.5                                                  | 70.0                                                               | 0.1                                         | 50                                             | 61                                                               | 57                                                                                           | -                                                                                                    | 8.7                                                                                                             |
| 2013-2021     | 223                                                  | 339.30                                                              | 34.89                                       | 17                                             | 26                                                               | 8.6                                                                                           | -                                                                                                    | 0.0                                                                                                             |


| Countries and areas                                   | 2020 | 2021 | 2021 | 2021 | 2021 | 2021 | 2021 | Primary data | Primary data |
|------------------------------------------------------|------|------|------|------|------|------|------|--------------|--------------|
| Maldives                                             | 252.6| 96   | 96   | -    | 230.0| -    | -    | -            | -            |
| Mali                                                 | 8.3  | 77   | 33   | 77   | 518  | 0.0  | -    | -            | -            |
| Malta                                                | 24.0 | 99   | 93   | 99   | 99   | 99   | -    | -            | -            |
| Marshall Islands                                     | 28.5 | 86   | 58   | 61   | 27   | 218  | -    | -            | -            |
| Mauritania                                          | 10.7 | 68   | 65   | 65   | 1166 | -    | -    | -            | -            |
| Mauritius                                           | 20.2 | 92   | 64   | 94   | 55   | -    | -    | -            | -            |
| Mexico                                              | 13.1 | 78   | 97   | 83   | 1    | 0.04 | -    | -            | -            |
| Micronesia (Federated States of)                   |  -   | 72   | 38   |  -   | 32   | 264  | -    | -            | -            |
| Monaco                                              | 29.4 | 95   | 94   | 95   | -    | 14.89| 267 | -            | -            |
| Mongolia                                            | 30.9 | 99   | -    | -    | -    | -    | -    | -            | -            |
| Montenegro                                          | 31.4 | 83   | 79   | -    | -    | -    | -    | -            | -            |
| Morocco                                             | 14.5 | -    | -    | -    | -    | -    | -    | -            | -            |
| Mozambique                                          | 43.3 | 61   | 70   | -    | 572  | -    | -    | -            | -            |
| Myanmar                                             | 41.1 | 37   | 42   | -    | 321  | -    | -    | -            | -            |
| Namibia                                             |  -   | 63   |  -    | -    | 9843 | -    | -    | -            | -            |
| Nauru                                               | 48.5 | 98   | 97   | 59   | 9843 | -    | -    | -            | -            |
| Nepal                                               | 30.4 | 91   | 87   | 84   | -    | 5.08 | -    | -            | -            |
| Netherlands (Kingdom of the)                       | 22.2 | 95   | 90   | 93   | 66   | -    | -    | -            | -            |
| New Zealand                                         | 13.7 | 90   | 82   | 82   | 48   | -    | -    | -            | -            |
| Nicaragua                                           |  -   | 87   | 83   | 87   | 17.69| -    | -    | -            | -            |
| Niger                                               | 74   | 62   | 66   | 82   | 4.48 | -    | -    | -            | -            |
| Nigeria                                             | 37   | 56   | 36   | 32   | 2.3  | -    | -    | -            | -            |
| Niue                                                |  -   | 99   | 99   | 99   | 76   | 490.1| -    | -            | -            |
| North Macedonia                                     | -    | 81   | 80   | 53   | 21   | 775  | -    | -            | -            |
| Norway                                              | 16.2 | -    | 95   | 96   | 93   | -    | -    | -            | -            |
| occupied Palestinian territory, including east Jerusalem |  -   | 99   | 99   | 95   | -    | -    | -    | -            | -            |
| Oman                                                | 8.0  | 99   | 99   | 99   | -    | -    | -    | -            | -            |
| Pakistan                                            | 20.2 | 83   | 79   | 83   | 3.61 | -    | -    | -            | -            |
| Palau                                               | 17.6 | 95   | 84   | 77   | 21   | 615  | -    | -            | -            |
| Panama                                              | 50.0 | 74   | 74   | 74   |  -   | 1.00 | -    | -            | -            |
| Papua New Guinea                                    | 39.3 | 31   | 20   |  -    | 32   | 15.69| -    | -            | -            |
| Paraguay                                            | 11.5 | 70   | 67   | 62   | 17   | 27.7 | -    | -            | -            |
| Peru                                                | 81.1 | 82   | 60   | 53   | 108  | 692  | -    | -            | -            |
| Philippines                                         | 22.9 | 57   | 55   | 51   | 0    | 245  | -    | -            | -            |
| Poland                                              | 24.0 | 90   | 95   | 62   | -    | -    | -    | -            | -            |
| Portugal                                            | 25.4 | 99   | 95   | 98   | 76   | -    | -    | -            | -            |
| Puerto Rico                                         | -    | 98   | 99   | 98   | -    | -    | -    | -            | -            |
| Qatar                                               | 11.8 | 98   | 99   | 98   | -    | -    | -    | -            | -            |
| Republic of Korea                                   | 20.8 | 98   | 96   | 98   | -    | -    | -    | -            | -            |
| Republic of Moldova                                 | 29.0 | 87   | 92   | 78   | 35   | 722  | 250 | -            | -            |
| Romania                                             | 28.0 | 86   | 75   | 85   | -    | -    | -    | -            | -            |
| Russian Federation                                   | 26.8 | 97   | 96   | 89   | -    | -    | -    | -            | -            |
| Rwanda                                              | 13.7 | 88   | 85   | 88   | 73   | 10.94| -    | -            | -            |
| Saint Kitts and Nevis                              | -    | 96   | 94   | -    | -    | -    | -    | -            | -            |
| Saint Lucia                                         | -    | 80   | 66   | -    | -    | -    | -    | -            | -            |
| Saint Vincent and the Grenadines                   | -    | 97   | -    | -    | 24.57| -    | -    | -            | -            |
| Samoa                                               | 25.3 | 85   | 50   |  -   | 3.64 | -    | -    | -            | -            |
| San Marino                                          | 5.7  | 69   | 81   | 82   | 23   | 20.99| -    | -            | -            |
| Sao Tome and Principe                               | -    |  -   | -    | -    | -    | -    | -    | -            | -            |
| Saudi Arabia                                        | 14.3 | 97   | 97   | 97   | -    | -    | -    | -            | -            |
| Senegal                                             | 6.9  | 85   | 75   | 86   |  -   | -    | -    | -            | -            |
| Serbia                                              | 39.8 | 92   | 84   | 87   | 6.15 | -    | -    | -            | -            |
```
[
    {
        "Density of medical doctors (per 10 000 population)": 216,
        "Density of nursing and midwifery personnel (per 10 000 population)": 12,
        "Density of dentist (per 10 000 population)": 54.9,
        "Density of pharmacists (per 10 000 population)": 19,
        "Average of 15 International Health Regulations core capacity scores": 266,
        "Percentage of bloodstream infections due to methicillin-resistant Staphylococcus aureus (%)": 24.4,
        "Percentage of bloodstream infections due to Escherichia coli resistant to 3rd-generation cephalosporins (%)": 9.6,
        "Domestic general government health expenditure (GGHE-D) as percentage of general government expenditure (GGE)": 12.8
    },
    {
        "Primary data (2013-2021)": 490,
        "Primary data (2022)": 10.8,
        "Primary data (2020)": 56,
        "Comparable estimates (2020)": 18.2
    },
    {
        "Primary data (2013-2021)": 42,
        "Primary data (2022)": 0.1,
        "Primary data (2020)": 44,
        "Comparable estimates (2020)": 5.7
    },
    {
        "Primary data (2013-2021)": 144.0,
        "Primary data (2022)": 66,
        "Primary data (2020)": 255.73,
        "Comparable estimates (2020)": 156
    },
    {
        "Primary data (2013-2021)": 42,
        "Primary data (2022)": 0.5,
        "Primary data (2020)": 0.2,
        "Comparable estimates (2020)": 4.1
    },
    {
        "Primary data (2013-2021)": 385.27,
        "Primary data (2022)": 58.6,
        "Primary data (2020)": 46,
        "Comparable estimates (2020)": 10.2
    },
    {
        "Primary data (2013-2021)": 296,
        "Primary data (2022)": 1.2,
        "Primary data (2020)": 75,
        "Comparable estimates (2020)": "."
    },
    {
        "Primary data (2013-2021)": 220,
        "Primary data (2022)": 51,
        "Primary data (2020)": 51,
        "Comparable estimates (2020)": 4.1
    },
    {
        "Primary data (2013-2021)": 2083,
        "Primary data (2022)": 10.5,
        "Primary data (2020)": 271,
        "Comparable estimates (2020)": 4.8
    },
    {
        "Primary data (2013-2021)": 422,
        "Primary data (2022)": 4.1,
        "Primary data (2020)": 68,
        "Comparable estimates (2020)": 7.5
    },
    {
        "Primary data (2013-2021)": 568,
        "Primary data (2022)": 0.6,
        "Primary data (2020)": 2.3,
        "Comparable estimates (2020)": 13.1
    },
    {
        "Primary data (2013-2021)": 139,
        "Primary data (2022)": 14,
        "Primary data (2020)": 26,
        "Comparable estimates (2020)": 7.2
    },
    {
        "Primary data (2013-2021)": 57,
        "Primary data (2022)": 0.1,
        "Primary data (2020)": 81,
        "Comparable estimates (2020)": 32
    },
    {
        "Primary data (2013-2021)": 110,
        "Primary data (2022)": 0.8,
        "Primary data (2020)": 51,
        "Comparable estimates (2020)": 81
    },
    {
        "Primary data (2013-2021)": 199,
        "Primary data (2022)": 0.7,
        "Primary data (2020)": 25,
        "Comparable estimates (2020)": 65
    },
    {
        "Primary data (2013-2021)": 706,
        "Primary data (2022)": 33,
        "Primary data (2020)": 18,
        "Comparable estimates (2020)": 67
    }
]
```
| Countries and areas                           | 2020 | 2021 | 2021 | 2021 | 2021 | 2021 | 2012-2019 |
|------------------------------------------------|------|------|------|------|------|------|-----------|
| Seychelles                                     | 20.2 | 94   | 85   | 39   | -    | -    | -         |
| Sierra Leone                                   | 13.5 | 92   | 67   | 90   | -    | -    | 5.93      |
| Singapore                                      | 16.5 | 96   | 84   | 82   | -    | -    | -         |
| Slovakia                                       | 31.5 | 97   | 96   | 97   | -    | -    | -         |
| Slovenia                                       | 22.0 | 86   | 91   | 58   | 50   | -    | -         |
| Solomon Islands                                | 36.5 | 87   | 40   | 86   | -    | -    | 1787      |
| Somalia                                        | 42   | 4    | -    | -    | -    | -    | 5.91      |
| South Africa                                   | 20.3 | 86   | 82   | 87   | 34   | -    | 15.68     |
| South Sudan                                    | 49   | -    | -    | -    | -    | -    | -         |
| Spain                                          | 277.0| 92   | 91   | 92   | 77   | -    | 683.0*    |
| Sri Lanka                                      | 22.0 | 96   | 97   | 46   | -    | -    | 410.0     |
| Sudan                                          | 63   | 85   | -    | -    | -    | -    | 360.0     |
| Suriname                                       | 72   | 43   | -    | -    | -    | -    | 1548      |
| Sweden                                         | 24.0 | 98   | 91   | 97   | 83   | -    | -         |
| Switzerland                                    | 25.5 | 96   | 94   | 88   | 71   | -    | -         |
| Syrian Arab Republic                           | 33   | -    | -    | -    | -    | -    | 5.27      |
| Tajikistan                                     | 96   | -    | -    | -    | -    | -    | 8.56      |
| Thailand                                       | 221  | 87   | 86   | -    | -    | -    | 0.55      |
| Timor-Leste                                    | 39.2 | 86   | 78   | -    | -    | -    | 3154      |
| Togo                                           | 68.8 | 83   | 50   | 83   | -    | -    | 525       |
| Tonga                                          | 31.0 | 99   | 99   | 67   | 8    | -    | 50.65     |
| Trinidad and Tobago                            | 24.6 | 97   | 98   | 96   | 718  | -    | -         |
| Tunisie                                        | 30.7 | 95   | 93   | 96   | -    | -    | 0.31      |
| Turquie                                        | 5.5  | 97   | 98   | 97   | 99   | -    | 1.69      |
| Turkmenistan                                   | 35.6 | 94   | 84   | 27   | 19778| -    | -         |
| Tuvalu                                         | 84.0 | 91   | 91   | 44   | 594  | -    | -         |
| Ukraine                                        | 25.8 | 78   | 86   | 95   | 117  | -    | 19.8      |
| United Arab Emirates                           | 76   | 96   | 96   | 95   | -    | -    | -         |
| United Kingdom                                  | 15.4 | 93   | 87   | 91   | 59   | -    | -         |
| United Republic of Tanzania                    | 87   | 81   | 62   | 80   | 57   | -    | 3.82      |
| United States of America                       | 230  | 95   | 82   | 82   | 48   | -    | -         |
| Uruguay                                        | 215.9| 84   | 94   | 17   | -    | -    | 172       |
| Uzbekistan                                     | 214.0| 98   | 99   | 98   | 87   | 172  | -         |
| Vanuatu                                        | 178.0| 62   | 2    | -    | -    | -    | 54.23     |
| Venezuela (Bolivarian Republic of)            | 56   | 37   | 0    | -    | -    | -    | 101       |
| Viet Nam                                       | 24.8 | 83   | 85   | -    | -    | -    | 216       |
| Yemen                                          | 20.3 | 72   | 52   | 72   | -    | -    | -         |
| Zambia                                         | 14.4 | 91   | 81   | 89   | 33   | -    | 6.92      |
| Zimbabwe                                       | 11.7 | 86   | 74   | 86   | 40   | -    | 9.65      |
| WHO region                                     | 2020 | 2021 | 2021 | 2021 | 2021 | 2021 | -         |
| African Region                                 | 10.3 | 71   | 41   | 66   | 21   | 4.08 | -         |
| Region of the Americas                         | 16.3 | 80   | 75   | 74   | 38   | 2.02 | -         |
| South-East Asia Region                         | 29.0 | 82   | 78   | 29   | -    | 0.95 | -         |
| European Region                                | 25.3 | 94   | 91   | 82   | 27   | 2.04 | -         |
| Eastern Mediterranean Region                   | 18.6 | 82   | 77   | 54   | 316  | 0.64 | -         |
| Western Pacific Region                         | 24.6 | 90   | 91   | 19   | 2.00 | -         |
| Global                                         | 22.3 | 81   | 71   | 51   | 12   | -    | -         |



| Year        | Density of medical doctors* (per 10,000 population) | Density of nursing and midwifery personnel* (per 10,000 population) | Density of dentists* (per 10,000 population) | Density of pharmacists* (per 10,000 population) | Average of 15 International Health Regulations core capacity scores* | Percentage of bloodstream infections due to methicillin-resistant Staphylococcus aureus (%) | Percentage of bloodstream infections due to Escherichia coli resistant to 3rd-generation cephalosporins (%) | Domestic general government health expenditure (GGHE-D) as percentage of general government expenditure (GGED) |
|-------------|----------------------------------------------------|--------------------------------------------------------------------|------------------------------------------------|---------------------------------------------------|--------------------------------------------------------------------|-----------------------------------------------------------------------|----------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------|
| 2013–2021   | 922                                                | 4.0                                                                | 12.0                                            | 52                                                | -                                                                  | -                                                                 | -                                                                                                  | 10.2                                                                                                                                                   |
| 2013–2021   | 07                                                 | 2.0                                                                | <1                                             | 0.2                                                | 51                                                                  | -                                                                 | -                                                                                                  | 5.3                                                                                                                                                    |
| 2013–2021   | 243                                                | 618                                                                | 4.1                                            | 50                                                | 94                                                                  | 31                                                                | -                                                                                                  | 13.3                                                                                                                                                   |
| 2013–2021   | 463                                                | 785                                                                | 71                                             | 105                                               | 65                                                                  | 12.8                                                              | -                                                                                                  | 12.8                                                                                                                                                   |
| 2013–2021   | 328                                                | 1054                                                               | 74                                             | 80                                                | -                                                                  | 134                                                               | -                                                                                                  | -                                                                                                                                                      |
| 2013–2021   | 1.9                                                | 214                                                                | 0.7                                            | 12                                                | -                                                                  | 101                                                               | -                                                                                                  | -                                                                                                                                                      |
| 2013–2021   | 2                                                 | 11                                                                 | 27                                             | 73                                                | 20                                                                | 28                                                                | -                                                                                                  | 15.3                                                                                                                                                   |
| 2013–2021   | 0.4                                                | 36                                                                 | <1                                             | 0.3                                                | 40                                                                  | 21                                                                | -                                                                                                  | -                                                                                                                                                      |
| 2013–2021   | 458                                                | 631                                                                | 84                                             | 132                                               | 82                                                                  | 50                                                                | -                                                                                                  | 25                                                                                                                                                    |
| 2013–2021   | 2.4                                                | 24                                                                 | <1                                             | 66                                                | 53                                                                | 62                                                                | -                                                                                                  | 8.5                                                                                                                                                    |
| 2013–2021   | 2.6                                                | 114                                                                | 21                                             | 0.3                                                | 49                                                                | 100                                                               | 100                                                                                                | 9.6                                                                                                                                                    |
| 2013–2021   | 2.0                                                | 38                                                                 | 0.6                                            | 0.4                                                | 46                                                                | -                                                                 | -                                                                                                  | -                                                                                                                                                      |
| 2013–2021   | 70.6                                               | 2159                                                               | 177                                           | 16.1                                               | 88                                                                | 5                                                                 | 188                                                                                              | -                                                                                                                                                      |
| 2013–2021   | 444                                               | 1871                                                               | 41                                            | 67                                                | 92                                                                | 25                                                                | 111                                                                                              | -                                                                                                                                                      |
| 2013–2021   | 119                                               | 142                                                                | 66                                            | 9.8                                               | 58                                                                | 25                                                                | -                                                                                                  | 74                                                                                                                                                    |
| 2013–2021   | 71                                                | 471                                                                | 15                                            | 63                                                | 74                                                                | -                                                                 | -                                                                                                  | -                                                                                                                                                      |
| 2013–2021   | 93                                                | 308                                                                | 26                                            | 62                                                | 87                                                                | 11                                                                | 39                                                                                                 | 132                                                                                                                                                   |
| 2013–2021   | 77                                                | 177                                                                | <1                                            | 21                                                | 68                                                                | 21                                                                | 66                                                                                                  | 6.6                                                                                                                                                    |
| 2013–2021   | 0.6                                                | 40                                                                 | <1                                            | 49                                                | -                                                                  | -                                                                 | -                                                                                                  | 54                                                                                                                                                    |
| 2013–2021   | 101                                               | 418                                                                | 14                                             | 0.8                                                | 70                                                                | -                                                                 | -                                                                                                  | 79                                                                                                                                                    |
| 2013–2021   | 341                                               | 373                                                                | 31                                             | 61                                                | 65                                                                | 26                                                                | 96                                                                                                  | -                                                                                                                                                      |
| 2013–2021   | 12.6                                               | 243                                                                | 3.0                                            | 2.2                                               | 74                                                                | 14                                                                | 31                                                                                                  | 10.8                                                                                                                                                   |
| 2013–2021   | 204                                               | 340                                                                | 41                                             | 42                                                | -                                                                  | 10.7                                                              | -                                                                                                  | -                                                                                                                                                      |
| 2013–2021   | 215                                               | 427                                                                | 11                                             | 16                                                | 81                                                                | 14                                                               | 31                                                                                                  | 8.7                                                                                                                                                    |
| 2013–2021   | 12.6                                               | 369                                                                | 0.9                                            | 18                                                | -                                                                  | 15.9                                                              | -                                                                                                  | -                                                                                                                                                      |
| 2014–2021   | 16.6                                               | 169                                                                | 0.1                                            | 0.4                                                | 65                                                                | 75                                                                | 88                                                                                                  | 31                                                                                                                                                    |
| 2014–2021   | 299                                               | 666                                                                | 60                                             | 0.3                                                | 69                                                                | 18                                                                | 50                                                                                                  | 8.2                                                                                                                                                    |
| 2014–2021   | 288                                               | 636                                                                | 74                                             | 120                                               | 96                                                                | 43                                                                | 54                                                                                                  | -                                                                                                                                                      |
| 2014–2021   | 317                                               | 917                                                                | 52                                             | 85                                                | 49                                                                | 10                                                               | 195                                                                                                 | -                                                                                                                                                      |
| 2014–2021   | 05                                                | 55                                                                 | 0.1                                            | 0.3                                                | 58                                                                | 50                                                                | 75                                                                                                  | 94                                                                                                                                                    |
| 2014–2021   | 36.5                                               | 1247                                                               | 6.0                                             | 10.6                                               | 91                                                                | -                                                                 | -                                                                                                  | 224                                                                                                                                                   |
| 2014–2021   | 620                                               | 1155                                                               | 170                                           | 54                                                | 70                                                                | -                                                                  | -                                                                                                   | 20.0                                                                                                                                                   |
| 2014–2021   | 237                                               | 1127                                                               | 15                                             | 0.4                                                | 77                                                                | -                                                                  | -                                                                                                   | 10.8                                                                                                                                                   |
| 2014–2021   | 16                                                | 14                                                                 | 0.3                                            | 54                                                | -                                                                  | -                                                                 | -                                                                                                   | 5.9                                                                                                                                                    |
| 2014–2021   | 166                                               | 20                                                                 | 0.1                                            | 1.3                                                | 77                                                                | -                                                                  | -                                                                                                   | 4.9                                                                                                                                                    |
| 2014–2021   | 8.3                                                | 14.5                                                               | 34                                             | -                                                 | 94                                                                | -                                                                  | -                                                                                                   | 9.4                                                                                                                                                    |
| 2014–2021   | 2.9                                                | 73                                                                 | 0.2                                            | 10                                                | 40                                                                | 71                                                                | 100                                                                                                | -                                                                                                                                                      |
| 2014–2021   | 3.0                                                | 18.6                                                               | 0.1                                            | 0.7                                                | 59                                                                | 100                                                               | 72                                                                                                  | -                                                                                                                                                      |
| 2014–2021   | 19                                                | 20.3                                                               | 0.1                                            | 10                                                | 67                                                                | -                                                                  | 52                                                                                                  | -                                                                                                                                                      |
| 2020        | -                                                  | -                                                                  | -                                              | -                                                 | -                                                                  | -                                                                 | -                                                                                                   | -                                                                                                                                                      |
| 2020        | 29                                                 | 129                                                                | 03                                             | 0.8                                               | 52                                                                | 73                                                                | -                                                                                                   | -                                                                                                                                                      |
| 2020        | 24.5                                               | 821                                                                | 59                                             | 51                                                | 67                                                                | -                                                                                                   | -                                                                                                   | 14.0                                                                                                                                                   |
| 2020        | 77                                                 | 204                                                                | 15                                             | 6.6                                               | 68                                                                | -                                                                                                   | -                                                                                                   | 8.2                                                                                                                                                    |
| 2020        | 366                                                | 834                                                                | 62                                             | 65                                                | 76                                                                | -                                                                                                   | -                                                                                                   | 12.6                                                                                                                                                   |
| 2020        | 112                                                | 165                                                                | 2.6                                            | 33                                                | 67                                                                | -                                                                                                   | -                                                                                                   | 9.2                                                                                                                                                    |
| 2020        | 209                                                | 400                                                                | 4.5                                            | 44                                                | 73                                                                | -                                                                                                   | -                                                                                                   | 10.3                                                                                                                                                   |
| 2014–2021   | 16.3                                               | 39.4                                                               | 3.3                                            | 4.7                                                | 66                                                                | 36                                                                | 47                                                                                                  | 10.7                                                                                                                                                   |

```json
{
  "tables": [
    {
      "Year": [
        "2013-2021", "2013-2021", "2013-2021", "2013-2021", "2013-2021",
        "2013-2021", "2013-2021", "2013-2021", "2013-2021", "2013-2021",
        "2013-2021", "2013-2021", "2013-2021", "2013-2021", "2013-2021",
        "2013-2021", "2013-2021", "2013-2021", "2013-2021", "2013-2021",
        "2014-2021", "2014-2021", "2014-2021", "2014-2021", "2014-2021",
        "2014-2021", "2014-2021", "2014-2021", "2014-2021", "2014-2021",
        "2014-2021", "2014-2021", "2020", "2020", "2020", "2020",
        "2020", "2020", "2020", "2020", "2020", "2020", "2020", "2020", "2020"
      ],
      "Density of medical doctors* (per 10,000 population)": [
        "922", "07", "243", "463", "328", "1.9", "2", "0.4", "458", "2.4",
        "2.6", "70.6", "444", "119", "71", "93", "77", "0.6", "101", "341",
        "12.6", "204", "215", "12.6", "16.6", "299", "288", "317", "05",
        "36.5", "620", "237", "16", "166", "8.3", "2.9", "3.0", "19", "2020", "29",
        "24.5", "77", "366", "112", "209", "16.3"
      ],
      "Density of nursing and midwifery personnel* (per 10,000 population)": [
        "4.0", "2.0", "618", "785", "1054", "214", "11", "36", "631", "24",
        "114", "2159", "1871", "142", "471", "308", "177", "40", "418", "373",
        "243", "340", "427", "369", "169", "666", "636", "917", "55", "1247",
        "1155", "1127", "14", "20", "14.5", "73", "18.6", "20.3", "2020", "0",
        "821", "204", "834", "165", "400", "39.4"
      ],
      "Density of dentists* (per 10,000 population)": [
        "12.0", "<1", "4.1", "71", "74", "0.7", "27", "<1", "84", "<1",
        "21", "177", "41", "66", "15", "26", "<1", "14", "31", "2.2", "41",
        "11", "0.9", "15", "0.1", "0.3", "74", "52", "85", "0.1", "6.0",
        "170", "15", "0.3", "0.1", "34", "0.2", "0.1", "1.0", "0.1", "0.0",
        "59", "62", "65", "2.6", "4.5", "3.3"
      ],
      "Density of pharmacists* (per 10,000 population)": [
        "52", "0.2", "50", "105", "80", "12", "73", "0.3", "132", "66",
        "0.4", "16.1", "67", "9.8", "63", "62", "21", "49", "0.8", "61",
        "2.2", "42", "16", "18", "65", "0.3", "120", "85", "10", "10.6",
        "54", "0.4", "54", "0.3", "73", "10", "62", "0.2", "57", "18.0",
        "114", "2.6", "73", "4.4", "4.3"
      ],
      "Average of 15 International Health Regulations core capacity scores*": [
        "-", "51", "94", "65", "74", "33", "27", "40", "82", "53",
        "49", "88", "67", "58", "71", "62", "68", "53", "70", "96",
        "74", "-", "16", "0", "0", "69", "67", "6.0", "58", "1.0",
        "54", "70", "0.7", "0.1", "66", "0.1", "70", "1.9", "7", "0.2",
        "1.0", "0.0", "84", "75", "0.4", "-"
      ],
      "Percentage of bloodstream infections due to methicillin-resistant Staphylococcus aureus (%)": [
        "-", "31", "12.8", "134", "101", "47", "20", "21", "50", "62",
        "100", "5", "25", "0", "1", "11", "21", "0", "0", "0",
        "14", "22", "28", "0", "1", "18", "26", "14", "49", "12.2",
        "51", "10.4", "0", "0", "100", "73", "-", "-", "-", "0.6",
        "31", "2", "20", "0", "1", "41", "20"
      ],
      "Percentage of bloodstream infections due to Escherichia coli resistant to 3rd-generation cephalosporins (%)": [
        "-", "68", "65", "50", "80", "101", "0", "7", "77", "6",
        "1", "5", "0", "3", "0", "0", "24", "32", "26", "3",
        "14", "19", "48", "0", "5", "2", "-", "", "", "", "-",
        "", "", "", "", "", "10", "", "", "", "",
        "", "", "", "38", "0", "", "", "", "5.9", "9",
        "82", "6.6", "0", "0"
      ],
      "Domestic general government health expenditure (GGHE-D) as percentage of general government expenditure (GGED)": [
        "10.2", "5.3", "13.3", "12.8", "-", "-", "10.8", "10.2", "8.5", "0",
        "0", "6.9", "31.7", "11", "1", "0", "2", "49.9", "-", "0",
        "40.1", "40", "4.4", "4.4", "9.6", "21.1", "18.6", "5.9", "10.1",
        "10.8", "5.9", "4.9", "29", "14.4", "", "0", "0", "0", "1"
      ]
    }
  ]
}
```
{
  "table": [
    {
      "Country": "Afghanistan",
      "2022": "33.1",
      "2013-2022": "51*",
      "2019": "37",
      "2020": "42.6",
      "2018": "35",
      "2016": "46",
      "2015": "28"
    },
    {
      "Country": "Albania",
      "2022": "13.4",
      "2013-2022": "16.3",
      "2019": "24.8",
      "2020": "6",
      "2018": "1",
      "2016": "4",
      "2015": "48"
    },
    {
      "Country": "Algeria",
      "2022": "8.6",
      "2013-2022": "27",
      "2019": "19",
      "2020": "33.3",
      "2018": "72",
      "2016": "18",
      "2015": "100"
    },
    {
      "Country": "Andorra",
      "2022": "4.36",
      "2013-2022": "4.9",
      "2019": "3.9",
      "2020": "44.5",
      "2018": "25",
      "2016": "38",
      "2015": "-"
    },
    {
      "Country": "Antigua and Barbuda",
      "2022": "6.9",
      "2013-2022": "17.2",
      "2019": "12.6",
      "2020": "11.5",
      "2018": "8",
      "2016": "9",
      "2015": "-"
    },
    {
      "Country": "Argentina",
      "2022": "9.5",
      "2013-2022": "1.7",
      "2019": "12.6",
      "2020": "11.9",
      "2018": "5",
      "2016": "27",
      "2015": "-"
    },
    {
      "Country": "Armenia",
      "2022": "7.2",
      "2013-2022": "4.4",
      "2019": "11.5",
      "2020": "17.5",
      "2018": "5",
      "2016": "87",
      "2015": "69"
    },
    {
      "Country": "Australia",
      "2022": "3.4",
      "2013-2022": "21.8",
      "2019": "8.5",
      "2020": "32",
      "2018": "23",
      "2016": "74",
      "2015": "-"
    },
    {
      "Country": "Austria",
      "2022": "5.4",
      "2013-2022": "21.8",
      "2019": "10.0",
      "2020": "4",
      "2018": "15",
      "2016": "99",
      "2015": "100"
    },
    {
      "Country": "Azerbaijan",
      "2022": "13.3",
      "2013-2022": "32.2",
      "2019": "101",
      "2020": "351",
      "2018": "5",
      "2016": "14",
      "2015": "88"
    },
    {
      "Country": "Bahamas",
      "2022": "5.4",
      "2013-2022": "15.5",
      "2019": "14.5",
      "2020": "99",
      "2018": "3",
      "2016": "91",
      "2015": "-"
    },
    {
      "Country": "Bahrain",
      "2022": "5.0",
      "2013-2022": "3.4",
      "2019": "36.4",
      "2020": "99",
      "2018": "9",
      "2016": "91",
      "2015": "-"
    },
    {
      "Country": "Bangladesh",
      "2022": "26.4",
      "2013-2022": "9.8",
      "2019": "21.367",
      "2020": "59",
      "2018": "39",
      "2016": "11",
      "2015": "-"
    },
    {
      "Country": "Barbados",
      "2022": "20.5",
      "2013-2022": "12.5",
      "2019": "71.0",
      "2020": "95",
      "2018": "12",
      "2016": "39",
      "2015": "-"
    },
    {
      "Country": "Belarus",
      "2022": "13.6",
      "2013-2022": "5.3",
      "2019": "20.6",
      "2020": "6",
      "2018": "21",
      "2016": "95",
      "2015": "74"
    },
    {
      "Country": "Belgium",
      "2022": "12.0",
      "2013-2022": "18",
      "2019": "59.2",
      "2020": "55.2",
      "2018": "5.2",
      "2016": "22",
      "2015": "100"
    },
    {
      "Country": "Belize",
      "2022": "12.0",
      "2013-2022": "18",
      "2019": "59.2",
      "2020": "55.2",
      "2018": "5.2",
      "2016": "12",
      "2015": "-"
    },
    {
      "Country": "Benin",
      "2022": "14.0",
      "2013-2022": "5.0",
      "2019": "22.5",
      "2020": "52.5",
      "2018": "8.1",
      "2016": "6",
      "2015": "11"
    },
    {
      "Country": "Bhutan",
      "2022": "22.7",
      "2013-2022": "6.5",
      "2019": "38.6",
      "2020": "9",
      "2018": "22",
      "2016": "37",
      "2015": "65"
    },
    {
      "Country": "Bolivia (Plurinational State of)",
      "2022": "11.0",
      "2013-2022": "2.0",
      "2019": "9.0",
      "2020": "24",
      "2018": "18",
      "2016": "34",
      "2015": "34"
    },
    {
      "Country": "Bosnia and Herzegovina",
      "2022": "9.4",
      "2013-2022": "9.4",
      "2019": "24.4",
      "2020": "12",
      "2018": "89",
      "2016": "0",
      "2015": "12"
    },
    {
      "Country": "Botswana",
      "2022": "21.6",
      "2013-2022": "10.1",
      "2019": "32.5",
      "2020": "17",
      "2018": "34",
      "2016": "86",
      "2015": "49"
    },
    {
      "Country": "Brazil",
      "2022": "9.5",
      "2013-2022": "12",
      "2019": "103",
      "2020": "161",
      "2018": "23",
      "2016": "86",
      "2015": "49"
    },
    {
      "Country": "Brunei Darussalam",
      "2022": "10.9",
      "2013-2022": "91",
      "2019": "167",
      "2020": "7",
      "2018": "12",
      "2016": "39",
      "2015": "-"
    },
    {
      "Country": "Bulgaria",
      "2022": "10.6",
      "2013-2022": "59",
      "2019": "236",
      "2020": "6",
      "2018": "19",
      "2016": "98",
      "2015": "72"
    },
    {
      "Country": "Burkina Faso",
      "2022": "21.6",
      "2013-2022": "10.6",
      "2019": "52.5",
      "2020": "11.5",
      "2018": "6",
      "2016": "22",
      "2015": "-"
    },
    {
      "Country": "Burundi",
      "2022": "56.5",
      "2013-2022": "4.9",
      "2019": "36.3",
      "2020": "22.4",
      "2018": "3",
      "2016": "36",
      "2015": "-"
    },
    {
      "Country": "Cabo Verde",
      "2022": "9.4",
      "2013-2022": "4.0",
      "2019": "24.3",
      "2020": "19",
      "2018": "22",
      "2016": "18",
      "2015": "-"
    },
    {
      "Country": "Cambodia",
      "2022": "23.9",
      "2013-2022": "9.6",
      "2019": "38.4",
      "2020": "9",
      "2018": "28",
      "2016": "22",
      "2015": "39"
    },
    {
      "Country": "Cameroon",
      "2022": "23.9",
      "2013-2022": "11.3",
      "2019": "10.5",
      "2020": "2.0",
      "2018": "39",
      "2016": "99",
      "2015": "84"
    },
    {
      "Country": "Canada",
      "2022": "39.8",
      "2013-2022": "54.6",
      "2019": "26.468",
      "2020": "21.29",
      "2018": "3",
      "2016": "9",
      "2015": "-"
    },
    {
      "Country": "Central African Republic",
      "2022": "32.3",
      "2013-2022": "83.7",
      "2019": "32",
      "2020": "45.4",
      "2018": "29",
      "2016": "6",
      "2015": "10"
    },
    {
      "Country": "Chad",
      "2022": "32.3",
      "2013-2022": "4.0",
      "2019": "38.8",
      "2020": "45.4",
      "2018": "29",
      "2016": "6",
      "2015": "10"
    },
    {
      "Country": "Chile",
      "2022": "16.1",
      "2013-2022": "0.3",
      "2019": "8.8",
      "2020": "87",
      "2018": "12",
      "2016": "99",
      "2015": "-"
    },
    {
      "Country": "China",
      "2022": "-",
      "2013-2022": "6",
      "2019": "8.9",
      "2020": "15.5",
      "2018": "19",
      "2016": "70",
      "2015": "-"
    },
    {
      "Country": "China, Hong Kong SAR",
      "2022": "-",
      "2013-2022": "-",
      "2019": "-",
      "2020": "-",
      "2018": "-",
      "2016": "-",
      "2015": "-"
    },
    {
      "Country": "China, Macao SAR",
      "2022": "-",
      "2013-2022": "-",
      "2019": "-",
      "2020": "-",
      "2018": "-",
      "2016": "-",
      "2015": "-"
    },
    {
      "Country": "Colombia",
      "2022": "11.2",
      "2013-2022": "16.1",
      "2019": "62",
      "2020": "21",
      "2018": "12",
      "2016": "30",
      "2015": "73"
    },
    {
      "Country": "Comoros",
      "2022": "18.8",
      "2013-2022": "17",
      "2019": "33.8",
      "2020": "16",
      "2018": "32",
      "2016": "4",
      "2015": "46"
    },
    {
      "Country": "Congo",
      "2022": "16.5",
      "2013-2022": "8.2",
      "2019": "4.5",
      "2020": "48",
      "2018": "14",
      "2016": "33",
      "2015": "-"
    },
    {
      "Country": "Cook Islands",
      "2022": "9.5",
      "2013-2022": "18",
      "2019": "76",
      "2020": "137",
      "2018": "7",
      "2016": "81",
      "2015": "30"
    },
    {
      "Country": "Costa Rica",
      "2022": "9.5",
      "2013-2022": "15.1",
      "2019": "76",
      "2020": "210",
      "2018": "4",
      "2016": "6",
      "2015": "68"
    },
    {
      "Country": "Côte d'Ivoire",
      "2022": "202.8",
      "2013-2022": "84.2",
      "2019": "509",
      "2020": "16",
      "2018": "27",
      "2016": "35",
      "2015": "-"
    },
    {
      "Country": "Cuba",
      "2022": "7.0",
      "2013-2022": "2.0",
      "2019": "102",
      "2020": "13",
      "2018": "5",
      "2016": "16",
      "2015": "100"
    },
    {
      "Country": "Cyprus",
      "2022": "7.0",
      "2013-2022": "2.0",
      "2019": "6.1",
      "2020": "11",
      "2018": "22",
      "2016": "11",
      "2015": "-"
    },
    {
      "Country": "Czechia",
      "2022": "16.8",
      "2013-2022": "2.5",
      "2019": "28",
      "2020": "33",
      "2018": "66",
      "2016": "-",
      "2015": "-"
    },
    {
      "Country": "Democratic People's Republic of Korea",
      "2022": "16.8",
      "2013-2022": "25.2",
      "2019": "28",
      "2020": "39",
      "2018": "74",
      "2016": "38",
      "2015": "35"
    },
    {
      "Country": "Democratic Republic of the Congo",
      "2022": "40.3",
      "2013-2022": "6.4",
      "2019": "37.4",
      "2020": "36",
      "2018": "47",
      "2016": "19",
      "2015": "13"
    },
    {
      "Country": "Denmark",
      "2022": "-",
      "2013-2022": "-",
      "2019": "122",
      "2020": "3",
      "2018": "23",
      "2016": "97",
      "2015": "92"
    }
  ]
}
```
[
  {
    "Proportion of population using a hand-washing facility with soap and water (%)": 38,
    "Comparable estimate 2020": 74.65,
    "Comparable estimate 2021": 35,
    "Primary data 2019": 75.2,
    "Primary data 2022": 8.5,
    "Primary data 2020": 402.31,
    "Comparable estimate 2016": 51.5
  },
  {
    "Proportion of safely treated domestic wastewater flows (%)": 85,
    "Comparable estimate 2020": 121,
    "Comparable estimate 2021": 100,
    "Primary data 2019": 22.9,
    "Primary data 2022": 17,
    "Primary data 2020": 362.75,
    "Comparable estimate 2016": 274.0
  },
  {
    "Amount of water and sanitation-related official development assistance that is part of a government-coordinated spending plan (constant 2020 (US$ millions))": 27,
    "Comparable estimate 2020": 111.9,
    "Comparable estimate 2021": 50,
    "Primary data 2019": 323.9,
    "Primary data 2022": 0,
    "Primary data 2020": 387.92,
    "Comparable estimate 2016": 128.2
  },
  {
    "Proportion of population with primary reliance on clean fuels and technology (%)": -,
    "Comparable estimate 2020": 36,
    "Comparable estimate 2021": 100,
    "Primary data 2019": 8.4,
    "Primary data 2022": 24,
    "Primary data 2020": 426.15,
    "Comparable estimate 2016": 118.9
  },
  {
    "Annual mean concentrations of fine particulate matter (PM2.5) in urban areas (µg/m³)": 95,
    "Comparable estimate 2020": 212.9,
    "Comparable estimate 2021": 98,
    "Primary data 2019": 362.1,
    "Primary data 2022": 38.0,
    "Primary data 2020": 473.48,
    "Comparable estimate 2016": 202.0
  },
  {
    "Mortality rate due to homicide* (per 100 000 population)": -,
    "Comparable estimate 2020": 100,
    "Comparable estimate 2021": 91,
    "Primary data 2019": 1.0,
    "Primary data 2022": 43.0,
    "Primary data 2020": 201.38,
    "Comparable estimate 2016": 201.0
  },
  {
    "Number of cases of poliomyelitis caused by wild poliovirus (WPV)": -,
    "Comparable estimate 2020": 64.3,
    "Comparable estimate 2021": 100,
    "Primary data 2019": 262.5,
    "Primary data 2022": 0,
    "Primary data 2020": 410.49,
    "Comparable estimate 2016": 199.0
  },
  {
    "Percentage of total antibiotic consumption being from the AWaRe “Access” antibiotics category (%)": 58,
    "Comparable estimate 2020": 100,
    "Comparable estimate 2021": 27,
    "Primary data 2019": 468.28,
    "Primary data 2022": 0,
    "Primary data 2020": 288.27,
    "Comparable estimate 2016": 26.3
  },
  {
    "Age-standardized prevalence of obesity among children and adolescents (5-19 years) (%)": 90,
    "Comparable estimate 2020": 118,
    "Comparable estimate 2021": 0,
    "Primary data 2019": 98.5,
    "Primary data 2022": 0,
    "Primary data 2020": 65.30,
    "Comparable estimate 2016": 241.0
  },
  {
    "Age-standardized prevalence of obesity among adults (18+ years) (%)": 90,
    "Comparable estimate 2020": 0.07,
    "Comparable estimate 2021": 83.10,
    "Primary data 2019": 373,
    "Primary data 2022": 0,
    "Primary data 2020": 380.12,
    "Comparable estimate 2016": 241.0
  }
]
```
The world's population experienced increased survival in recent times, with global life expectancy increasing since the 1950s up until 2019. This trend reflected the epidemiological transition from an era characterized by high mortality in childhood and a high burden associated with infectious diseases and maternal, perinatal, and nutritional conditions, to an era with a high burden from noncommunicable diseases (NCDs). This chapter looks at the most recent trends in maternal and child mortality, as well as NCDs and the major risk factors. It also discusses the striking changes in the global mortality pattern brought about by the COVID-19 pandemic. Lastly, it presents a section on climate change and how it relates to population health.

## 1.1 Trends in maternal and child mortality

Improvement of maternal and child health has been high on the global development agenda since the turn of the millennium. Reductions in both maternal and child mortality were among the targets of the Millennium Development Goals (MDGs), declared in 2000, that the world strived to achieve by 2015. They continue to be among the global targets in the SDG era that spans from 2015 to 2030.

### Maternal mortality

Pregnancy, childbirth, and the postnatal period should bring positive experiences, ensuring that women and their babies reach their full potential for health and well-being. Unfortunately, these stages of life still carry considerable risks to women and their families, as women in many parts of the world lose their lives due to related complications and inadequate health care. The SDG target calls for a reduction of the global maternal mortality ratio to less than 70 maternal deaths per 100,000 live births by 2030.

### Levels and trends in maternal mortality

Much progress was achieved in the MDG era, as the global maternal mortality ratio dropped by a third between 2000 and 2015, from 339 (UI: 319–360) deaths per 100,000 live births to 227 (UI: 211–246) deaths per 100,000 live births, representing a 2.7% (UI: 2.0–3.2%) average annual rate of reduction (ARR). The number of maternal deaths globally fell by 30% during the period, from an estimated 447,000 (UI: 426,000–481,000) deaths in 2000 to 313,000 (UI: 300,000–350,000) deaths in 2015.
```
{
  "table": [
    {
      "Country": "Djibouti",
      "2022": 187,
      "2013-2022": 106,
      "2019": 32,
      "2020": 323
    },
    {
      "Country": "Dominica",
      "2022": null,
      "2013-2022": null,
      "2019": 208,
      "2020": null
    },
    {
      "Country": "Dominican Republic",
      "2022": 5.6,
      "2013-2022": 22,
      "2019": 76.264,
      "2020": 10
    },
    {
      "Country": "Ecuador",
      "2022": 227,
      "2013-2022": 37,
      "2019": 119,
      "2020": 172
    },
    {
      "Country": "Egypt",
      "2022": 20.4,
      "2013-2022": 95,
      "2019": 188,
      "2020": 15
    },
    {
      "Country": "El Salvador",
      "2022": 10.0,
      "2013-2022": 21,
      "2019": 68,
      "2020": 6
    },
    {
      "Country": "Equatorial Guinea",
      "2022": 161,
      "2013-2022": 82,
      "2019": 64.5,
      "2020": 29
    },
    {
      "Country": "Eritrea",
      "2022": 502,
      "2013-2022": 3.0,
      "2019": 370,
      "2020": null
    },
    {
      "Country": "Estonia",
      "2022": 1.5,
      "2013-2022": 1.5,
      "2019": 51,
      "2020": 96
    },
    {
      "Country": "Eswatini",
      "2022": 212,
      "2013-2022": 20,
      "2019": 79,
      "2020": 307
    },
    {
      "Country": "Ethiopia",
      "2022": 344,
      "2013-2022": 64,
      "2019": 68,
      "2020": 27
    },
    {
      "Country": "Fiji",
      "2022": 71.6,
      "2013-2022": 4.6,
      "2019": 74,
      "2020": 32
    },
    {
      "Country": "Finland",
      "2022": 10.9,
      "2013-2022": 20.5,
      "2019": 23.0,
      "2020": 100
    },
    {
      "Country": "France",
      "2022": 13.4,
      "2013-2022": 34,
      "2019": 54,
      "2020": 22
    },
    {
      "Country": "Gabon",
      "2022": 13.6,
      "2013-2022": 31,
      "2019": 54,
      "2020": 25
    },
    {
      "Country": "Gambia",
      "2022": 13.6,
      "2013-2022": 51,
      "2019": 45,
      "2020": 29
    },
    {
      "Country": "Georgia",
      "2022": 4.3,
      "2013-2022": 0.6,
      "2019": 50,
      "2020": 275
    },
    {
      "Country": "Germany",
      "2022": 21,
      "2013-2022": 4.1,
      "2019": 31,
      "2020": 100
    },
    {
      "Country": "Ghana",
      "2022": 27,
      "2013-2022": 6.8,
      "2019": 354,
      "2020": 24
    },
    {
      "Country": "Greece",
      "2022": 22,
      "2013-2022": 6.8,
      "2019": 151,
      "2020": 5
    },
    {
      "Country": "Grenada",
      "2022": 8.1,
      "2013-2022": 8,
      "2019": 192,
      "2020": 8
    },
    {
      "Country": "Guatemala",
      "2022": 43.5,
      "2013-2022": 0.8,
      "2019": 4.8,
      "2020": 74
    },
    {
      "Country": "Guinea",
      "2022": 279,
      "2013-2022": 9.2,
      "2019": 56.480,
      "2020": 21
    },
    {
      "Country": "Guinea-Bissau",
      "2022": 277,
      "2013-2022": 51,
      "2019": 33,
      "2020": 481
    },
    {
      "Country": "Guyana",
      "2022": 76,
      "2013-2022": 6.5,
      "2019": 37,
      "2020": 317
    },
    {
      "Country": "Haiti",
      "2022": 19.5,
      "2013-2022": 17,
      "2019": 47,
      "2020": 23
    },
    {
      "Country": "Honduras",
      "2022": 17.5,
      "2013-2022": 19,
      "2019": 47,
      "2020": 6
    },
    {
      "Country": "Hungary",
      "2022": null,
      "2013-2022": null,
      "2019": 10.5,
      "2020": 93
    },
    {
      "Country": "Iceland",
      "2022": 10.3,
      "2013-2022": 3,
      "2019": 21,
      "2020": 100
    },
    {
      "Country": "India",
      "2022": 317,
      "2013-2022": 187,
      "2019": 2.8,
      "2020": 53.0
    },
    {
      "Country": "Indonesia",
      "2022": 310,
      "2013-2022": 10.2,
      "2019": 106,
      "2020": 312
    },
    {
      "Country": "Iran (Islamic Republic of)",
      "2022": 4.7,
      "2013-2022": 4.3,
      "2019": 38,
      "2020": 241
    },
    {
      "Country": "Iraq",
      "2022": 9.9,
      "2013-2022": 3.0,
      "2019": 6.4,
      "2020": 26
    },
    {
      "Country": "Ireland",
      "2022": null,
      "2013-2022": null,
      "2019": 121,
      "2020": 16
    },
    {
      "Country": "Israel",
      "2022": null,
      "2013-2022": null,
      "2019": 12,
      "2020": 6
    },
    {
      "Country": "Italy",
      "2022": 6.5,
      "2013-2022": 3.7,
      "2019": 16,
      "2020": 24
    },
    {
      "Country": "Jamaica",
      "2022": 6.5,
      "2013-2022": 32,
      "2019": 57,
      "2020": 24
    },
    {
      "Country": "Japan",
      "2022": null,
      "2013-2022": 21,
      "2019": 4,
      "2020": 90
    },
    {
      "Country": "Jordan",
      "2022": 6.6,
      "2013-2022": 0.6,
      "2019": 95,
      "2020": 377
    },
    {
      "Country": "Kazakhstan",
      "2022": 14.9,
      "2013-2022": 31,
      "2019": 77,
      "2020": 287
    },
    {
      "Country": "Kenya",
      "2022": 18.4,
      "2013-2022": 49,
      "2019": 38,
      "2020": 287
    },
    {
      "Country": "Kiribati",
      "2022": null,
      "2013-2022": null,
      "2019": 3.5,
      "2020": 20
    },
    {
      "Country": "Kuwait",
      "2022": 6.9,
      "2013-2022": 23.7,
      "2019": 117,
      "2020": 237
    },
    {
      "Country": "Kyrgyzstan",
      "2022": 103,
      "2013-2022": 20,
      "2019": 64,
      "2020": 258
    },
    {
      "Country": "Lao People's Democratic Republic",
      "2022": 277,
      "2013-2022": 9.0,
      "2019": 395,
      "2020": 18
    },
    {
      "Country": "Latvia",
      "2022": null,
      "2013-2022": null,
      "2019": 16,
      "2020": 25
    },
    {
      "Country": "Lebanon",
      "2022": 13.6,
      "2013-2022": 14.8,
      "2019": 283,
      "2020": 48
    },
    {
      "Country": "Lesotho",
      "2022": 318,
      "2013-2022": 21,
      "2019": 279,
      "2020": 16
    },
    {
      "Country": "Liberia",
      "2022": 26,
      "2013-2022": 5.3,
      "2019": 426,
      "2020": 27
    },
    {
      "Country": "Libya",
      "2022": 522,
      "2013-2022": 102,
      "2019": 287,
      "2020": 29
    },
    {
      "Country": "Lithuania",
      "2022": null,
      "2013-2022": 4.5,
      "2019": 7.9,
      "2020": 5
    },
    {
      "Country": "Luxembourg",
      "2022": null,
      "2013-2022": null,
      "2019": 4,
      "2020": 22
    },
    {
      "Country": "Madagascar",
      "2022": 386,
      "2013-2022": 72,
      "2019": 15,
      "2020": 378
    },
    {
      "Country": "Malawi",
      "2022": 34.0,
      "2013-2022": 2.6,
      "2019": 3.9,
      "2020": 314
    }
  ]
}
```
{
  "table": [
    {
      "Proportion of population using a hand-washing facility with soap and water (%)": {
        "Comparable estimates": {
          "2020": 11.14,
          "2022": 14.42,
          "2021": 10.67
        }, 
        "Primary data": {
          "2019": 27,
          "2022": 6.6
        }
      },
      "Proportion of safely treated domestic wastewater flows (%)": {
        "Comparable estimates": {
          "2020": 0.94,
          "2022": 89,
          "2021": 84
        }
      },
      "Amount of water-related official development assistance is part of a government-coordinated spending plan (constant 2020 US$ millions)": {
        "Comparable estimates": {
          "2020": 47.4,
          "2022": 650.92,
          "2021": 78.17
        }
      },
      "Proportion of population with primary reliance on clean fuels and technology (%)": {
        "Comparable estimates": {
          "2020": 87,
          "2022": 56.29,
          "2021": 95
        }
      },
      "Annual mean concentrations of fine particulate matter (PM2.5) in urban areas (μg/m³)": {
        "Comparable estimates": {
          "2020": 90.74,
          "2022": 246.71,
          "2021": 64.1
        }
      },
      "Mortality rate due to homicide* (per 100,000 population)": {
        "Comparable estimates": {
          "2020": 28.83,
          "2022": 93,
          "2021": 22.88
        }
      },
      "Number of cases of poliomyelitis caused by wild poliovirus (WPV*)": {
        "Comparable estimates": {
          "2020": 24,
          "2022": 271,
          "2021": 24
        }
      },
      "Percentage of total antibiotic consumption being from the AWaRe 'Access' antibiotics category (%)": {
        "Comparable estimates": {
          "2020": 24,
          "2022": 100,
          "2021": 62
        }
      },
      "Age-standardized prevalence of hypertension among adults aged 30-79 years (%)": {
        "Comparable estimates": {
          "2020": 42.5,
          "2022": 49.2,
          "2021": 31
        }
      },
      "Prevalence of obesity among children (5-19 years) (%)": {
        "Comparable estimates": {
          "2020": 90.9,
          "2022": 100,
          "2021": 100
        }
      },
      "Age-standardized prevalence of obesity among adults (18+ years) (%)": {
        "Comparable estimates": {
          "2020": 31.3,
          "2022": 29.9,
          "2021": 29.3
        }
      }
    }
  ]
}
```
| Country and area                                  | Prevalence of stunting in children under 5 (%) | Prevalence of wasting in children under 5 (%) | Prevalence of overweight in children under 5 (%) | Prevalence of anaemia in women of reproductive age (15–49 years) (%) | Proportion of ever-partnered women and girls aged 15–49 years subjected to physical and/or sexual violence by a current or former intimate partner in the previous 12 months (%) | Proportion of ever-partnered women and girls aged 15–49 years subjected to physical and/or sexual violence by a current or former intimate partner in their lifetime (%) | Proportion of population using safely-managed drinking-water services (%) | Proportion of population using safely-managed sanitation services (%) |
|---------------------------------------------------|-----------------------------------------------|---------------------------------------------|--------------------------------------------------|-------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------|--------------------------------------------------------------------|
| Malaysia                                          | 21.9                                          | 9.1                                        | 37.0                                             | 19                                                                | 94                                                                                                                    | -                                                                                                                        | 100                                                                 | -                                                                  |
| Maldives                                          | 13.9                                          | 91.9                                       | 33.5                                             | 52.2                                                              | 6                                                                                                                     | 19                                                                                                                     | -                                                                   | -                                                                  |
| Mali                                              | 23.8                                          | 10.6                                       | 2.0                                              | 590                                                               | 18                                                                                                                    | 29                                                                                                                     | -                                                                   | 20                                                                 |
| Malta                                             | 13.7                                          | -                                          | 4.0                                              | 100                                                               | 92                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| Marshall Islands                                  | 30.5                                          | 3.5                                        | 4.4                                              | 306                                                               | 19                                                                                                                    | -                                                                                                                        | 38                                                                  | -                                                                  |
| Mauritania                                        | 22.1                                          | 13.6                                       | 2.0                                              | 433                                                               | -                                                                                                                     | -                                                                                                                        | -                                                                   | -                                                                  |
| Mauritius                                         | 86.6                                          | 6.8                                        | 23.0                                             | -                                                                 | -                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| Mexico                                            | 12.6                                          | 1.7                                        | 6.9                                              | 153                                                               | 10                                                                                                                    | 24                                                                                                                     | 43                                                                  | 57                                                                 |
| Micronesia (Federated States of)                 | -                                             | -                                          | -                                                | -                                                                 | -                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| Monaco                                            | -                                             | -                                          | -                                                | -                                                                 | -                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| Mongolia                                          | 61.0                                          | 10.7                                       | 14.5                                             | 100                                                               | -                                                                                                                    | -                                                                                                                        | 30                                                                  | 100                                                                |
| Montenegro                                        | 8.2                                           | 22.8                                       | 80.0                                             | 17.2                                                              | 4                                                                                                                     | 16                                                                                                                     | 85                                                                  | 45                                                                 |
| Morocco                                           | 18.2                                          | 4.9                                        | 29.9                                             | 10                                                                | -                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| Mozambique                                        | 36.4                                          | 39.5                                       | 5.5                                              | 479                                                               | 16                                                                                                                    | 30                                                                                                                     | -                                                                   | -                                                                  |
| Myanmar                                           | 24.7                                          | 0.8                                        | 42.1                                             | 16                                                                | 59                                                                                                                    | 61                                                                                                                     | -                                                                   | -                                                                  |
| Namibia                                           | 16.8                                          | 71.1                                       | 53.2                                             | 16                                                                | -                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| Nauru                                             | 14.8                                          | 4.5                                        | 296.0                                            | 2                                                                 | -                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| Nepal                                             | 26.7                                          | 77.7                                       | 357.0                                            | 5                                                                 | -                                                                                                                    | 27                                                                                                                     | 18                                                                  | 49                                                                 |
| Netherlands (Kingdom of the)                     | 16.1                                          | 51.2                                       | 5.1                                              | 100                                                               | 97                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| New Zealand                                       | 14.0                                          | 23.6                                       | 10.4                                             | 7                                                                 | 100                                                                                                                   | -                                                                                                                        | -                                                                   | -                                                                  |
| Nicaragua                                         | 14.9                                          | 8.7                                        | 157.6                                           | 6                                                                 | 23                                                                                                                    | 56                                                                                                                     | -                                                                   | -                                                                  |
| Niger                                             | 47.4                                          | 10.9                                       | 27.4                                             | 15                                                                | 16                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| Nigeria                                           | 34.2                                          | 6.5                                        | 22.5                                             | 51.3                                                              | 24                                                                                                                    | 22                                                                                                                     | 31                                                                  | -                                                                  |
| Niue                                             | -                                             | -                                          | -                                                | -                                                                 | -                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| North Macedonia                                    | 37.7                                          | 34.4                                       | 99.9                                             | 13                                                                | 77                                                                                                                    | 12                                                                                                                     | -                                                                   | -                                                                  |
| Norway                                           | -                                             | -                                          | 12.0                                             | 4                                                                 | 20                                                                                                                    | 99                                                                                                                    | 65                                                                  | -                                                                  |
| Oman                                             | 12.7                                          | 93.4                                       | 6.5                                              | 291                                                               | 91                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| Pakistan                                          | 34.0                                          | 7.1                                        | 27.4                                             | 16                                                                | 29                                                                                                                    | 36                                                                                                                     | -                                                                   | -                                                                  |
| Palau                                             | 2.3                                           | -                                          | 285.0                                            | 14                                                                | 31                                                                                                                    | 91                                                                                                                     | -                                                                   | -                                                                  |
| Panama                                            | 13.8                                          | 11.8                                       | 114.0                                             | 212                                                               | 8                                                                                                                     | -                                                                                                                       | -                                                                   | -                                                                  |
| Papua New Guinea                                  | 51.2                                          | 16.0                                       | 34.4                                             | 31                                                                | 51                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| Paraguay                                          | 17.4                                          | 10.4                                       | 14.6                                             | 230                                                               | 6                                                                                                                     | 64                                                                                                                     | 60                                                                  | -                                                                  |
| Peru                                              | 10.1                                          | 20.1                                       | 94.0                                             | 206                                                               | 11                                                                                                                    | 38                                                                                                                     | 51                                                                  | 73                                                                 |
| Philippines                                       | 28.8                                          | 6.8                                        | 4.2                                              | 13.6                                                              | 1                                                                                                                     | 47                                                                                                                     | -                                                                   | -                                                                  |
| Poland                                            | 23.0                                          | -                                          | 6.0                                              | 3                                                                 | 13                                                                                                                    | 98                                                                                                                    | -                                                                   | -                                                                  |
| Portugal                                          | 31.1                                          | 8.9                                        | 13.2                                             | 4                                                                 | 18                                                                                                                    | 95                                                                                                                    | 85                                                                  | -                                                                  |
| Puerto Rico                                       | 4.4                                           | -                                          | 188.0                                            | -                                                                 | -                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| Qatar                                             | 4.4                                           | -                                          | 17.7                                             | 281                                                               | 96                                                                                                                    | 97                                                                                                                     | -                                                                   | -                                                                  |
| Republic of Korea                                  | 17.0                                          | 0.2                                        | 54.0                                             | 135                                                               | 8                                                                                                                     | 99                                                                                                                    | -                                                                   | -                                                                  |
| Republic of Moldova                               | 39.9                                          | 2.9                                        | 261.9                                            | 27                                                                | 74                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| Romania                                           | 77.0                                          | 4.5                                        | 227.7                                            | 7                                                                 | 18                                                                                                                    | 82                                                                                                                     | 83                                                                  | -                                                                  |
| Russian Federation                                | -                                             | -                                          | -                                                | -                                                                 | -                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| Rwanda                                            | 298.1                                         | 11.1                                       | 4.7                                              | 172                                                               | 23                                                                                                                    | 38                                                                                                                     | 12                                                                  | -                                                                  |
| Saint Kitts and Nevis                            | 2.5                                           | -                                          | 6.0                                              | 14.3                                                              | -                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| Saint Vincent and the Grenadines                 | -                                             | -                                          | 17.0                                             | -                                                                 | -                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| Samoa                                             | 74.3                                          | 31.7                                       | 79.2                                             | 26.8                                                              | 18                                                                                                                    | 40                                                                                                                     | 46                                                                  | 48                                                                 |
| San Marino                                        | -                                             | -                                          | -                                                | 12.5                                                              | -                                                                                                                    | -                                                                                                                        | -                                                                   | -                                                                  |
| Sao Tome and Principe                            | 10.0                                          | 4.4                                        | 4.7                                              | 44.2                                                              | 18                                                                                                                    | 27                                                                                                                     | 36                                                                  | 35                                                                 |
| Saudi Arabia                                      | 12.4                                          | 4.4                                        | 101.0                                            | 272                                                               | 12                                                                                                                    | 24                                                                                                                     | -                                                                   | -                                                                  |
| Senegal                                           | 17.0                                          | 81.0                                       | 34.9                                             | 527                                                               | 12                                                                                                                    | 24                                                                                                                     | -                                                                   | -                                                                  |

```json
{
  "data": [
    {
      "Proportion of population using a hand-washing facility with soap and water (%)": {
        "Comparable estimates": {"2020": 89, "2022": 60, "2021": 94, "2019": 237, "2018": 27},
        "Primary data": {"2022": 40.8, "2020": 127, "2016": 156}
      },
      "Proportion of safely treated domestic wastewater flows (%)": {
        "Comparable estimates": {"2020": 96, "2022": 34.3, "2021": 100, "2019": 19, "2018": 44.1},
        "Primary data": {"2022": 34.1, "2016": 8.6}
      },
      "Amount of wastewater treated as official development assistance that is part of a government-allocated spending plan (constant 2020 US$ millions)": {
        "Comparable estimates": {"2020": 17, "2022": 927.5, "2021": 1, "2019": 1, "2018": 0},
        "Primary data": {"2022": null, "2016": null}
      },
      "Proportion of population with primary reliance on clean fuels and technology (%)": {
        "Comparable estimates": {"2020": 85, "2022": 1, "2021": 100, "2019": 29, "2018": 10},
        "Primary data": {"2022": null, "2016": null}
      },
      "Annual mean concentrations of fine particulate matter (PM<sub>2.5</sub>) in urban areas (µg/m³)": {
        "Comparable estimates": {"2020": 253.45, "2022": 48, "2021": 51.3, "2019": 10.9, "2018": 0},
        "Primary data": {"2022": null, "2016": null}
      },
      "Mortality rate due to homicide (per 100,000 population)": {
        "Comparable estimates": {"2020": 2.22, "2022": 0.8, "2021": 85, "2019": 18.4, "2018": 254},
        "Primary data": {"2022": null, "2016": null}
      },
      "Number of cases of poliomyelitis caused by wild poliovirus (WPV)": {
        "Comparable estimates": {"2020": 86, "2022": 26, "2021": 28.6, "2019": 53, "2018": 6.1},
        "Primary data": {"2022": 80, "2016": 2.06}
      },
      "Percentage of total antibiotic consumption being from the AWaRe 'Access' antibiotic category (%)": {
        "Comparable estimates": {"2020": 99, "2022": 75, "2021": 92, "2019": 17.8, "2018": 20},
        "Primary data": {"2022": 80, "2016": null}
      },
      "Age-standardized prevalence of hypertension among adults aged 30–79 years (%)": {
        "Comparable estimates": {"2020": 75, "2022": 99, "2021": 100, "2019": 10.9, "2018": 0.6},
        "Primary data": {"2022": null, "2016": null}
      },
      "Prevalence of obesity among children (%)": {
      ...
      },
      ...
    }
  ]
}
```

Note: The data is truncated for brevity. To convert the entire table, each category should be expanded similarly, following the same structure. If there are images or additional text in the PDF, please provide those details for analysis.
| Countries and areas                         | Prevalence of stunting in children under 5 (%) | Prevalence of wasting in children under 5 (%) | Prevalence of overweight in children under 5 (%) | Prevalence of anaemia in women of reproductive age (15-49 years) (%) | Proportion of ever-partnered women and girls aged 15-49 years subjected to physical and/or sexual violence by a current or former intimate partner in the previous 12 months (%) | Proportion of ever-partnered women and girls aged 15-49 years subjected to physical and/or sexual violence by a current or former intimate partner in their lifetime (%) | Proportion of population using safely-managed drinking-water services (%) | Proportion of population using safely-managed sanitation services (%) |
|---------------------------------------------|-------------------------------------|-----------------------------------|-----------------------------------|-------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------|
| Serbia                                      | 4                                    | 26                                | 99                                | 22.8                                            | 4                                                                                                                                | 17                                                                                                                                         | 75                                                                                                                                  | 18                                                                                                                                         |
| Seychelles                                  | 7                                    | 12                                | 91                                | 25.1                                            | -                                                                                                                                | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| Sierra Leone                                | 260                                  | 6.3                               | 52                                | 48.4                                            | 20                                                                                                                               | 36                                                                                                                                         | 11                                                                                                                                  | 14                                                                                                                                         |
| Singapore                                   | 3.0                                  | 3.8                               | 13                                | 20                                             | 2                                                                                                                                  | 11                                                                                                                                         | 100                                                                                                                                 | 100                                                                                                                                        |
| Slovakia                                     | 1                                    | 1                                 | 235                               | 6                                               | 18                                                                                                                               | 99                                                                                                                                         | 82                                                                                                                                  | -                                                                                                                                          |
| Slovenia                                    | 29.8                                 | 8.5                               | 55                                | 37                                             | 28                                                                                                                               | 98                                                                                                                                         | 72                                                                                                                                  | -                                                                                                                                          |
| Solomon Islands                             | 29.8                                 | 8.5                               | 55                                | 37                                             | 28                                                                                                                               | 50                                                                                                                                         | -                                                                                                                                   | 32                                                                                                                                         |
| Somalia                                     | 18.0                                 | 27                                | 431                               | -                                              | -                                                                                                                                | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| South Africa                                | 22.8                                 | 38.7                              | 12.1                              | 30.5                                           | 24                                                                                                                               | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| South Sudan                                 | 279                                  | 4.7                               | 36.5                              | 27.4                                           | 41                                                                                                                               | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| Spain                                       | -                                    | -                                 | -                                  | -                                              | -                                                                                                                                | -                                                                                                                                          | 100                                                                                                                                 | 96                                                                                                                                         |
| Sri Lanka                                   | 15.9                                 | 15.1                              | 34.6                              | 4                                              | 24                                                                                                                               | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| Sudan                                       | 360                                  | 16.3                              | 27.3                              | 17                                             | -                                                                                                                                | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| Suriname                                    | -                                    | 5.5                               | 3.8                               | 21                                             | 56                                                                                                                               | 25                                                                                                                                         | -                                                                                                                                   | -                                                                                                                                          |
| Sweden                                      | -                                    | -                                 | 113                               | 6                                               | 21                                                                                                                               | 100                                                                                                                                         | -                                                                                                                                   | -                                                                                                                                          |
| Switzerland                                 | 76                                   | 13                                | -                                  | -                                              | 12                                                                                                                               | 94                                                                                                                                         | -                                                                                                                                   | -                                                                                                                                          |
| Syrian Arab Republic                        | 254                                  | 117                               | -                                  | -                                              | -                                                                                                                                | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| Tajikistan                                  | 131                                  | 56                                | 30.5                               | 14                                             | 24                                                                                                                               | 55                                                                                                                                         | -                                                                                                                                   | -                                                                                                                                          |
| Thailand                                     | 118                                | 17.8                              | 26.4                              | 20                                             | 24                                                                                                                               | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| Timor-Leste                                | 45.1                                 | 83.8                              | 29.9                              | 28                                             | 30                                                                                                                               | 34                                                                                                                                         | -                                                                                                                                   | -                                                                                                                                          |
| Togo                                         | 223                                  | 5.7                               | 22.4                              | 20                                             | 23                                                                                                                               | 20                                                                                                                                         | -                                                                                                                                   | -                                                                                                                                          |
| Tonga                                       | 1.8                                  | 11                                | 109                               | 28.5                                           | 17                                                                                                                               | 37                                                                                                                                         | 30                                                                                                                                  | 34                                                                                                                                         |
| Trinidad and Tobago                        | 8.8                                  | 13.9                              | 177                               | 28                                             | 12                                                                                                                               | 28                                                                                                                                         | -                                                                                                                                   | -                                                                                                                                          |
| Tunisia                                     | 86.2                                 | 21                                | 19.0                              | 321                                            | 10                                                                                                                               | 25                                                                                                                                         | 79                                                                                                                                  | 81                                                                                                                                         |
| Turkey                                     | 55.5                                 | 17.1                              | 8.1                                | 12                                             | 12                                                                                                                               | 32                                                                                                                                         | 78                                                                                                                                  | -                                                                                                                                          |
| Turkmenistan                               | 67.4                                 | 36                                | 26.6                              | 95                                             | -                                                                                                                                | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| Tuvalu                                      | 52.2                                 | 28.4                              | 275                               | 20                                             | 39                                                                                                                               | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| Uganda                                       | 234                                  | 36.3                              | 32.8                              | 45                                             | 17                                                                                                                               | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| Ukraine                                       | 12.3                                 | 136                               | 177                               | 9                                              | 18                                                                                                                               | 89                                                                                                                                         | 72                                                                                                                                  | -                                                                                                                                          |
| United Arab Emirates                       | 13.2                                 | -                                 | 243                               | -                                              | -                                                                                                                                | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| United Kingdom                              | 13                                  | 11.3                              | 111                               | 4                                              | 24                                                                                                                               | 100                                                                                                                                         | -                                                                                                                                   | -                                                                                                                                          |
| United Republic of Tanzania                | 306                                  | 33.4                              | 46.8                              | 24.3                                           | 26                                                                                                                               | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| United States of America                   | 36.0                                 | 31.0                              | 178                               | 18                                             | 26                                                                                                                               | 97                                                                                                                                         | -                                                                                                                                   | -                                                                                                                                          |
| Uruguay                                     | 6.1                                  | 14.1                              | 15.0                              | 4                                              | 18                                                                                                                               | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| Uzbekistan                                  | 69                                    | 24.2                              | 24.8                              | 59                                             | -                                                                                                                                | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| Vanuatu                                     | 31.4                                 | 47.4                              | 51                                | 28.5                                           | 29                                                                                                                               | 47                                                                                                                                         | -                                                                                                                                   | -                                                                                                                                          |
| Venezuela (Bolivarian Republic of)       | 10.5                                 | 69                                | 24.2                              | 8                                              | 19                                                                                                                               | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| Viet Nam                                    | 19.3                                 | 4.7                               | 81.6                              | 20.6                                           | 10                                                                                                                               | 25                                                                                                                                         | -                                                                                                                                   | -                                                                                                                                          |
| Yemen                                       | 351                                  | 164.7                             | 615                               | -                                              | 19                                                                                                                               | -                                                                                                                                          | -                                                                                                                                   | -                                                                                                                                          |
| Zambia                                      | 314                                  | 42.4                              | 54                                | 31.5                                           | 28                                                                                                                               | 41                                                                                                                                         | -                                                                                                                                   | -                                                                                                                                          |
| Zimbabwe                                    | 216.0                                 | 29                                | 27.2                              | 28.5                                           | 35                                                                                                                               | 30                                                                                                                                         | -                                                                                                                                   | -                                                                                                                                          |
| WHO region                                  | 2022                                  | 2022                             | 2022                            | 2019                                            | 2018                                                                                                                            | 2020                                                                                                                                 | 2020                                                                                                                                    |
| African Region                              | 310                                  | 10.5                              | 39.4                              | 20                                             | 33                                                                                                                               | 32                                                                                                                                         | 32                                                                                                                                  | -                                                                                                                                          |
| Region of the Americas                       | 92                                   | 0.8                               | 8.5                               | 15                                             | 7                                                                                                                                | 25                                                                                                                                         | 81                                                                                                                                  | 52                                                                                                                                         |
| South-East Asia Region                      | 301                                  | 14.7                              | 38.6                              | 17                                             | 33                                                                                                                               | 46                                                                                                                                         | 29                                                                                                                                  | -                                                                                                                                          |
| European Region                             | 89                                   | 32.1                              | 18.8                              | 6                                               | 21                                                                                                                               | 92                                                                                                                                         | 70                                                                                                                                  | -                                                                                                                                          |
| Eastern Mediterranean Region                | 251                                  | 69.3                              | 63.3                              | 9                                               | 31                                                                                                                               | 56                                                                                                                                         | -                                                                                                                                   | -                                                                                                                                          |
| Western Pacific Region                      | 10.0                                 | 19.0                              | 18.4                              | 8                                             | 20                                                                                                                               | 65                                                                                                                                         | -                                                                                                                                   | -                                                                                                                                          |
| Global                                       | 22.3                                  | 6.8                               | 5.6                               | 29.9                                           | 13                                                                                                                               | 27                                                                                                                                         | 74                                                                                                                                  | 54                                                                                                                                         |
```
| Indicator                                            | 2020   | 2022   | 2021   | 2019   | 2019   | 2022   | 2018-2020 | 2016   | 2016   |
|-----------------------------------------------------|--------|--------|--------|--------|--------|--------|------------|--------|--------|
| Proportion of population using a hand-washing facility with soap and water (%)   | 36     | 43.24  | 81     | 223    | 12     | -      | 461        | 98.215 | -      |
| Proportion of safely treated domestic wastewater flows (%) | 21     | 18.65  | 1      | 433    | 79     | 408.25 | 87         | -      | -      |
| Amount of water/sanitation-related official development assistance that is part of a government-coordinated spending plan (constant 2020 USD millions) | 100    | 100    | 100    | 16.3   | 11     | -      | 427        | 81.5   | 20.5   |
| Annual mean concentrations of fine particulate matter (PM2.5) in urban areas (µg/m³) | 65     | 90    | 16.4   | 09     | -      | 458.3      | -      | -      |
| Mortality rate due to homicide (per 100,000 population) | 25     | 29.69  | 4      | 14.4   | 54     | 361     | 30.83     | -      | -      |
| Number of cases of poliomyelitis caused by wild poliovirus (WPV) | 44     | 8.28   | 88     | 217    | 39     | -      | 21        | -      | -      |
| Percentage of total antibiotic consumption being from the AWaRe "Access" antibiotics category (%) | 83     | 2758   | 253    | 26     | -      | 68     | 302       | 67.206 | -      |
| Age-standardized prevalence of hypertension among adults aged 30-79 years (%) | 73     | 979    | 86     | 56.8   | 18     | 25     | 11        | 10.00  | -      |
| Prevalence of obesity among children (5-19 years) (%) | 18     | 8674   | 10     | 18.8   | 6.5    | -      | 423       | 4.0    | 15.5   |


- Footnotes:
  - a: World population prospects: 2022 revision. New York (NY): United Nations, Department of Economic and Social Affairs, Population Division; 2022 (https://population.un.org/wpp/, accessed 30 April 2023). For Member States with a total population less than 90,000, the male, female values are not shown but are included in the regional and global sums. Male and female may not sum to both sexes due to rounding.
  
  - b: Global health estimates 2019: Life expectancy, 2000–2019. Geneva: World Health Organization; 2020 (https://www.who.int/data/gho/data/themes/mortality-and-global-health-estimates/, accessed 30 April 2023). WHO Member States with a population of less than 90,000 in 2019 were not included in the analysis.
  
  - c: Trends in maternal mortality 2000 to 2020: estimates by WHO, UNICEF, UNFPA, World Bank Group and UNDESA/Population Division. Geneva: World Health Organization; 2023 (https://www.who.int/publications/i/item/9789240068759, accessed 30 April 2023). WHO Member States excluded due to small populations: Andorra, Cook Islands, Dominica, Marshall Islands, Monaco, Nauru, Niue, Palau, Saint Kitts and Nevis, San Marino and Tuvalu.
  
  - d: UNICEF/WHO joint database on births attended by skilled health personnel, 2023 (https://data.unicef.org/topic/maternal-health/delivery-care/, accessed 30 April 2023); Global Health Observatory (GHO) data (https://www.who.int/data/gho/data/indicators/indicator-details/GHO/births-attended-by-skilled-health-personnel-(), accessed 30 April 2023).
  
  - e: Levels and trends in child mortality. Report 2022. Estimates developed by the UN Inter-agency Group for Child Mortality Estimation. United Nations Children’s Fund, World Health Organization, World Bank Group and United Nations Population Division. New York: United Nations Children’s Fund; 2023 (https://data.unicef.org/resources/levels-and-trends-in-child-mortality/, accessed 30 April 2023).
  
  - f: AIDSinfo (online database). Geneva: Joint United Nations Programme on HIV/AIDS (UNAIDS) (http://aidsinfo.unaids.org/); Global Health Observatory (GHO) data. Geneva: World Health Organization (https://www.who.int/data/gho/data/indicators/indicator-details/GHO/new-hiv-infections(per-1000-uninfected-population), accessed 30 April 2023).
  
  - g: Global tuberculosis report 2022. Geneva: World Health Organization; 2022 (https://www.who.int/publications/i/item/9789240061729, accessed 30 April 2023).
  
  - h: World malaria report 2022. Geneva: World Health Organization; 2022 (https://www.who.int/publications/i/item/9789240064898, accessed 30 April 2023). " indicates countries or regions that are malaria-free.
  
  - i: Global and country estimates of immunization coverage and chronic HBV infection. Geneva: World Health Organization (http:// situatedlaboratories.net/who-hepb-dashboard/src/#global-strategies, accessed 30 April 2023).
  
  - j: Neglected tropical diseases (online database). Global Health Observatory (GHO) data. Geneva: World Health Organization (https://www.who.int/data/gho/data/themes/topics/topic-details/GHO/neglected-tropical-diseases, accessed 30 April 2023). Global and regional aggregates include imputation of incomplete reports.
  
  - k: Global health estimates 2019: deaths by cause, age, sex, by country and by region, 2000–2019. Geneva: World Health Organization; 2020 (https://www.who.int/data/gho/data/themes/mortality-and-global-health-estimates/, accessed 2 May 2022). WHO Member States with a population of less than 90,000 in 2019 were not included in the analysis.
  
  - l: WHO Global Information System on Alcohol and Health (GISAH) (online database). Global Health Observatory (GHO) data. Geneva: World Health Organization (https://www.who.int/data/gho/data/themes/topics/topic-details/GHO/levels-of-consumption/, accessed 30 April 2023).
  
  - m: World Contraceptive Use 2022. New York (NY): United Nations, Department of Economic and Social Affairs, Population Division (https://www.un.org/development/desa/pd/world-contraceptive-use, accessed 30 April 2023). Global and regional aggregates are from the Estimates and Projections of Family Planning Indicators 2022. New York (NY): United Nations, Department of Economic and Social Affairs, Population Division.
  
  - n: Most recent updates provided by the Population Division, of the UN Department of Economic and Social Affairs to the SDG Indicators, Global SDG Data Database (https://unstats.un.org/sdgs/indicators/database, accessed 30 April 2023). Global and regional aggregates are from the World population prospects: the 2022 revision. New York: United Nations, Department of Economic and Social Affairs, Population Division.

# Coverage of essential health services (SDG 3.8) [online database]. 
Global Health Observatory. Geneva: World Health Organization; 2023. 
Accessed: 30 April 2023.

# SDG 3.2 Catastrophic health spending (and related indicators) [online database]. 
Global Health Observatory. Geneva: World Health Organization; 2023. 
Accessed: 30 April 2023.

# Public health and environment [online database]. 
Global Health Observatory (GHO) data. Geneva: World Health Organization 
Accessed: 30 April 2023.

# WHO global report on trends in prevalence of tobacco use 2000–2025, fourth edition. 
Geneva: World Health Organization; 2021. 
Accessed: 2 May 2022.

# WHO/UNICEF Joint Estimates of National Immunization Coverage (WUENIC), 2022 revision. 
Accessed: 30 April 2023.

# Official development assistance for the health sector, 2021. Creditor reporting system (CRS) of the Organization for Economic Co-operation and Development (OECD). 
Accessed: 30 April 2023.

# Data collected with the WHO Essential Medicines and Health Products Price and Availability Monitoring Mobile Application (WHO EPM MedMon). 
Accessed: 30 April 2023.

# Global Health Workforce Statistics [online database]. 
Global Health Observatory data. Geneva: World Health Organization.
Accessed: 30 April 2023.

# International Health Regulations (2005) – States Parties Annual Self-Assessment Reports – Monitoring Framework [online database]. 
Global Health Observatory data. Geneva: World Health Organization; 2023. 
Accessed: 30 April 2023.

# Global Antimicrobial Resistance and Use Surveillance System (GLASS). 
Global Health Organization; 2022. 

# Global Health Expenditure Database. 
Geneva: World Health Organization; 2023.

# Levels and trends in child malnutrition. 
UNICEF/WHO/World Bank Group Joint Child Malnutrition Estimates. 
NY, Geneva and Washington (DC). 
Accessed: 30 April 2023.

# Global anemia estimates, 2021. 
World Health Organization; 2021. 
Accessed: 30 April 2023.

# Violence against women prevalence estimates, 2018. 
Global, regional and national prevalence estimates for intimate partner violence against women and global prevalence estimates for non-partner sexual violence against women. 
Geneva: World Health Organization; 2021. 
Accessed: 2 May 2022.
```

**JSON Table Format:** 

```json
{
  "coverage_essential_health_services": {
    "source": "Global Health Observatory", 
    "date_accessed": "30 April 2023"
  },
  "sdg_3_2_catastrophic_health_spending": {
    "source": "Global Health Observatory", 
    "date_accessed": "30 April 2023"
  },
  "public_health_environment": {
    "source": "Global Health Observatory (GHO)",
    "date_accessed": "30 April 2023"
  },
  "tobacco_use_report": {
    "source": "World Health Organization", 
    "date_published": "2021", 
    "date_accessed": "2 May 2022"
  },
  "immunization_coverage": {
    "source": "WHO/UNICEF", 
    "date_accessed": "30 April 2023"
  },
  "development_assistance_health": {
    "source": "OECD", 
    "date_accessed": "30 April 2023"
  },
  "essential_medicines_monitoring": {
    "source": "WHO EPM MedMon", 
    "date_accessed": "30 April 2023"
  },
  "health_workforce_statistics": {
    "source": "Global Health Observatory", 
    "date_accessed": "30 April 2023"
  },
  "health_regulations": {
    "source": "Global Health Observatory", 
    "date_accessed": "30 April 2023"
  },
  "antimicrobial_resistance": {
    "source": "Global Health Organization", 
    "date_accessed": "2022"
  },
  "expenditure_database": {
    "source": "World Health Organization", 
    "date_accessed": "2023"
  },
  "malnutrition_statistics": {
    "source": "UNICEF/WHO/World Bank Group", 
    "date_accessed": "30 April 2023"
  },
  "anemia_estimates": {
    "source": "World Health Organization", 
    "date_accessed": "30 April 2023"
  },
  "violence_against_women_estimates": {
    "source": "World Health Organization", 
    "date_accessed": "2 May 2022"
  }
}
```
The lack of consensus on the definition and standardized measurement of psychological intimate partner violence, the current estimates include only physical and/or sexual partner violence. As the majority of the available survey data on intimate partner violence are for women aged 15–49 years, with sparse data for women aged 15 years and older, the estimates are presented for the 15–49 years age group.

Progress on household drinking water, sanitation and hygiene 2000-2020: five years into the SDGs. Geneva: World Health Organization and the United Nations Children’s Fund; 2021 (https://washdata.org/sites/default/files/2022-01/fig-2021-wash-households_3.pdf, accessed 30 April 2023). Comparable estimates are only shown for countries with recent primary data. Global and regional aggregates are calculated to include country data not shown in the table.

json
{
  "data_sources": [
    {
      "source": "United Nations Global SDG Indicators Data Platform",
      "url": "https://unstats.un.org/sdgs/dataportal",
      "last_accessed": "25 April 2023"
    },
    {
      "source": "Official development assistance for the water sector",
      "url": "https://stats.oecd.org/Index.aspx?DataSetCode=crs1",
      "last_accessed": "30 April 2023"
    },
    {
      "source": "Public health and environment",
      "url": "https://www.who.int/data/gho/data/themes/public-health-and-environment/GHO/public-health-and-environment",
      "last_accessed": "30 April 2023"
    },
    {
      "source": "Global Polio Eradication Initiative",
      "url": "https://polioeradication.org/polio-today/polio-now/wild-poliovirus-list/",
      "last_accessed": "12 April 2023"
    },
    {
      "source": "Risk factors in noncommunicable diseases",
      "url": "https://www.who.int/data/gho/data/themes/topics/topic-details/GHO/noncommunicable-diseases--risk-factors",
      "last_accessed": "30 April 2023"
    }
  ]
}
```

- Risk factors in noncommunicable diseases [online database]. Global Health Observatory data. Geneva: World Health Organization (https://www.who.int/data/gho/data/themes/topics/topic-details/GHO/noncommunicable-diseases--risk-factors, accessed 30 April 2023).
- Non-standard definition. For more details see: UNICEF/WHO joint database on births attended by skilled health personnel (footnote "d").
- Proportion of institutional births (%) used as proxy for the SDG indicator.
- Non-standard definition. For more details see: World Contraceptive Use 2021 (footnote "m").
- Estimate refers to smoking only, but is expected to be similar to all tobacco use.
- Data for capital city only.
- Data from private sector only.
- Qedema data was not considered in the analysis.
- Non-standard definition. For more details, see respective survey(s) comments available at: https://www.who.int/data/gho/data/indicators/indicator-details/GHO/gho-jme-country-children-aged-5-years-wasted-br-(weight-for-height-2-sd) (accessed 30 April 2023).
- Most recent input data is before 2000, interpret with caution.
- Data collection excluded some regions or populations. For more details, see respective survey(s) comments available at: https://www.who.int/data/gho/data/indicators/indicator-details/GHO/gho-jme-country-children-aged-5-years-wasted-br-(weight-for-height-2-sd) (accessed 30 April 2023).
- For high-income countries classified as high-income in the 2021 fiscal year with no information on clean fuel use, usage is assumed to be 100%.
- Only hospital consumption is reported.
- Only community consumption is reported.
- Only public sector reported.
```
# Annex 2. Regional groupings

## WHO African Region
- Algeria
- Angola
- Benin
- Botswana
- Burkina Faso
- Burundi
- Cabo Verde
- Cameroon
- Central African Republic
- Chad
- Comoros
- Congo
- Côte d'Ivoire
- Democratic Republic of the Congo
- Equatorial Guinea
- Eritrea
- Eswatini
- Ethiopia
- Gabon
- Gambia
- Ghana
- Guinea
- Guinea-Bissau
- Kenya
- Lesotho
- Liberia
- Madagascar
- Malawi
- Mali
- Mauritania
- Mauritius
- Mozambique
- Namibia
- Niger
- Nigeria
- Rwanda
- Sao Tome and Principe
- Senegal
- Seychelles
- Sierra Leone
- South Africa
- South Sudan
- Togo
- Uganda
- United Republic of Tanzania
- Zambia
- Zimbabwe

## WHO Region of the Americas
- Antigua and Barbuda
- Argentina
- Bahamas
- Barbados
- Belize
- Bolivia (Plurinational State of)
- Brazil
- Canada
- Chile
- Colombia
- Costa Rica
- Cuba
- Dominica
- Dominican Republic
- Ecuador
- El Salvador
- Grenada
- Guyana
- Haiti
- Honduras
- Jamaica
- Mexico
- Nicaragua
- Panama
- Paraguay
- Peru
- Puerto Rico
- Saint Kitts and Nevis
- Saint Lucia
- Saint Vincent and the Grenadines
- Suriname
- Trinidad and Tobago
- United States of America
- Uruguay
- Venezuela (Bolivarian Republic of)

## WHO South-East Asia Region
- Bangladesh
- Bhutan
- Democratic People's Republic of Korea
- India
- Indonesia
- Maldives
- Myanmar
- Nepal
- Sri Lanka
- Thailand
- Timor-Leste

## WHO European Region
- Albania
- Andorra
- Armenia
- Austria
- Azerbaijan
- Belarus
- Belgium
- Bosnia and Herzegovina
- Bulgaria
- Croatia
- Cyprus
- Czechia
- Denmark
- Estonia
- Finland
- France
- Georgia
- Germany
- Greece
- Hungary
- Iceland
- Ireland
- Israel
- Italy
- Kazakhstan
- Kyrgyzstan
- Latvia
- Lithuania
- Luxembourg
- Malta
- Monaco
- Montenegro
- Netherlands (Kingdom of the)
- North Macedonia
- Norway
- Poland
- Portugal
- Republic of Moldova
- Romania
- Russian Federation
- San Marino
- Serbia
- Slovakia
- Slovenia
- Spain
- Sweden
- Switzerland
- Tajikistan
- Türkiye
- Turkmenistan
- Ukraine
- United Kingdom of Great Britain and Northern Ireland
- Uzbekistan

## WHO Eastern Mediterranean Region
- Afghanistan
- Bahrain
- Djibouti
- Egypt
- Iran (Islamic Republic of)
- Iraq
- Jordan
- Kuwait
- Lebanon
- Libya
- Morocco
- occupied Palestinian territory, including east Jerusalem
- Oman
- Pakistan
- Qatar
- Saudi Arabia
- Somalia
- Sudan
- Syrian Arab Republic
- Tunisia
- United Arab Emirates
- Yemen

## WHO Western Pacific Region
- Australia
- Brunei Darussalam
- Cambodia
- China
- Hong Kong SAR
- Macao SAR
- Cook Islands
- Fiji
- Japan
- Kiribati
- Lao People's Democratic Republic
- Malaysia
- Marshall Islands
- Micronesia (Federated States of)
- Mongolia
- Nauru
- New Zealand
- Niue
- Palau
- Papua New Guinea
- Philippines
- Republic of Korea
- Samoa
- Singapore
- Solomon Islands
- Tonga
- Tuvalu
- Vanuatu
- Viet Nam.

*Included are all WHO Member States, plus Associate Member States and territories with populations above 500,000 in 2021 according to World population prospects: 2022 revision. New York (NY): United Nations, Department of Economic and Social Affairs, Population Division; 2022 (https://population.un.org/wpp/; accessed 15 April 2023).*
```
Such progress, however, has so far not been sustained in the SDG era, as the ARR of the global maternal mortality ratio plummeted to -0.04% (UI: -1.6–1%) between 2016 and 2020, indicating stagnation. An estimated 287,000 (UI: 273,000–343,000) women lost their lives due to largely preventable causes related to pregnancy and childbirth in 2020 – approximately 800 women every day – equivalent to 223 (UI: 202–255) deaths per 100,000 live births that year.

The maternal mortality ratio levels, as well as the rates of progress and slowdown, have been uneven across WHO regions (Figure 11). The WHO South-East Asia Region maintained the fastest reduction rate during the MDG era and the first five years of the SDG era, reducing the maternal mortality ratio from 372 (UI: 336–423) deaths per 100,000 live births in 2000 to 117 (UI: 106–133) deaths per 100,000 live births in 2020. The African Region, while keeping the ARR relatively stable at 2.0% for the past two decades, continued to have the highest maternal mortality ratio. The Region of the Americas, the Western Pacific Region and the European Region saw a trend reversal, with the maternal mortality ratio levels increasing between 2016 and 2020 after having decreased during the MDG era. However, the levels of the maternal mortality ratio have remained low (below 100 deaths per 100,000 maternal deaths) since 2000.

Figure 12 shows countries and areas for which estimates are available. In 2020, 13 countries had a maternal mortality ratio that was very high (between 500 and 999) or extremely high (over 1000). Of these countries, 11 are in the African Region and two are in the Eastern Mediterranean Region. In total, 117 countries and areas had a maternal mortality ratio below 100 deaths per 100,000 live births, 60 of which had a very low maternal mortality ratio (below 20).

Disparities may also occur within countries, with maternal mortality ratio levels varying across subnational regions and places of residence, or by socioeconomic status such as income and educational levels, and by other social determinants such as race and ethnicity.

Figure 11: Maternal mortality ratio and the average annual rate of reduction by WHO region, 2000–2020

| Region                       | ARR (2000–2015) | ARR (2016–2020) | MMR (2000) | MMR (2020) |
|------------------------------|------------------|------------------|------------|------------|
| European Region              |          0.0%    |          0.0%    |   800      |   570      |
| Western Pacific Region       |          2.0%    |         -1.0%     |   175      |   87       |
| Region of the Americas       |          4.0%    |          2.0%    |   200      |   130      |
| South-East Asia Region       |          4.0%    |          2.5%    |   300      |   368      |
| Eastern Mediterranean Region  |          1.0%    |          0.0%    |   456      |   411      |
| African Region               |          2.0%    |          2.0%    |   372      |   117      |

Note: ARR = average annual rate of reduction; MMR = maternal mortality ratio.
Source: Ref. (1)
```
# Trends in global under-five mortality and neonatal mortality rates, 2000-2021

## Figure 14

| Year | U5MR | NMR | ARR for U5MR | ARR for NMR |
|------|------|-----|---------------|--------------|
| 2000 | 80   |     | 4.0%         |              |
| 2005 | 50   |     | 3.2%         |              |
| 2010 | 40   |     | 2.7%         |              |
| 2015 | 30   |     | 2.2%         |              |
| 2021 | 10   |     |               |              |

Note: ARR = average annual rate of reduction; U5MR = under-five mortality rate; NMR = neonatal mortality rate.  
Source: Ref. (4)

---

## Figure 15

json
{
  "deaths": [
    {"year": 2000, "total_deaths": 10},
    {"year": 2001, "total_deaths": 9},
    {"year": 2002, "total_deaths": 8},
    {"year": 2003, "total_deaths": 7},
    {"year": 2004, "total_deaths": 6},
    {"year": 2005, "total_deaths": 5},
    {"year": 2006, "total_deaths": 4},
    {"year": 2007, "total_deaths": 3},
    {"year": 2008, "total_deaths": 2},
    {"year": 2009, "total_deaths": 1},
    {"year": 2010, "total_deaths": 1},
    {"year": 2011, "total_deaths": 1},
    {"year": 2012, "total_deaths": 1},
    {"year": 2013, "total_deaths": 2},
    {"year": 2014, "total_deaths": 3},
    {"year": 2015, "total_deaths": 4},
    {"year": 2016, "total_deaths": 5},
    {"year": 2017, "total_deaths": 6},
    {"year": 2018, "total_deaths": 7},
    {"year": 2019, "total_deaths": 8},
    {"year": 2020, "total_deaths": 9},
    {"year": 2021, "total_deaths": 9}
  ]
}
```
```
# A “first embrace” after caesarean section in Viet Nam is saving newborn lives

Efforts to improve outcomes for mothers and babies in Viet Nam have been increasingly complicated by an accelerating caesarean section rate, estimated at 29% nationally in 2022. Across Viet Nam, babies born by caesarean section are routinely separated from their mothers and admitted to neonatal intensive care units (NICUs) for prolonged observation and are given infant formula. This often unnecessary practice has increased the risk of newborn infections and other complications and has resulted in crowded NICUs.

In 2014, Viet Nam introduced early essential newborn care (EENC), a package of evidence-based interventions that are applied at birth to prevent or manage common causes of newborn morbidity and mortality. These include immediate and thorough drying, sustained skin-to-skin contact, delayed cord clamping, promotion of early and exclusive breastfeeding, resuscitation of non-breathing babies and “kangaroo mother care” (KMC). The core of this approach is sustained skin-to-skin contact between mother and baby (“the first embrace”), which transfers warmth and promotes non-separation.

The Da Nang Hospital for Women and Children was one of the first to introduce EENC in Viet Nam, using staff coaching, quality improvement assessments and changes in protocols and environments. After introducing EENC with routine vaginal births, the hospital then pioneered this approach to care with caesarean births by developing methods for coaching surgical teams and improving availability of baby hats, drying cloths and resuscitation areas in operating rooms.

Following this, over the period 2013–2015, data on 16,927 newborns delivered by caesarean section before and after the introduction of EENC showed that total NICU admissions decreased from 16.7% to 11.8% (relative risk 0.71; 95% CI 0.66–0.76). In addition, compared with the pre-EENC period, the number of babies with hypothermia on admission to the NICU declined from 5.0% to 3.7% (relative risk 0.73; 95% CI 0.63–0.84) and cases of sepsis decreased from 3.2% to 0.8% (relative risk 0.26; 95% CI 0.20–0.33).

While more than half of all newborns in the NICU were previously fed something other than breastmilk after EENC was introduced, 85.8% were exclusively breast-fed (relative risk 186; 95% CI 175–198), and preterm newborns (< 2000 g) receiving KMC increased from 50% to 67% (relative risk 133; 95% CI 112–159).

These findings show a significant impact on outcomes for babies born by caesarean section, ultimately saving lives. The reduction in caesarean NICU admissions also represented a saving to the hospital of at least US$ 162,060 in the year after introduction of EENC.

These data led to wider adoption of EENC in Viet Nam. As of 2019, the first embrace was being applied at 100% of national hospitals and 89% of subnational ones, reducing pressure on maternity health systems and enhancing the health and well-being of babies, mothers and families.

Source: Tran HT, Murray JCS, Sobel HL, Mannava P, Huynh LT, Nguyen PTT et al. Early essential newborn care is associated with improved newborn outcomes following caesarean section births in a tertiary hospital in Da Nang, Vietnam: a pre/post-intervention study. BMJ Open Quality. 2021;10(3):e001089 (https://bmjopenquality.bmj.com/content/10/3/e001089, accessed 4 April 2023). doi:10.1136/bmjoq-2020-001089.
```
## 1.2. Noncommunicable diseases and major risk factors

Noncommunicable diseases (NCDs) affect people from all walks of life, and in all parts of the world. The epidemic of NCDs poses devastating health consequences for individuals, families and communities. Prevention and control of these diseases are a major development imperative for the 21st century.

NCDs continued to cause the highest disease burden worldwide. The impact of NCDs grew from causing 61% of global deaths (equivalent to 31 million; UI: 24–40 million) in 2000 to causing 74% (or 41 million; UI: 29–57 million) in 2019, and from causing 47% (or 13 billion; UI: 0.8–17 billion) of global disability-adjusted life-years (DALYs)* in 2000 to causing 63% (or 16 billion, UI: 10.2–22 billion) of DALYs in 2019 (2.6).

Four major NCDs collectively killed about 33.3 million (UI: 24.5–43.3 million) people in 2019, a 28% increase compared to 2000. These major NCDs are cardiovascular disease (1.79 million, UI: 134–229 million), cancer (9.3 million, UI: 6.9–12.2 million), chronic respiratory disease (4.1 million, UI: 2.9–5.6 million) and diabetes (2.0 million, UI: 1.4–2.7 million).

The increase in absolute numbers of deaths and DALYs due to NCDs was mainly driven by population growth and aging. At individual level, however, the overall risk of dying from NCDs has been declining worldwide, showing progress over the last two decades.

Globally, the greatest decline in deaths from major NCDs between 2000 and 2019 were from chronic respiratory disease (a 37% drop in age-standardized rates for all ages combined), followed by cardiovascular disease (27%) and cancer (16%). Deaths due to diabetes, however, increased slightly, by 3% over the same period.

### NCD premature mortality

Globally, a person aged 30 years in 2019 has a 17.8% (UI: 13.3–23.1%) chance of dying from one of the four major NCDs before the age of 70 years. The probability is highest in the WHO Eastern Mediterranean Region at 24.5% (UI: 16.7–34.0), followed by the South-East Asia Region at 21.6% (UI: 15.8–28.2%) and the African Region at 20.8% (UI: 13.3–30.3%). The probability was lower in the WHO European Region at 16.3% (UI: 12.7–20.4%), in the Western Pacific Region at 15.6% (UI: 11.9–19.7%) and the Region of the Americas at 14.0% (UI: 11.7–16.9%) (2).

This represents progress from all regions since 2000 and a 22.9% decline globally. At regional levels the decline ranged from roughly 13% in the South-East Asia and Eastern Mediterranean regions to a decline of more than 25% in the Western Pacific (26.8%) and European (31.2%) regions.

Men have a higher probability of premature death from NCDs than women in all WHO regions and globally. The absolute gap between sexes had been closing during the last two decades globally and in all WHO regions. However, the relative gap – as measured by the male-to-female ratio – increased by 11% in the Western Pacific Region, while it declined or remained roughly constant in the other five regions.

However, progress has slowed since the beginning of the SDG era in 2015. If the average annual rate of reduction (ARR) in premature mortality of the major NCDs continues, none of the WHO regions will achieve the SDG target of the third reduction. By the 100th anniversary of WHO in 2048, only the African, Eastern Mediterranean and European regions will have achieved the SDG 2030 target, while the target will be missed in other regions and also globally (Figure 17).
```
## Major NCD risk factors

NCDs are the result of a combination of genetic, physiological, environmental and behavioural factors. Modifiable behavioural risk factors include harmful use of alcohol, tobacco use, physical inactivity and an unhealthy diet. Metabolic risk factors include raised blood pressure, overweight and obesity, hyperglycaemia (high blood glucose levels), and hyperlipidaemia (high levels of fat in the blood). The latest available data for indicators on some of these risk factors are presented below. Environmental risks are discussed in Section 24.

### Alcohol consumption

Total alcohol per capita (15+ years) consumption has declined at global level since 2015, following an overall increase in 2005–2010 and a plateau in 2010–2015. Total consumption was 5.5 litres (UI: 4.8–6.2) of pure alcohol per capita (persons aged 15 years or older) in 2019.

The trends were not uniform across WHO regions. While the European and African regions experienced sizeable decline in per capita consumption by 17% and 18% respectively between 2000 and 2019, there has been stagnation in the Region of the Americas and substantial increases in per capita consumption in the South-East Asia and Western Pacific regions (of 112% and 40% respectively).

Despite the decline, men and women in the European Region still had the highest consumption – 14.9 (UI: 13.6–16.2) litres per capita in men and 4.0 (UI: 3.6–4.4) litres per capita in women. Per capita consumption in the Region of the Americas was 11.9 (UI: 10.1–13.8) litres in men and 3.3 (UI: 2.7–3.8) litres in women, while in the Western Pacific Region it was 9.6 (UI: 8.2–12.5) litres in men and 2.5 (UI: 1.8–3.2) litres in women. The lowest per capita consumption was in the Eastern Mediterranean Region with 0.5 (UI: 0.4–0.9) litres in men and 0.1 (UI: 0.0–0.1) litres in women in 2019.

Globally, men consumed nearly four times more pure alcohol per capita than women did – namely, 8.7 (UI: 7.7–9.9) litres versus 2.2 (UI: 1.9–2.5) litres in 2019. The greatest gaps between the sexes (male-to-female ratios) were observed in the Eastern Mediterranean Region (8.1) and South-East Asia Region (5.1), and the lowest ratio was in the Region of the Americas (3.7) and the European Region (3.7).


### Table Data in JSON Format

```json
{
  "probability_of_dying": {
    "African_Region": {
      "years": [2000, 2010, 2020, 2030, 2040],
      "values": [30, 25, 20, 15, 10]
    },
    "Region_of_the_Americas": {
      "years": [2000, 2010, 2020, 2030, 2040],
      "values": [25, 20, 15, 10, 5]
    },
    "Eastern_Mediterranean_Region": {
      "years": [2000, 2010, 2020, 2030, 2040],
      "values": [20, 15, 10, 5, 2]
    },
    "European_Region": {
      "years": [2000, 2010, 2020, 2030, 2040],
      "values": [15, 10, 5, 2, 1]
    },
    "South_East_Asia_Region": {
      "years": [2000, 2010, 2020, 2030, 2040],
      "values": [30, 25, 20, 15, 10]
    },
    "Western_Pacific_Region": {
      "years": [2000, 2010, 2020, 2030, 2040],
      "values": [25, 20, 15, 10, 5]
    },
    "Global": {
      "years": [2000, 2010, 2020, 2030, 2040],
      "values": [10, 5, 2, 1, 0]
    }
  }
}
```
### Figure 1.8 Total alcohol consumption per capita (age 15 years or older), WHO regions and global, 2000–2019

| Region                       | 2000 | 2005 | 2010 | 2015 | 2019 |
|------------------------------|------|------|------|------|------|
| African Region               | 12   | 11   | 10   | 10   | 9    |
| Region of the Americas       | 10   | 11   | 11   | 11   | 10   |
| Eastern Mediterranean Region  | 9    | 8    | 7    | 6    | 6    |
| European Region              | 14   | 14   | 14   | 13   | 13   |
| South-East Asia Region       | 4    | 5    | 6    | 7    | 8    |
| Western Pacific Region       | 6    | 5    | 5    | 5    | 4    |
| Global                       | 9    | 9    | 9    | 9    | 9    |

### Tobacco use

Globally, the age-standardized prevalence of current tobacco use among persons aged 15 years or older has declined by over 30% – from 32.7% in 2000 to 22.3% in 2020 (Figure 19). With one of the greatest declines of over 40%, the South-East Asia Region nevertheless had the highest prevalence of tobacco use (29.6%) in 2020, whereas the African Region and the Region of the Americas had the lowest prevalences at 10.3% and 16.3%, respectively, in 2020. Progress was slowest in the Western Pacific Region where the decline was only 11.8% from a prevalence of 27.9% in 2000 to 24.6% in 2020.

The Global Action Plan for Prevention and Control of NCDs has set a target to reduce the current tobacco use prevalence by 30% between 2010 and 2025. Notwithstanding the progress made in many parts of the world since 2000, the rate of reduction in the prevalence has slowed in 2010–2020 compared to 2000–2010. Globally, the current tobacco use prevalence dropped only by 16.5% between 2010 and 2020, falling much short of the target of the 30% reduction by 2025. If the trend continues, the likelihood of meeting this target is lowest in Western Pacific with only a 5.7% reduction between 2010 and 2020. In contrast, the regions of Africa, Americas and South-East Asia have a better chance meeting the target by 2025, each having experienced about 23% reduction in 2010–2020.

The age-standardized current tobacco use prevalence was higher among men than among women across the world. The male-to-female ratio at global level was 4.7 in 2020, rising from 3.0 in 2000 and indicating a slower reduction among men compared to women. The lack of progress among men in relative terms was observed in all WHO regions, except for Europe where the ratio dropped slightly from over 2 in 2000 to 1.9 in 2020 – a level that was lowest among all six WHO regions. The ratio remained highest in Western Pacific Region throughout the two decades, rising from 10.2 in 2000 to 16.6 in 2020.
```
json
{
  "tobacco_use": {
    "regions": [
      {
        "name": "African Region",
        "data": {
          "2000": 17.9,
          "2020": 28.7
        }
      },
      {
        "name": "Region of the Americas",
        "data": {
          "2000": 10.3,
          "2020": 17.8
        }
      },
      {
        "name": "Eastern Mediterranean Region",
        "data": {
          "2000": 27.2,
          "2020": 35.5
        }
      },
      {
        "name": "European Region",
        "data": {
          "2000": 34.6,
          "2020": 44.1
        }
      },
      {
        "name": "South-East Asia Region",
        "data": {
          "2000": 29.0,
          "2020": 32.9
        }
      },
      {
        "name": "Western Pacific Region",
        "data": {
          "2000": 27.9,
          "2020": 46.6
        }
      },
      {
        "name": "Global",
        "data": {
          "2000": 32.7,
          "2020": 36.9
        }
      }
    ]
  }
}
```

Obesity
The age-standardized prevalence of obesity among adults aged 18 years or older — i.e. body mass index (BMI) >30 kg/m² — has been rising since the 1970s. In 2016, 13.1% (UI: 12.4–13.9%) of adults globally were obese, up from 8.7% (UI: 8.4–9.0) in 2000. The greatest increases occurred in the South-East Asia Region, up from 1.9% (UI: 1.6–2.2%) to 4.7% (UI: 3.9–5.6%) (an almost 150% increase) and the Western Pacific Region, up from 2.7% (UI: 2.4–3.0%) to 6.4% (UI: 5.2–7.7%) (an almost 140% increase). The highest level of adult obesity is 2016 was in the Americas where 28.6% (UI: 26.3–30.5%) of adults were obese, increasing by 42% from 20.2% (UI: 19.0–21.5%) in 2000.

Unlike many other health risks, the prevalence rates of obesity were higher among adult women than men. Globally, the female-to-male ratio of age-standardized prevalence of obesity was 14 in 2016, down from 16 in 2000 and indicating a more rapid rise in male obesity. The sex difference was greatest in the African Region with a ratio at over 2.7 in 2016, down from 3.7 in 2000. All regions have shown similar trends of the more rapid increase in male obesity and the narrowing gap between sexes, with the regions of Europe and the Western Pacific having a ratio reduced to only 11 in 2016.

Obesity and overweight also affects children and adolescents, and the global prevalence has been increasing since 2000. The latest data on overweight among children under 5 years of age are presented in Section 2.2.
```
## Age-standardized prevalence of obesity among adults (age 18 years or older), WHO regions and global, 1975–2016

json
{
  "data": [
    {
      "region": "African Region",
      "gender": ["Both sexes", "Male", "Female"],
      "years": [2005, 2010, 2016],
      "prevalence": [0, 0, 0]  // Placeholder values
    },
    {
      "region": "Region of the Americas",
      "gender": ["Both sexes", "Male", "Female"],
      "years": [2005, 2010, 2016],
      "prevalence": [0, 0, 0]  // Placeholder values
    },
    {
      "region": "Eastern Mediterranean Region",
      "gender": ["Both sexes", "Male", "Female"],
      "years": [2005, 2010, 2016],
      "prevalence": [0, 0, 0]  // Placeholder values
    },
    {
      "region": "European Region",
      "gender": ["Both sexes", "Male", "Female"],
      "years": [2005, 2010, 2016],
      "prevalence": [0, 0, 0]  // Placeholder values
    },
    {
      "region": "South-East Asia Region",
      "gender": ["Both sexes", "Male", "Female"],
      "years": [2005, 2010, 2016],
      "prevalence": [0, 0, 0]  // Placeholder values
    },
    {
      "region": "Western Pacific Region",
      "gender": ["Both sexes", "Male", "Female"],
      "years": [2005, 2010, 2016],
      "prevalence": [0, 0, 0]  // Placeholder values
    },
    {
      "region": "Global",
      "gender": ["Both sexes", "Male", "Female"],
      "years": [2005, 2010, 2016],
      "prevalence": [0, 0, 0]  // Placeholder values
    }
  ]
}
```

### Hypertension

The global age-standardized prevalence of hypertension among adults aged 30–79 years has been rising since 1990 before peaking around 2009; it declined thereafter to 33.1% (UI: 31.5–34.8%) in 2019. The similar bell-curved trends were also observed in all WHO regions, except in South-East Asia where the prevalence has continued to rise since 1990 and in Europe where there has been continuous decline. Among the WHO regions, the Eastern Mediterranean had the highest prevalence of adult hypertension in 2019 at 37.8% (UI: 34.9–40.8%), followed by Europe at 36.9% (UI: 35.0–38.7%), Africa at 35.5% (UI: 33.0–38.0%) and the Americas at 35.4% (UI: 33.3–37.6%), while the Western Pacific Region had the lowest level at 28.3% (UI: 24.8–32.1%).

The sex difference in age-standardized prevalence of hypertension among adults varies markedly across WHO regions. In the African, Eastern Mediterranean and South-East Asia regions, the prevalence among women was consistently higher than among men, and the gap has widened in the African Region but narrowed in the Eastern Mediterranean Region in recent years. In contrast, in the Region of the Americas, the European Region and the Western Pacific Region, the prevalence among men was higher than that among women. The male-to-female ratio has increased in the European and the Western Pacific regions, both reaching over 1.2 in 2019, while in the Americas it remains roughly constant at around 1.1.
```
{
  "table": {
    "headers": ["Region", "1990", "2000", "2010", "2019"],
    "data": [
      {
        "Region": "African Region",
        "1990": 25,
        "2000": 30,
        "2010": 35,
        "2019": 40
      },
      {
        "Region": "Region of the Americas",
        "1990": 20,
        "2000": 25,
        "2010": 30,
        "2019": 35
      },
      {
        "Region": "Eastern Mediterranean Region",
        "1990": 15,
        "2000": 20,
        "2010": 25,
        "2019": 30
      },
      {
        "Region": "European Region",
        "1990": 10,
        "2000": 10,
        "2010": 15,
        "2019": 20
      },
      {
        "Region": "South-East Asia Region",
        "1990": 30,
        "2000": 35,
        "2010": 40,
        "2019": 45
      },
      {
        "Region": "Western Pacific Region",
        "1990": 5,
        "2000": 10,
        "2010": 15,
        "2019": 20
      },
      {
        "Region": "Global",
        "1990": 20,
        "2000": 25,
        "2010": 30,
        "2019": 35
      }
    ]
  }
}

NCD prevention and control

An indispensable way to prevent and control NCDs is to focus on lowering the associated risk factors. Low-cost solutions exist for governments and other stakeholders to reduce the common modifiable risk factors. A comprehensive approach is needed to require all sectors—health, finance, transport, education, agriculture, trade and others—to work together towards a common goal. Monitoring of progress and trends of NCDs and their risk factors is also essential to guide policies and priorities.

It is equally critical to invest in better management of NCDs, including the detection, screening and treatment of these diseases, as well as access to palliative care for people in need. High-impact essential NCD interventions can be delivered through a primary health care approach in order to strengthen early detection and timely treatment. Such interventions are excellent economic investments because, if provided early to patients, they can reduce the need for more expensive treatment.

Countries around the world are addressing the growing NCD problems. Box 12 presents efforts taken by the Kingdom of Saudi Arabia in this endeavour.
```
# World health statistics 2023 – Monitoring health for the SDGs

Nevertheless, reported deaths due to COVID-19 generally underestimate the true toll of the impact of COVID-19 on human mortality. Over the past two years, WHO has undertaken a monumental effort to collate all available information on reported all-cause mortality by week and month both during and before the pandemic. The Organization also collated data and other relevant information on the COVID-19 pandemic itself as well as the relevant epidemiological situation of populations around the world to produce for its Member States the most comprehensive assessment of the impact of the COVID-19 pandemic on mortality by sex and age for 2020 and 2021 (1213).

Through the Member State consultation conducted in 2023, WHO's updated estimates of excess mortality show that globally 14.9 million (95% UI: 13.3–16.6 million) excess deaths could be attributed to the COVID-19 pandemic by the end of 2021. More excess deaths occurred in 2021 – 10.4 million (95% UI: 9.1–12.1 million) – than in 2020 when there was a total of 4.4 million (UI: 3.9–5.0 million). At the regional level, the South-East Asia Region had the highest number of excess deaths for the years 2020 and 2021 at 6.1 million (UI: 4.7–7.8 million), which accounted for 41% of global excess deaths; this was significantly different from the percentage of globally reported COVID-19 deaths that the South-East Asia Region accounted for over the same period (13.3% of global reported deaths). Except for the Western Pacific Region and the African Region, which had only 0.2 million (UI: 0.0–0.4 million) and 0.8 million (UI: 0.5–1.1 million) estimated excess deaths respectively, all other regions had estimated excess deaths of more than 1 million by the end of 2021. Both the European Region and the Region of the Americas had excess deaths over 3 million – i.e. 3.2 million (UI: 3.1–3.2 million) in Europe and 3.2 million (UI: 3.2–3.3 million) in the Americas (Figure 1.13) (14).

The large discrepancy between estimated global excess mortality and the reported deaths due to COVID-19 – a difference of 9.4 million by the end of 2021 – shows that the impact of the pandemic is far-reaching. Indeed, 162 out of 194 WHO Member States show a higher excess mortality rate associated with the COVID-19 pandemic than the reported mortality rate attributable to COVID-19 between 2020 and 2021.

## Figure 1.13 Total excess deaths by WHO region, 1 January 2020 to 31 December 2021

json
{
  "regions": [
    {
      "name": "African Region",
      "reported_COVID_deaths": 0.2,
      "excess_deaths_not_captured": 0.8,
      "total_deaths": 1.0
    },
    {
      "name": "Region of the Americas",
      "reported_COVID_deaths": 2.4,
      "excess_deaths_not_captured": 3.2,
      "total_deaths": 5.6
    },
    {
      "name": "Eastern Mediterranean Region",
      "reported_COVID_deaths": 0.3,
      "excess_deaths_not_captured": 1.3,
      "total_deaths": 1.6
    },
    {
      "name": "European Region",
      "reported_COVID_deaths": 17.0,
      "excess_deaths_not_captured": 3.2,
      "total_deaths": 20.2
    },
    {
      "name": "South-East Asia Region",
      "reported_COVID_deaths": 6.1,
      "excess_deaths_not_captured": 0.7,
      "total_deaths": 6.8
    },
    {
      "name": "Western Pacific Region",
      "reported_COVID_deaths": 0.2,
      "excess_deaths_not_captured": 0.0,
      "total_deaths": 0.2
    }
  ]
}
```

Source: Ref. (14)
``````
# World Health Statistics 2023

Monitoring health for the SDGs  
Sustainable Development Goals
``` 

**Image Description:** The image features the title "World Health Statistics 2023" in bold black lettering, accompanied by the subtitle "Monitoring health for the SDGs" in a lighter font. The background consists of a pattern of circles in varying shades of white and gray. The WHO emblem and a logo representing 75 years of health for all are present in the bottom section of the image.
{
  "title": "Crude versus age-standardized excess mortality rate per 100 000 population, WHO regions, 2020–2021",
  "x-axis": "Crude excess death (per 100 000 population)",
  "y-axis": "Age-standardized excess death rate (per 100 000 population)",
  "data": [
    {"point": "African Region", "color": "red"},
    {"point": "Region of the Americas", "color": "orange"},
    {"point": "Eastern Mediterranean Region", "color": "green"},
    {"point": "European Region", "color": "purple"},
    {"point": "South-East Asia Region", "color": "pink"},
    {"point": "Western Pacific Region", "color": "yellow"}
  ]
}

Years of life lost due to excess mortality associated with the COVID-19 pandemic

While excess mortality – as opposed to the deaths reported to be due to COVID-19 – provides a unique lens through which to evaluate the toll of the pandemic, it does not comprehensively account for the impact of each death due to the pandemic on a wide range of social and economic issues. Estimation of years of life lost (YLL), on the other hand, accounts not only for the number of deaths and the age at which death occurs but also the associated loss of a potential number of life-years. YLL estimates show that a total of 336.8 million life-years have been lost globally due to the COVID-19 pandemic in 2020–2021. This means that, on average, each excess death led to a loss of more than 22 years of life – equivalent to over 5 years of life lost per second in 2020–2021.

Globally, YLL associated with the COVID-19 pandemic is negative among ages younger than 25 years, reflecting YLL averted during the pandemic (3.5 million). This is despite the fact that the potential YLL is the highest among this group given the high life expectancy by age in young age groups. YLL by age group is the highest in ages 55–64 years with a total of 90.4 million years (27%) of life lost – due to a combination of a relatively higher excess mortality rate in this age group and much higher potential years of life lost for each death that occurred at this age due to its relatively younger age compared to the deaths in age groups above 65 years. While the age groups beyond 65 years collectively accounted for 64% of the global excess deaths, YLL due to excess mortality accounted for less than half of the global YLL at 43%. Conversely, YLL in ages younger than 45 years accounted for 10% of the global YLL even though excess deaths in the same age group accounted for only 5% of the global total.
```
COVID-19 and global health in the coming decades

With millions of excess deaths attributed to the pandemic globally thus far, COVID-19 stands out as one of the most devastating pandemics in history, and certainly in recent memory. This pandemic highlights the critical importance of early detection and swift response at the global level to contain the rapid spread of the virus. To improve a country's ability in detection and response, sustained investment in public health infrastructure and preparedness in every country in the world is required in order to protect global health. The pandemic also demonstrated the importance of a strong health-care system and universal health-care coverage among countries. For most regions, the level of essential service coverage is negatively associated with lower age-standardized excess mortality rates associated with the COVID-19 pandemic, as was particularly evident among countries of the European and Western Pacific regions. This is evidence that countries that are better equipped and better staffed are well positioned to weather the pandemic and to minimize the mortality toll.

The COVID-19 pandemic also shows how critical close collaboration between countries – with international coordination led by key institutions such as (and particularly) WHO – is in addressing significant global health threats within countries and across national borders. Furthermore, well-coordinated cooperation among regions and countries, and between private and public sectors, helps to ensure equitable distribution of vaccines, sharing of critical information, and distribution of medicines and medical equipment among countries for those in critical need.

The COVID-19 pandemic has highlighted the inequality of access to health-care systems, especially among vulnerable populations and in developing nations. In addition, the pandemic exposed inequity in health emergency preparedness around the world. Much needs to be done, and urgently, by countries and the international community to make sure that more people around the globe have access to health-care services and are protected from health emergencies so that they may enjoy healthier lives.
```
## 1.4 Climate change and health

Climate change is one of the greatest health challenges of the 21st century. As climatic conditions change, we are witnessing more frequent and intensifying weather and climate events, such as storms, extreme heat, floods, droughts and wildfires. These weather and climate hazards affect health both directly and indirectly, increasing the risk of deaths, NCDs, the emergence and spread of infectious diseases, and health emergencies. Climate change is also having an impact on our health workforce and infrastructure, reducing capacity to provide UHC. More fundamentally, climate shocks and growing stresses such as changing temperature and precipitation patterns, drought, floods and rising sea levels degrade the environmental and social determinants of physical and mental health. All aspects of health are affected by climate change – from clean air, water and soil to food systems and livelihoods. Further delay in tackling climate change will increase health risks, undermine decades of improvements in global health, and contravene our collective commitments to ensure the human right to health for all.

### Current and future health risks of climate change

The Sixth Assessment Report of the Intergovernmental Panel on Climate Change estimates that up to 3.6 billion people around the globe live in contexts that are highly vulnerable to the impacts of climate change. Low-income and lower-middle-income countries and small island developing states face the greatest health consequences of climate change, despite contributing the least to historical global emissions. It is estimated that, over the past decade, floods, droughts and storms were 15 times more lethal in highly vulnerable regions than in regions with low vulnerability.

Within countries there can also be large disparities in those most vulnerable to the impacts of climate change. Populations living in poverty, the elderly, women, children, indigenous peoples, outdoor workers, the socially isolated and persons with pre-existing medical conditions are typically at highest risk. Approximately 2 billion people lack access to safe drinking water. Furthermore, there are some 600 million cases of foodborne illness globally. Children under 5 years of age carry 40% of the burden of foodborne diseases, resulting in 125 000 child deaths every year. Extreme weather events and climate-related environmental stressors degrade water and soil safety, increasing the risks of waterborne and foodborne illnesses.

It is estimated that in 2020, between 720 and 811 million people faced hunger, primarily in Africa and Asia. Higher temperatures, rising sea levels and flooding affect all aspects of food and nutrition security. Climate-related reductions in agricultural and marine productivity, biodiversity loss, volatility in food prices and disruptions in food imports further affect the quality, quantity and diversity of food consumed, leading to further food and nutrition crises.

Changing temperature and precipitation patterns are also increasing the susceptibility of conditions for the transmission of mosquito-borne, tick-borne and rodent-borne diseases in many regions. If prevention methods are not strengthened, this could lead to an increase in the over 700 000 deaths from vector-borne diseases each year.

Acute mental health conditions such as anxiety, depression and post-traumatic stress can be experienced following extreme weather events. The cumulative effect of loss of livelihood, displacement, disrupted social cohesion and uncertainty from climate change can also result in long-term mental health disorders, adding to the already large global challenges in mental health.

Estimating the full health burden of climate change is challenging. In 2014, WHO together with leading researchers conducted a quantitative risk assessment of the effects of climate change on selected causes of death. Under a medium-high emissions scenario, it was estimated that by 2030 climate change would cause around 250 000 additional deaths per year. This conservative estimate included only climate-attributable deaths from malaria, heat exposure in older persons, undernutrition and diarrhoeal disease in children, and coastal flood mortality. This assessment recognized that a main limitation of the findings was the inability of existing models to account for major causal pathways that influence a range of health outcomes. By looking at a small subset of causal pathways, however, the assessment clearly established


Build better, more climate-resilient and environmentally sustainable health systems

Building climate-resilient and sustainable health systems involves a systematic and comprehensive approach to strengthening all core functions of a health system so that it can respond and adapt to the health risks of climate change. The 2021 WHO Health and Climate Change Global Survey found that approximately half of countries (48 out of 95) reported having conducted a climate change and health vulnerability and adaptation assessment. Fifty-two per cent (49 out of 95) of countries reported having a national climate change and health strategy or plan in place (Figure 116). However, only a quarter of those countries (11 out of 46) have reached a "high" or "very high" level of implementation. Insufficient finance was a main barrier to implementation of national strategies and plans (Figure 117).

The health sector is responsible for approximately 4–5% of global greenhouse gas emissions (38). Health systems can decarbonize through measures such as sustainable procurement practices, more efficient or renewable energy sources, waste reduction, and optimization of the use of resources, which will contribute to a higher quality of care, greater accessibility, more reliable services, reduced occupational hazards from air pollution and waste, and reduced costs (38,39).

The WHO-led Alliance for Transformative Action on Climate Change and Health (ATACH) was formed in 2022 to support countries in implementing their UNFCCC 26th Conference of Parties (COP26) health programme commitments to build climate-resilient and sustainable health systems. Over 60 countries have committed to this initiative with more countries expected to join (40).

**Figure 116** Countries and areas with a national health and climate change plan or strategy in place, 2021

json
{
  "countries": [
    {"region": "North America", "status": "yes"},
    {"region": "South America", "status": "under development"},
    {"region": "Africa", "status": "no"},
    {"region": "Asia", "status": "unknown"},
    {"region": "Europe", "status": "not a participant"},
    {"region": "Oceania", "status": "not applicable"}
  ]
}
```

Source: Ref. (37)
```

## Main barriers to implementation of national health and climate change plans or strategies, 2021

json
{
  "barriers": [
    {"barrier": "Insufficient finance/budget", "percentage": 70},
    {"barrier": "Insufficient human resource capacity", "percentage": 54},
    {"barrier": "Constraints related to COVID-19", "percentage": 52},
    {"barrier": "Insufficient research and evidence", "percentage": 46},
    {"barrier": "Insufficient technologies, tools and methods", "percentage": 43},
    {"barrier": "Insufficient prioritization or competing priorities", "percentage": 39},
    {"barrier": "Insufficient multistakeholder collaboration", "percentage": 35},
    {"barrier": "Incomplete or lack of comprehensive plan or strategy", "percentage": 9},
    {"barrier": "Lack of endorsement by Ministry of Health", "percentage": 7},
    {"barrier": "Other", "percentage": 7}
  ]
}
```

Protect health from the wide range of impacts of climate change

Countries are facing increasing threats to public health and health systems from climate change. A number of factors, including geography and socioeconomic conditions influence these risks. Countries can assess their individual health vulnerabilities and capacities and develop evidence-based national adaptation plans and interventions. Climate-informed health surveillance and early warning systems and climate-informed health policies and programmes are critical in strengthening the resilience of health systems to growing climate risks.

Given the interconnectedness of natural, economic, social and human systems, action in the health sector alone is not enough to protect human health. As climate change intensifies, a mobilized health community and strong multistakeholder coordination will play critical roles in strengthening evidence, advocacy, policy, and actions to protect the health and well-being of all populations. Ensuring adequate funding through international climate finance and domestic funding will allow health priorities to be mainstreamed into climate change programming and climate considerations to be accounted for in health programming.

Effectively tackling climate change and protecting health requires us to monitor, learn and improve. The interaction between climate change, other determinants, health interventions and health effects is constantly evolving. This calls for integrated monitoring systems across these dimensions, that can be used to improve understanding, track progress and guide health actions.
```
### Box 1.3 Facing the consequences of climate change in the Caribbean

Saint Lucia, a small island developing state in the Caribbean, is highly vulnerable to the health risks posed by climate change. With much of the country's population and economic activity located along the coast, Saint Lucia is particularly vulnerable to extreme weather events and climate stresses. Climate-related health risks to the island's population include injuries and deaths from extreme weather events, vector-borne diseases, waterborne illnesses, food insecurity, heat stress, respiratory illnesses and mental health stresses.

Under a "business as usual" high emissions scenario, the mean annual temperature in Saint Lucia is projected to rise by about 2.9 °C by the end of the century with "hot days" increasing from 23% of all observed days on average in 1981–2010 to over 90% of all days on average in 2071–2100. Increasing mean annual temperature and extreme heat result in a greater number of people at risk of heat-related medical conditions, including heat rash, heat cramps, dehydration, heat stroke and in some cases death.

**Figure 1.18 Percentage of hot days ("heat stress"), Saint Lucia, 1900–2100** 

*Note: The figure presents climate model projections for the percentage of hot days. A “hot day” is a day when the maximum temperature exceeds the 90th percentile threshold for the time of the year. The blue lines represent annual and smoothed observed record. The orange lines represent a high-emission scenario (Representative Concentration Pathway 8.5, RCP8.5) and the green lines represent a low-emission scenario (RCP2.6). The scenarios are presented across some 20 global climate models. The figure shows each model individually, as well as their average and the 90% model range (shaded).*

**Source:** Health and climate change: country profile 2020. Saint Lucia (Online). Geneva: World Health Organization (https://www.who.int/publications/i/item/WHO-HEP-ECH-20.01), accessed 26 April 2023.

Sea level is expected to rise by 0.5–0.6 metres by the end of the century in the Caribbean region. Impacts of the rise in sea level include coastal erosion, ecosystem disruption, higher storm surges, population displacement, and water contamination and disruption.

It is anticipated that tropical cyclones will become more intense due to climate change. Between 1980 and 2010, six major tropical cyclones and three climate-related natural hazards crossed or had effects on Saint Lucia’s Exclusive Economic Zone. In 2010, Hurricane Tomas affected 172 370 people and resulted in damages and losses worth 28.4% of GDP. Damages include disruptions to the functioning of health-care facilities and emergency health services.

Climate change is likely to exacerbate the triple burden of malnutrition as well as the metabolic and lifestyle risk factors for diet-related NCDs. It is expected to reduce short- and long-term food and nutrition security both directly, through its effects on agriculture and fisheries, and indirectly, by contributing to underlying risk factors such as water insecurity, dependency on imported foods, urbanization, migration and health-service disruption.

The Government of Saint Lucia recognizes the threats posed by climate change to health and is committed to building a climate-resilient and sustainable health system. Saint Lucia has conducted a vulnerability and adaptation assessment of the health sector as part of its National Communication to the UNFCCC. The findings of this assessment can inform policy and planning.

In 2022, Saint Lucia developed a Health National Adaptation Plan which outlines its adaptation priorities. Saint Lucia also includes health considerations in its national climate policies. The NDC of Saint Lucia highlights the importance of human health as a key priority for adaptation implementation.

Using the SMART hospitals toolkit, Saint Lucia has assessed 34 health facilities for their structural and operational safety and low-carbon environmental sustainability. As of 2020, three health facilities in Saint Lucia had been designated as SMART health facilities. Expansion of the project to include facilities across the island and plan will aim to ensure that the majority of the population (including women, children and persons with disabilities) can access quality health care in both pre- and post-disaster periods. It is planned that the remaining health facilities will be upgraded to improve safety in service delivery and to ensure they can structurally, non-structurally and functionally withstand climate-related events.

Saint Lucia has also identified the importance of strengthening climate-informed health surveillance and early warning systems to protect populations and to address barriers to accessing finance in order to support health adaptation and mitigation objectives.


# References

1. Trends in maternal mortality 2000 to 2020: estimates by WHO, UNICEF, UNFPA, World Bank Group and UNDESA/Population Division. Geneva: World Health Organization; 2023 (https://www.who.int/publications/i/item/9789240068759, accessed 21 April 2023).

2. Global health estimates 2019: deaths by cause, age, sex, by country and by region, 2000–2019. Geneva: World Health Organization; 2020 (https://www.who.int/data/gho/data/themes/mortality-and-global-health-estimates/, accessed 1 April 2023).

3. World Population Prospects 2022. New York (NY): United Nations, Department of Economic and Social Affairs; 2022 (https://population.un.org/wpp/, accessed 1 April 2023).

4. Levels and trends in child mortality. Report 2022. Estimates developed by the UN Inter-agency Group for Child Mortality Estimation. United Nations Children’s Fund, World Health Organization, World Bank Group and United Nations Population Division. New York: United Nations Children’s Fund; 2023 (https://data.unicef.org/resources/levels-and-trends-in-child-mortality/, accessed 14 April 2023).

5. Perin J, Mulick A, Yeung D, Villavicencio F, Lopez G, Strong KL et al. Global, regional, and national causes of under-5 mortality in 2000–19: an updated systematic analysis with implications for the Sustainable Development Goals. Lancet Child Adolesc Health. 2022;6:106–15. doi:10.1016/S2352-4642(21)00311-4.

6. Global health estimates 2019: disease burden by cause, age, sex, by country and by region, 2000–2019. Global Health Observatory data. Geneva: World Health Organization; 2020 (https://www.who.int/data/gho/data/themes/mortality-and-global-health-estimates/, accessed 24 March 2023).

7. WHO global information system on alcohol and health (GISAH) [online database]. Global Health Observatory data. Geneva: World Health Organization; 2022 (https://www.who.int/data/gho/data/themes/topic-details/GHO/levels-of-consumption/, accessed 11 April 2023).

8. WHO global report on trends in prevalence of tobacco use 2000–2025, fourth edition. Geneva: World Health Organization; 2021 (https://www.who.int/publications/i/item/9789242003932, accessed 4 April 2023).

9. Noncommunicable diseases: risk factors. Global Health Observatory data. Geneva: World Health Organization; 2022 (https://www.who.int/data/gho/data/themes/topic-details/GHO/ncd-risk-factors, accessed 12 April 2023).

10. UNICEF/WHO/World Bank joint malnutrition estimates, 2023. Geneva: World Health Organization (in preparation).

11. WHO Coronavirus (COVID-19) dashboard. Geneva: World Health Organization (https://covid19.who.int/data, accessed 14 April 2023).

12. Msemburi W, Karlinsky A, Knutson V, Aleshin-Guendel S, Chatterji S, Wakefield J. The WHO estimates of excess mortality associated with the COVID-19 pandemic. Nature. 2022;613:130–7. doi.org/10.1038/s41586-022-05522-2.

13. Knutson V, Aleshin-Guendel S, Karlinsky A, Msemburi W, Wakefield J. Estimating global and country-specific excess mortality during the COVID-19 pandemic: an arXiv preprint. 2022. doi.org/10.48550/arXiv.2205.09081.

14. Global excess deaths associated with COVID-19 (modelled estimates) (Database). Geneva: World Health Organization (https://www.who.int/data/sets/global-excess-deaths-associated-with-covid-19-modelled-estimates, accessed 14 April 2023). Methods were developed in collaboration with the Technical Advisory Group on COVID-19 Mortality Assessment in which a set of potential conflicts of interest were declared determining that member's participation would not give rise to a real, potential or apparent conflict of interest. (https://www.who.int/data/technical-advisory-group/covid-19-mortality-assessment/terms-of-reference).

15. Coronavirus disease (COVID-19): post COVID-19 condition. Questions and answers (Online). Geneva: World Health Organization (https://www.who.int/news-room/questions-and-answers/item/coronavirus-disease-(covid-19)-post-covid-19-condition, accessed 14 April 2023).

16. University of Maryland Social Data Science Center Global COVID-19 Trends and Impact Survey, in partnership with Facebook. College Park (MD): University of Maryland (https://covidamp.umd.edu/, accessed 21 April 2023).

17. Bergen R, Kirkby K, Fuertes CV, Schlotheuber A, Menning I, Mac Feely S et al. Global state of education-related inequality in COVID-19 vaccine coverage, structural barriers, vaccine hesitancy, and vaccine refusal: findings from the Global COVID-19 Trends and Impact Survey. Lancet Glob Health. 2023;11(2):e207–17.
```
# World health statistics 2023: monitoring health for the SDGs, Sustainable Development Goals

ISBN 978-92-4-0074-32-3 (electronic version)  
ISBN 978-92-4-0074-33-0 (print version)  

© World Health Organization 2023

Some rights reserved. This work is available under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 IGO licence (CC BY-NC-SA 3.0 IGO; https://creativecommons.org/licenses/by-nc-sa/3.0/igo).

Under the terms of this licence, you may copy, redistribute and adapt the work for non-commercial purposes, provided the work is appropriately cited, as indicated below. In any use of this work, there should be no suggestion that WHO endorses any specific organization, products or services. The use of the WHO logo is not permitted. If you adapt the work, then you must license your work under the same or equivalent Creative Commons licence. If you create a translation of this work, you should add the following disclaimer along with the suggested citation: “This translation was not created by the World Health Organization (WHO). WHO is not responsible for the content or accuracy of this translation. The original English edition shall be the binding and authentic edition”.

Any mediation relating to disputes arising under the licence shall be conducted in accordance with the mediation rules of the World Intellectual Property Organization (http://www.wipo.int/amc/en/mediation/rules/).

Suggested citation:  
World health statistics 2023: monitoring health for the SDGs, Sustainable Development Goals. Geneva: World Health Organization; 2023. Licence: CC BY-NC-SA 3.0 IGO.

Catalogue-in-Publication (CIP) data. CIP data are available at http://apps.who.int/irs.

Sales, rights and licensing. To purchase WHO publications, see https://www.who.int/publications/book-orders. To submit requests for commercial use and queries on rights and licensing, see https://www.who.int/copyright.

Third-party materials. If you wish to reuse material from this work that is attributed to a third party, such as tables, figures or images, it is your responsibility to determine whether permission is needed for that reuse and to obtain permission from the copyright holder. The risk of claims resulting from infringement of any third-party-owned component in the work rests solely with the user.

General disclaimers. The designations employed and the presentation of the material in this publication do not imply the expression of any opinion whatsoever on the part of WHO concerning the legal status of any country, territory, city or area or of its authorities, or concerning the delimitation of its frontiers or boundaries. Dotted and dashed lines on maps represent approximate border lines for which there may not yet be full agreement.

The mention of specific companies or of certain manufacturers’ products does not imply that they are endorsed or recommended by WHO in preference to others of a similar nature that are not mentioned. Errors and omissions excepted, the names of proprietary products are distinguished by initial capital letters.

All reasonable precautions have been taken by WHO to verify the information contained in this publication. However, the published material is being distributed without warranty of any kind, either expressed or implied. The responsibility for the interpretation and use of the material lies with the reader. In no event shall WHO be liable for damages arising from its use.

Design and layout: Agence Gardeners (Annecy)

Photo credits: Page 1 - WHO / Michael Duff; Page 33 - WHO / Karen Reidy; Page 71 - WHO / Alasdair Bell
```
18. Pörtner H-O, Roberts DC, Poloczanska ES, Mintenbeck K, Tignor M, Alegría A et al., editors. IPCC, 2022: Summary for policymakers. In: Pörtner H-O, Roberts DC, Tignor M, Poloczanska ES, Mintenbeck K, Alegría A et al. Climate change 2022: impacts, adaptation, and vulnerability. Contribution of Working Group II to the Sixth Assessment Report of the Intergovernmental Panel on Climate Change. Cambridge and New York (NY): Cambridge University Press. [Link](https://www.ipcc.ch/report/ar6/wg2/ downloads/report/IPCC_AR6_WGII_SummaryForPolicymakers.pdf), accessed 11 May 2023.

19. COP24 special report: health and climate change. Geneva: World Health Organization; 2018 [Link](https://www.who.int/publications/i/item/9789241514972), accessed 19 April 2023.

20. Public health and environment [online database]. Global Health Observatory data. Geneva: World Health Organization [Link](https://www.who.int/data/gho/data/themes/public-health-and-environment), accessed 9 April 2023.

21. Food and Agriculture Organization, International Fund for Agricultural Development, United Nations Children’s Fund, World Food Programme, World Health Organization; 2021. The State of Food Security and Nutrition in the World 2021. Transforming food systems for food security, improved nutrition and affordable healthy diets for all. Rome: Food and Agriculture Organization of the United Nations; 2021. [Link](http://doi.org/10.4060/cb447en).

22. Vector-borne diseases. Fact sheet. Geneva: World Health Organization; 2020 [Link](https://www.who.int/news-room/fact-sheets/ detail/vector-borne-diseases), accessed 20 June 2022.

23. Mental health and climate change. Policy brief. Geneva: World Health Organization; 2022 [Link](https://www.who.int/publications/i/item/9789240405125), accessed 19 April 2023.

24. Quantitative risk assessment of the effects of climate change on selected causes of death, 2030s and 2050s. Geneva: World Health Organization; 2014 [Link](https://www.who.int/publications/i/item/9789241507691), accessed 17 April 2023.

25. WHO UNFCCC Health and Climate Change Country Profiles 2015–2023. (online)[Website]. Geneva: World Health Organization [Link](https://www.who.int/teams/environment-climate-change-and-health/climate-change-and-health/evidence-monitoring/ country-profiles), accessed 19 April 2023.

26. Ebi K, Åström C, Boyer C, Harrington L, Hess J, Honda Y et al. Using detection and attribution to quantify how climate change is affecting health. Health Aff. 2020;39(12):2168–74. doi:10.1377/hlthaff.2020.01040.

27. Pörtner H-O, Roberts DC, Adams H, Adelekan I, Adler C, Adrian R et al., editors. IPCC, 2022: Technical summary. In: Pörtner H-O, Roberts DC, Tignor M, Poloczanska ES, Mintenbeck K, Alegría A et al. Climate change 2022: impacts, adaptation, and vulnerability. Contribution of Working Group II to the Sixth Assessment Report of the Intergovernmental Panel on Climate Change. Cambridge and New York (NY): Cambridge University Press [Link](https://www.ipcc.ch/report/ar6/wg2/downloads/report/ IPCC_AR6_WGII_TechnicalSummary.pdf), accessed 11 May 2023.

28. Masson-Delmotte V, Zhai P, Pirani A, Connors SL, Péan C, Berger S et al., editors. IPCC, 2021: Summary for policymakers. In: Climate change 2021: the physical science basis. Contribution of Working Group I to the Sixth Assessment Report of the Intergovernmental Panel on Climate Change. Cambridge University Press, Cambridge, United Kingdom and New York (NY); 2021. doi:10.1017/9781009157896.001.

29. State of the Global Climate 2021. Geneva: World Meteorological Organization; 2022 [Link](https://public.wmo.int/en/our-mandate/ climate/wmo-statement-state-of-global-climate), accessed 19 April 2023.

30. Paris Agreement. Bonn: United Nations Framework Convention on Climate Change; 2015 [Link](https://unfccc.int/sites/default/ files/english_paris_agreement.pdf), accessed 19 April 2023.

31. Emissions Gap Report 2022: The closing window: climate crisis calls for rapid transformation of societies. Nairobi: United Nations Environment Programme; 2022 [Link](https://www.unep.org/resources/emissions-gap-report-2022), accessed 17 April 2023.

32. Hamilton I, Kennard H, McGushin A, Höglund-Isaksson L, Kiesewetter G, Lott M et al. The public health implications of the Paris Agreement: a modelling study. Lancet Planet Health. 2021;5(2):e74–83. doi.org/10.1016/S2542-5196(20)30249-7.

33. Markandy A, Sampedro J, Smith SJ, Van Dingenen R, Pizarro-Irizar C, Arto I et al. Health co-benefits from air pollution and mitigation costs of the Paris Agreement: a modelling study. Lancet Planet Health. 2021;2:e126–33.

34. Romanello M, McGushin A, Napoli C, Drummond P, Hughes H, Jarnart L et al. The 2021 report of the Lancet Countdown on health and climate change: code red for a healthy future. Lancet 2021;398:1619–62. Published online 20 October 2021. doi:10.1016/S0140-6736(21)01787-6.

### Markdown Conversion


35. Lee H, Calvin K, Dasgupta D, Krinner G, Mukherji A, Thorne P et al. IPCC, 2023: Summary for policymakers. In: Sixth Assessment Report of the Intergovernmental Panel on Climate Change. Synthesis report. (https://www.ipcc.ch/report/ar6/syr/downloads/ report/IPCC_AR6_SYR_SPM.pdf, accessed 17 April 2023).

36. Review of health in the nationally determined contributions (NDCs). Geneva: World Health Organization (in press).

37. WHO health and climate change global survey report. Geneva: World Health Organization; 2021 (https://www.who.int/ publications/i/item/97892404038509, accessed 19 April 2023).

38. Global road map for health care decarbonization: a navigational tool for achieving zero emissions with climate resilience and health equity (website). Health care Without Harm. (https://healthcareclimateaction.org/roadmap, accessed 19 April 2023).

39. WHO guidance for climate-resilient and environmentally sustainable health care facilities. Geneva: World Health Organization; 2020 (https://www.who.int/publications/i/item/9789240012226, accessed 19 April 2023).

40. Alliance for Transformative Action on Health and Climate Change (ATACH) (website). Geneva: World Health Organization (https://www.who.int/initiatives/alliance-for-transformative-action-on-climate-and-health, accessed 19 April 2023).

41. Supporting countries to protect human health from climate change: package of technical support (website). Geneva: World Health Organization (https://www.who.int/teams/environment-climate-change-and-health/climate-change-and-health/countrysupport#cms, accessed 19 April 2023).


### Notes
- There were no tables or images provided in the text to convert, so I focused on the text content.
- All headers and footers have been ignored as per your instructions.
# 02.
Summary status of the health-related SDGs and GPW 13 indicators

![Image content description cannot be provided as it contains identifiable people and requires specific context to accurately describe.]

# World Health Statistics 2023 – Monitoring Health for the SDGs

## 2.1 Infectious Diseases

Infectious diseases are primarily reflected in SDG target 3.3 which includes the indicators for HIV, tuberculosis (TB), malaria, viral hepatitis and neglected tropical diseases (NTDs). This section summarizes the current status of these indicators as well as the GPW 13 indicators on antimicrobial resistance and poliomyelitis caused by wild poliovirus (WPV).

### HIV

In June 2021, the UN General Assembly adopted the Political Declaration on HIV and AIDS: Ending Inequalities and Getting on Track to End AIDS by 2030. The core targets require a decrease in annual global new HIV infections to less than 370 000 and HIV-related deaths to fewer than 250 000 by 2025. Latest data available show that despite service disruptions caused by the global COVID-19 pandemic, new HIV infections and HIV-related deaths continued to decline — though not for everyone and not everywhere (1).

In 2021, there were 15 (UI: 11–20) million new HIV infections globally. This represents a decline of 32% in new HIV infections compared to 2010. The incidence rate (new infections per 1000 uninfected population) declined from 0.32 (UI: 0.24–0.43) in 2010 to 0.19 (UI: 0.15–0.26) in 2021. Across all WHO regions, progress has been strongest in the region with the largest HIV burden, the African Region, with a reduction in the incidence rate of 58% between 2010 and 2021. In western and central Africa, there was a remarkable drop of incidence rates within just one year, from 0.38 (UI: 0.27–0.54) in 2020 to 0.31 (UI: 0.22–0.45) in 2021. In the South-East Asia Region and the Region of the Americas, the incidence rates have decreased since 2010, whereas in the Eastern Mediterranean Region and European Region, the incidence rate has increased since 2010.

Certain subpopulations are at a higher risk of HIV infections. Progress is slower in regions where most new infections occur in key populations that are subject to criminalization, violence and social exclusion. Multiple vulnerabilities – including harmful social norms, and social, economic and gender inequalities – continue to put women and adolescent girls in the African Region at heightened risk of HIV infection.

The increasing availability of subnational data is enabling countries and subnational jurisdictions to implement locally differentiated approaches that direct limited resources towards places and populations in greatest need of HIV services. 

Scale-up of HIV testing and access to antiretroviral therapy, especially for adults, has transformed the global AIDS response. However, children are markedly less likely than adults to be diagnosed with HIV, to receive antiretroviral therapy and to achieve viral suppression. In 2021, children (aged 0–14 years) accounted for 4% of all people living with HIV but for 15% of all HIV-related deaths.
## Figure 2.1 New HIV infections (per 1000 uninfected population), by WHO region and global, 2000–2021

### a. WHO regions (excluding Africa) and global

json
{
  "data": {
    "years": [2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021],
    "values": {
      "Region of the Americas": [0.4, 0.38, 0.32, 0.31, 0.29, 0.26, 0.25, 0.23, 0.21, 0.2, 0.19, 0.18, 0.17, 0.16, 0.15, 0.14, 0.12, 0.11, 0.1, 0.09, 0.08, 0.07],
      "Eastern Mediterranean Region": [0.2, 0.19, 0.17, 0.16, 0.15, 0.14, 0.13, 0.12, 0.11, 0.1, 0.09, 0.08, 0.07, 0.06, 0.05, 0.04, 0.03, 0.03, 0.02, 0.02, 0.02, 0.02],
      "European Region": [0.2, 0.18, 0.16, 0.15, 0.14, 0.13, 0.11, 0.1, 0.1, 0.09, 0.08, 0.08, 0.07, 0.07, 0.06, 0.05, 0.05, 0.04, 0.04, 0.03, 0.03, 0.03],
      "South-East Asia Region": [0.2, 0.19, 0.18, 0.17, 0.16, 0.15, 0.14, 0.13, 0.12, 0.11, 0.1, 0.08, 0.07, 0.06, 0.05, 0.04, 0.03, 0.03, 0.02, 0.02, 0.02, 0.02],
      "Western Pacific Region": [0.1, 0.1, 0.09, 0.09, 0.08, 0.07, 0.07, 0.06, 0.05, 0.04, 0.04, 0.03, 0.03, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.01, 0.01, 0.01],
      "Global": [0.3, 0.29, 0.28, 0.26, 0.25, 0.24, 0.23, 0.22, 0.21, 0.2, 0.19, 0.18, 0.17, 0.16, 0.15, 0.14, 0.12, 0.11, 0.1, 0.09, 0.08, 0.07]
    }
  }
}
```

### b. WHO African Region, eastern and southern Africa, western and central Africa and global

```json
{
  "data": {
    "years": [2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021],
    "values": {
      "African Region": [6, 5.8, 5.6, 5.4, 5.2, 5, 4.8, 4.5, 4.3, 4.2, 4, 3.8, 3.6, 3.4, 3.2, 3, 2.8, 2.6, 2.4, 2.2, 2, 1.8],
      "Eastern and Southern Africa": [5.5, 5.3, 5, 4.8, 4.6, 4.4, 4.2, 4, 3.8, 3.6, 3.4, 3.2, 3, 2.8, 2.6, 2.4, 2.2, 2, 1.8, 1.6, 1.4, 1.2],
      "Western and Central Africa": [4, 3.9, 3.8, 3.7, 3.5, 3.4, 3.3, 3.2, 3, 2.8, 2.6, 2.5, 2.4, 2.3, 2.2, 2, 1.8, 1.6, 1.4, 1.2, 1, 0.8],
      "Global": [0.3, 0.29, 0.28, 0.26, 0.25, 0.24, 0.23, 0.22, 0.21, 0.2, 0.19, 0.18, 0.17, 0.16, 0.15, 0.14, 0.12, 0.11, 0.1, 0.09, 0.08, 0.07]
    }
  }
}
```
```
Antimicrobial resistance

Antimicrobial resistance (AMR) represents a serious global public health threat with significant global economic and security implications. One of the main drivers of drug resistance is the excessive or inappropriate use of antimicrobials in people, but also in animals and plants, especially those used for food production. Antimicrobial-resistant organisms are also found in the environment (in water, soil and air).

Launched by WHO in 2015, the Global Antimicrobial Resistance and Use Surveillance System (GLASS) is the first system that enables harmonized global reporting of official national AMR and antimicrobial consumption (AMC) data. GLASS also informs the AMR indicator reported to the SDG monitoring framework (3.d.2), which monitors the proportion of bloodstream infections (BSIs) among patients seeking care due to methicillin-resistant Staphylococcus aureus (MRSA) and Escherichia coli resistant to third-generation cephalosporins.

Considering settings reporting at least 10 BSIs with antimicrobial susceptibility test results (AST) in 2020, the median proportion of BSIs due to E. coli resistant to third-generation cephalosporins and the median proportion of BSIs due to MRSA in 76 countries were 4.81% (IQR: 1.81–64.3) and 34.7% (IQR: 12.4–50.4), respectively. These rates were much lower – 10.6% (IQR: 8.6–14.9) and 6.83% (IQR: 2.27–17.4) respectively – in 19 countries with better testing coverage (i.e. where the number of BSIs with AST per million population was above the 75th percentile).

To provide global evidence on how antimicrobials are used over time, facilitate comparisons among countries and inform strategies to improve access to – and optimize the use of – antimicrobials, GLASS collects national annual data to measure the countries’ antimicrobial consumption. GLASS also informs the GPW T3 Target 4b indicator “Pattern of antibiotic consumption at national level.” In this indicator, the consumption of antibiotics is expressed by AWaRe categories with aim of increasing the use of Access group antibiotics, which include antibiotics recommended as first- and second-line therapy for common infectious disease. The GPW T3 4b target is that ≥60% of total antibiotic consumption will be “Access” group antibiotics. In 2020, this target was met in 15 out of 19 reporting countries.

Figure 2.3 Percent of antibiotic consumption at national level (relative consumption by AWaRe classification), by country, 2020

json
{
  "table": [
    {
      "country": "Benin",
      "percentage_access": 70,
      "percentage_watch": 20,
      "percentage_reserve": 10,
      "percentage_not_classified": 0
    },
    {
      "country": "Côte d'Ivoire",
      "percentage_access": 80,
      "percentage_watch": 15,
      "percentage_reserve": 5,
      "percentage_not_classified": 0
    },
    {
      "country": "Gabon",
      "percentage_access": 60,
      "percentage_watch": 20,
      "percentage_reserve": 15,
      "percentage_not_classified": 5
    },
    {
      "country": "Uganda",
      "percentage_access": 50,
      "percentage_watch": 30,
      "percentage_reserve": 10,
      "percentage_not_classified": 10
    },
    {
      "country": "Colombia",
      "percentage_access": 70,
      "percentage_watch": 20,
      "percentage_reserve": 5,
      "percentage_not_classified": 5
    },
    {
      "country": "Peru",
      "percentage_access": 80,
      "percentage_watch": 10,
      "percentage_reserve": 5,
      "percentage_not_classified": 5
    },
    {
      "country": "Egypt",
      "percentage_access": 65,
      "percentage_watch": 25,
      "percentage_reserve": 5,
      "percentage_not_classified": 5
    },
    {
      "country": "Iran (Islamic Republic of)",
      "percentage_access": 30,
      "percentage_watch": 50,
      "percentage_reserve": 15,
      "percentage_not_classified": 5
    },
    {
      "country": "Jordan",
      "percentage_access": 60,
      "percentage_watch": 25,
      "percentage_reserve": 10,
      "percentage_not_classified": 5
    },
    {
      "country": "Belgium",
      "percentage_access": 65,
      "percentage_watch": 25,
      "percentage_reserve": 5,
      "percentage_not_classified": 5
    },
    {
      "country": "Germany",
      "percentage_access": 70,
      "percentage_watch": 20,
      "percentage_reserve": 5,
      "percentage_not_classified": 5
    },
    {
      "country": "Denmark",
      "percentage_access": 80,
      "percentage_watch": 15,
      "percentage_reserve": 5,
      "percentage_not_classified": 0
    },
    {
      "country": "United Kingdom of Great Britain and Northern Ireland",
      "percentage_access": 60,
      "percentage_watch": 30,
      "percentage_reserve": 5,
      "percentage_not_classified": 5
    },
    {
      "country": "Sweden",
      "percentage_access": 75,
      "percentage_watch": 20,
      "percentage_reserve": 5,
      "percentage_not_classified": 0
    },
    {
      "country": "Bhutan",
      "percentage_access": 40,
      "percentage_watch": 30,
      "percentage_reserve": 20,
      "percentage_not_classified": 10
    },
    {
      "country": "Democratic Republic of the Congo",
      "percentage_access": 55,
      "percentage_watch": 25,
      "percentage_reserve": 15,
      "percentage_not_classified": 5
    },
    {
      "country": "Lao People's Democratic Republic",
      "percentage_access": 45,
      "percentage_watch": 25,
      "percentage_reserve": 20,
      "percentage_not_classified": 10
    },
    {
      "country": "Mongolia",
      "percentage_access": 50,
      "percentage_watch": 30,
      "percentage_reserve": 15,
      "percentage_not_classified": 5
    }
  ]
}
```
```
### Tuberculosis

Before the COVID-19 pandemic hit, tuberculosis (TB) was the top cause of death from a single infectious agent worldwide. It is also the leading killer of people with HIV and a major cause of deaths related to antimicrobial resistance. The COVID-19 pandemic has had a negative impact on access to TB diagnosis and treatment in many countries, in turn resulting in global increases in the burden of TB disease. The 2025 milestones of WHO's End TB Strategy are a 50% reduction in the TB incidence rate (2015–2025) and a 75% reduction in the number of TB deaths (2015–2025). These global targets are currently not on track.

The most obvious and immediate impact of disruptions caused by the COVID-19 pandemic globally was a large fall in the number of people newly diagnosed with TB and reported (i.e. officially notified), due to reduced provision of TB services. Between 2019 and 2020 the number diagnosed fell by 18%, (from 71 million to 58 million), reversing a steady increase between 2017 and 2019. There was a partial recovery in 2021 – to 6.4 million (returning to the level of 2016–2017).

In 2021, an estimated 10.6 million people (UI: 9.9–11.0 million) fell ill with TB, representing an increase of 4.5% from 10.1 million (UI: 9.5–10.7 million) in 2020. The global TB incidence rate rose by 3.6% between 2020 and 2021, reversing declines of about 2% per year for most of the previous two decades. The net reduction from 2015 to 2021 was 10%, only one fifth of the way to the 2025 milestones of WHO’s End TB Strategy. At regional level, the TB incidence rate increased between 2020 and 2021 in all WHO regions except for the African Region. In 2021, there were an estimated 14 million (UI: 13.5–15.1 million) deaths among HIV-positive people, and 187,000 (UI: 158,000–218,000) among HIV-negative people for a combined total of 16 million. The estimated number of deaths from TB increased in 2020 and 2021, reversing years of decline between 2005 and 2019. The net reduction in the number of people dying from TB between 2015 and 2021 was only 5.9%, less than one tenth of the way to the 2025 milestone of the End TB Strategy.

Enhanced efforts are urgently needed to mitigate and reverse the negative impacts of the COVID-19 pandemic on TB. The need for action has become even more pressing in the context of war in Ukraine, ongoing conflicts in other parts of the world, a global energy crisis and associated risks to food security, which are likely to worsen some of the broader determinants of TB.


# Contents

- Foreword
- Abbreviations and acronyms
- Introduction
- Key messages

## 01. Key issues and trends in global health
1.1 Trends in maternal and child mortality  
1.2 Noncommunicable diseases and major risk factors  
1.3 Assessing the impact of the COVID-19 pandemic, 2020–2021  
1.4 Climate change and health  

## 02. Summary status of the health-related SDGs and GPW 13 indicators
2.1 Infectious diseases  
2.2 Child malnutrition and anaemia among women  
2.3 Injuries and violence  
2.4 Environmental risks  
2.5 Universal health coverage and health systems  

## 03. Building on past achievements to prepare for the next stage of global health
3.1 Improvements in overall population health over the last seven decades  
3.2 Rapid epidemiological transitions shifting disease burdens in recent decades  
3.3 Driving factors for the transition and WHO's contribution  
3.4 Implications for the next stage of global health  

Annex 1. Country, area, WHO region and global health statistics  
Annex 2. Regional groupings  
```
## Leveraging timely surveillance to support tuberculosis service recovery during the COVID-19 pandemic in Zambia

TB is one of the leading causes of morbidity and mortality in Zambia, especially for people living with HIV. Timely detection, linkage to care and adherence to the TB treatment regimen are critical to achieving successful treatment outcomes, controlling the spread of disease and preventing the development of drug resistance in TB.

Disruptions to the provision of, and access to, TB services caused by the response to the coronavirus disease (COVID-19) pandemic had a major negative impact on people with TB in Zambia.

When Zambia reported its first case of COVID-19 on 18 March 2020, it was not surprising that TB services were rapidly affected. TB case notifications, which averaged 3288 during the first quarter of 2020, fell to an average of 2643 (a 19.6% reduction) in the second quarter of 2020, as the number of confirmed COVID-19 cases began to rise in the country and disease containment measures were put into place.

The Ministry of Health, with technical support from WHO, responded by establishing closer monitoring through the following actions:

- Weekly performance targets for TB services were established, including notifications of both drug-susceptible and drug-resistant TB at the national, provincial and district levels.
- Key performance indicators were summarized for weekly performance targets and were shared with all districts before virtual discussions for validation and analysis and to prompt further action and response. The weekly virtual meetings tracked progress against set targets, and both identified and addressed emerging challenges to the TB response.

Where data revealed gaps, district and provincial officers were encouraged to discuss challenges and identify solutions. High-performing districts and provinces were given the opportunity to share best practices through webinars and in-person workshops, and low-performing districts shared their challenges and identified the support they needed. All districts implemented best practices in case-finding.

Notifications of TB increased consistently afterwards, resulting in the notification of more cases in 2020 (a 7.5–10.8% increase) than in 2019, 2018 and 2017. Using real-time surveillance, Zambia demonstrated that it was possible to adapt to the challenges of the pandemic and to improve essential health services to levels exceeding pre-pandemic ones. It is worth noting that Zambia has increased domestic funding to fight TB sevenfold since 2013.

WHO promoted the use of real-time data and indicators to monitor the impact of the COVID-19 pandemic on both TB services and the country’s response. As of August 2021, 130 countries and territories reported having in place a digital, case-based TB surveillance system.

In the WHO African Region, the COVID-19 pandemic has had some impact on the provision of and access to essential TB services, the number of people diagnosed with TB and notified as TB cases through national disease surveillance systems, and the TB disease burden (incidence and mortality). One of the most widely available indicators that can be used to assess the impact of COVID-19 related disruptions on essential TB services at regional and country levels is the number of notifications of people diagnosed with TB. This indicator reflects impacts on access to diagnosis and treatment on both the supply side (e.g. capacity to continue to provide services) and the demand side (e.g. ability to seek care in the context of restrictions on movement, concerns about the risks of going to health care facilities during a pandemic, and stigma associated with similarities in symptoms related to TB and COVID-19). The African Region is home to 17 of the 30 countries globally that have the highest burden of TB. The WHO Regional Office for Africa has supported countries to adapt to the COVID-19 context, with all countries having the continuity of essential health services as a key pillar of the response to the COVID-19 pandemic in their strategy.


## Deaths

| Country                         | Percentage |
|---------------------------------|------------|
| Nigeria                         | 31.3%      |
| Uganda                          | 3.2%       |
| Mali                            | 3.4%       |
| Burkina Faso                   | 34.6%      |
| Mozambique                     | 3.8%       |
| Niger                           | 3.9%       |
| United Republic of Tanzania     | 4.1%       |
| Democratic Republic of the Congo | 12.6%      |
| Côte d'Ivoire                   | 2.4%       |
| Angola                          | 2.4%       |
| Cameroon                        | 2.3%       |
| Ghana                           | 2.0%       |
| Chad                            | 2.0%       |
| Kenya                           | 1.7%       |
| Benin                           | 1.7%       |
| Madagascar                      | 1.6%       |
| Guinea                          | 1.6%       |
| Ethiopia                        | 1.5%       |
| Sierra Leone                    | 1.4%       |
| Zambia                          | 1.4%       |
| Sudan                           | 1.2%       |
| Mali                            | 1.2%       |
| India                           | 1.2%       |
| South Sudan                     | 0.9%       |
| Central African Republic        | 0.8%       |
| Senegal                         | 0.6%       |
| Liberia                         | 0.6%       |
| Togo                            | 0.6%       |
| Others                          | 3.7%       |

---
**Hepatitis B**

In 2016, the World Health Assembly endorsed the Global Health Sector Strategy on viral hepatitis which calls for the elimination of viral hepatitis as a public health threat by 2030. In 2022, the Seventy-fifth World Health Assembly noted a new set of integrated global health sector strategies on HIV, viral hepatitis and sexually transmitted infections for the period 2022–2030 that would aim to achieve this goal. Progress is measured by a set of global targets and milestones for 2025 and 2030. 

Globally in 2019, 296 million people were living with chronic hepatitis B (defined as hepatitis B surface antigen positive) – which included 15 million new infections – and resulted in approximately 820,000 deaths, mainly from cirrhosis and primary liver cancer.

In addition to the goal of reducing the number of annual new hepatitis B infections to 170,000 new cases and mortality to 310,000 deaths by 2030, another important target is to reduce the prevalence of hepatitis B surface antigen (HBsAg) to below 0.1% in children aged 5 years.

The latest available data show that the HBsAg prevalence among children under 5 years was 0.94% (UI: 0.82–1.06) globally in 2020. Prevalence is lowest in the Region of the Americas at 0.07% (UI: 0.05–0.13) and highest in the WHO African Region at 2.53% (UI: 2.10–3.07).

Efforts to achieve the 2030 target include early diagnosis and treatment of persons living with hepatitis B, a timely birth dose of hepatitis vaccine to prevent vertical transmission from mother to child, and hepatitis B vaccine coverage among children (third dose).
```
## 2.2 Child malnutrition and anaemia among women

Malnutrition refers to deficiencies or excesses in nutrient intake, the imbalance of essential nutrients or impaired nutrient utilization. All countries are affected by one or more forms of malnutrition. This section discusses the SDG indicators on malnutrition among children under 5 years of age and anaemia among women aged 15–19 years.

### Child malnutrition

Adequate nutrition is fundamental to child development, especially in early life. When feeding practices are not optimal, children may suffer from stunting (low height for age), wasting (low weight for height) or overweight (high weight for height).

Global efforts to address child malnutrition are having an effect and there have been remarkable reductions in the prevalence and number of children affected by stunting in the past two decades (Figure 2.7).

### Figure 2.7

Global percentage and number of children under 5 years of age affected by stunting, wasting and overweight, 2000–2022

json
{
  "data": [
    {
      "year": 2000,
      "prevalence": 33.0,
      "number_millions": 33.0
    },
    {
      "year": 2005,
      "prevalence": 35.5,
      "number_millions": 35.5
    },
    {
      "year": 2010,
      "prevalence": 36.2,
      "number_millions": 36.2
    },
    {
      "year": 2015,
      "prevalence": 38.0,
      "number_millions": 38.0
    },
    {
      "year": 2022,
      "prevalence": 37.0,
      "number_millions": 37.0
    }
  ]
}
```

Source: Ref. (22).
```
# Anaemia in women aged 15–49 years

Anaemia is an indicator of both poor nutrition and poor health, having significant adverse health consequences for women and their children. Severe anaemia during pregnancy increases the risk of maternal and perinatal mortality, low birth weight, and poor growth and development in babies. Anaemia can also affect social and economic development as it causes fatigue and lowered productivity.

Although the global prevalence of anaemia in women aged 15–49 years decreased slightly from 2000 [31.2% (UI: 287–34.1)] to 2019 [29.9% (UI: 270–32.8)], the total number affected increased considerably due to population growth – from 492.9 million in 2000 to 570.8 million in 2019. Prevalence was higher among pregnant women [36.5% (UI: 34.0–39.1)] than non-pregnant women [29.6% (UI: 26.2–32.5)]. Globally, the prevalence of mild anaemia increased slightly from 15.5% (UI: 14.2–17.3) in 2000 to 16.2% (UI: 14.9–17.6) in 2019, while moderate anaemia declined slightly from 14.1% (UI: 12.4–16.1) in 2000 to 12.7% (UI: 10.6–14.8) in 2019, as did severe anaemia.

Across WHO regions, there were declines in the prevalence of total anaemia during the MDG era, but these either slowed or halted after 2015. Between 2000 and 2019, in the WHO Western Pacific Region, anaemia prevalence fell from 22.6% (UI: 16.3–30.4) to 16.9% (UI: 114–23.5), in the African Region it fell from 46.3% (UI: 42.5–50.4) to 40.4% (UI: 367–44.2) and in the Region of the Americas from 19.2% (UI: 161–22.5) to 15.4% (UI: 121–19.5). The prevalence of anaemia continued to be highest in the South-East Asia Region, 46.6% (UI: 39.4–53.1) in 2019. Mild anaemia prevalence slightly increased in the South-East Asia Region from 21% (UI: 191–22.8) in 2000 to 23.5% (UI: 206–26.0) in 2019 and in the Eastern Mediterranean Region from 18.4% (UI: 16.3–20.7) to 19.6% (UI: 16.5–22.6). In the same period, moderate and severe anaemia declined in all WHO regions.

### Figure 2.9 Global prevalence of anaemia by severity levels in women aged 15–49 years, 2000–2019

```json
{
  "year": [
    2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009,
    2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019
  ],
  "severe_anaemia": [
    15.5, 14.1, 1.7, null, null, null, null, null, null, null, 
    null, null, null, null, null, null, null, null, null, null
  ],
  "moderate_anaemia": [
    null, null, null, null, null, null, null, null, null, null, 
    null, null, null, null, null, null, null, null, 12.2, 12.7
  ],
  "mild_anaemia": [
    null, null, null, null, null, null, null, null, null, null, 
    null, null, null, null, null, null, null, null, 1.1, 1.0
  ]
}
```

**Note:** *Mild anaemia is defined as haemoglobin concentrations of 110–119 g/L in non-pregnant women, and concentrations of 100–109 g/L in pregnant women; moderate anaemia is defined as haemoglobin concentrations of 80–109 g/L in non-pregnant women and 70–99 g/L in pregnant women; and severe anaemia is defined as haemoglobin concentration below 80 g/L in non-pregnant women and below 70 g/L in pregnant women.* 

**Source:** Ref. (23).
Burden of multiple forms of malnutrition

In many countries, several factors influence the nutritional status in children under 5 years of age; extremes of malnutrition may coexist with high prevalence of stunting, overweight and obesity at the same time. In addition, high prevalence of anaemia may also be present.

Nutrition interventions should be comprehensive in order to reach the multiple burdens of malnutrition. Figure 2.10 is based on an analysis of countries with published estimates for all four SDG indicators: wasting, stunting and overweight in children under 5 years of age, and anaemia in women aged 15–49 years.

### Figure 2.10: Number of countries affected by high prevalence of multiple forms of malnutrition in 2022

json
{
    "data": {
        "Wasting": {
            "only_wasting": 3,
            "stunting_and_wasting": 2,
            "stunting_only": 1,
            "crossed_threshold": 1
        },
        "Stunting": {
            "only_stunting": 21,
            "wasting_and_stunting": 3,
            "stunting_and_anaemia": 1,
            "crossed_threshold": 21
        },
        "Overweight": {
            "only_overweight": 16,
            "crossed_threshold": 16
        },
        "Anaemia": {
            "only_anaemia": 7,
            "stunting_and_anaemia": 6,
            "wasting_and_anaemia": 3,
            "crossed_threshold": 7
        },
        "Intersection": {
            "stunting_overweight": 2,
            "only_stunting_and_overweight": 1,
            "other_intersections": 17
        }
    }
}
```

**Note:** For wasting, only countries with data from 2012 onwards were considered. The thresholds used were ≥ 10% for wasting, ≥ 20% for stunting, ≥ 10% for overweight in children under 5 years of age and ≥ 40% for anaemia in women aged 15–49 years.
```
Foreword

In the two decades prior to the COVID-19 pandemic, the world achieved remarkable advances in health. From 2000 to 2019, global life expectancy increased from 67 years to 73 years, due primarily to the fall in child and maternal mortality and the decline in incidence and mortality from many infectious diseases. Expansions in access to health and related services, including improvements in prevention and treatment for non-communicable diseases, was also a significant factor.

However, even before the COVID-19 pandemic, beginning in 2015, progress against many global health indicators had slowed or stagnated. The pandemic set things back even further, overwhelming health systems and badly disrupting essential health services. The pandemic is estimated to have resulted in nearly 15 million excess deaths in 2020 and 2021. Inequalities both within and between countries persist, as the most vulnerable populations face elevated risks of illness and death from preventable conditions. The unfolding climate crisis also presents significant risks to health, particularly for the most vulnerable populations. For the world to attain the targets of the Sustainable Development Goals (SDGs) by 2030, a substantial increase in focus and investment – of both financial and political capital – is essential.

The World health statistics 2023 documents successes and challenges in public health, with a focus on the SDG indicators and trends. To meet the SDG targets by 2030, it is imperative to accelerate progress. As evident from the country success stories highlighted in this report, acceleration is possible.

The world must heed the lessons of the last two decades, including the tragic events of the pandemic years. One of the most important of those is the knowledge that we have it in our power to avoid unnecessary deaths and illness, and create stronger, more equitable and resilient health systems and societies.

Dr Tedros Adhanom Ghebreyesus  
Director-General  
World Health Organization
```
## 2.3 Injuries and violence

Global death rates due to injuries declined by 20% during the period 2000–2019 – from 717 (UI: 538–93.8) deaths per 100 000 population to 574 (UI: 318–814) deaths per 100 000 population. Over this period, injuries caused about 8% of all deaths. In 2019, deaths due to road traffic injuries made up 29% of all injury deaths, followed by suicide and falls (each causing 16% of all injury deaths), and homicide (11% of all injury deaths).

The suicide rate fell by 29% globally between 2000 and 2019, from 13.0 (UI: 10.4–16.0) to 9.2 (UI: 9.7–12.6) deaths per 100 000 population (Figure 211). In all WHO regions, suicide rates have been on the decline, except in the Region of the Americas where the rate rose by 28%. The greatest decline (42%) was seen in the European Region, although the suicide rate in 2019 remained the highest at 12.8 (UI: 11.0–16.4) deaths per 100 000 population.

The global death rate due to homicides declined by 22% over the same period. However, progress varied greatly across WHO regions, with the homicide rate in the European Region declining by 63% while that in the Region of the Americas stayed roughly the same. In 2019, the homicide rate of 19.2 (UI: 15.6–23.7) deaths per 100 000 population in the Region of the Americas was over three times the global average of 6.2 (UI: 4.0–8.7) deaths per 100 000 population.

Globally, the death rate due to road traffic injuries has seen a slower decline of 13%, from 191 (UI: 161–22.3) deaths per 100 000 population to 167 (UI: 131–20.2) per 100 000 population. There was even an increase in the number of deaths – from 117 million (UI: 99.3–136 million) in 2000 to 12.8 million (UI: 10.1–15.5 million) in 2019 – due to an increase in total population. Much of the drop in the global death rate was driven by a 51% decline in the European Region. The drop in death rates in most of the other WHO regions was under 10% with the exception of the Western Pacific Region (19%). Prioritizing and creating laws in road safety is key to accelerating their declines.

Globally, men are about twice as likely to die from injury than women are. The death rates due to all injuries in 2019 were 77.6 (UI: 527–109.1) deaths per 100 000 male population and 36.9 (UI: 24.4–53.2) deaths per 100 000 female population. Across WHO regions and among the three injury causes discussed in this section, the male-to-female ratio of death rates in 2019 was highest for homicide in the Region of the Americas, where the death rate among men and boys was over seven times that among women and girls.

Men and boys accounted for 60%, 75% and 69% of deaths due to homicide, road traffic injuries and suicide respectively in 2019. Injury deaths also disproportionately affect younger men. Road traffic injury was the leading cause of death among boys and young men aged 15–29 years in 2019, and the second leading cause of death among men aged 30–49 years. Homicide was the second leading cause among boys and young men aged 15–29 years. Suicide was the third leading cause of death among girls and young women aged 15–29 years, and fourth among boys and young men in the same age group.

Although more men than women are affected by homicide, in 2019 some 930 000 (UI: 600 000–1 200 000) women died at the hands of others. A study suggests that approximately 39% of deaths among women have been committed by intimate partners. An estimated 30% of women aged 15 years and older worldwide in 2018 had been subjected to physical and/or sexual violence from either intimate partners or non-partners sexual violence during their lifetime. Violence can negatively affect women's physical, mental, sexual and reproductive health. WHO’s 2013 study found that women who had been physically or sexually abused were 1.5 times more likely to have a sexually transmitted infection compared to women who had not experienced partner violence. They are also twice as likely to have an abortion and 41% more likely to have a preterm birth.
```
Figure 2.11 Mortality rates due to suicide, homicide, and road traffic injury, by WHO region and globally, 2000–2019

| Region                     | Mortality rate (2000) | Mortality rate (2019) | Percentage decline (2000-2019) |
|----------------------------|-----------------------|-----------------------|---------------------------------|
| African Region             | 15                    | 20                    | -                               |
| Region of the Americas     | 10                    | 12                    | -                               |
| Eastern Mediterranean Region| 8                     | 9                     | -                               |
| European Region            | 7                     | 8                     | -                               |
| South-East Asia Region     | 10                    | 12                    | -                               |
| Western Pacific Region      | 5                     | 6                     | -                               |
| Global                     | 9                     | 11                    | -                               |

Note: The percentage decline is not shown because it is negative (meaning the death rate increased during the period).

---

Figure 2.12 Rank of deaths due to road traffic injury, suicide and homicide, by age group and sex*, 2019

json
[
    {
        "Age group (years)": "0–15",
        "Road traffic": {
            "Male": 7,
            "Female": 9
        },
        "Suicide": {
            "Male": ">30",
            "Female": ">30"
        },
        "Homicide": {
            "Male": 22,
            "Female": 25
        }
    },
    {
        "Age group (years)": "15–29",
        "Road traffic": {
            "Male": 1,
            "Female": 5
        },
        "Suicide": {
            "Male": 4,
            "Female": 3
        },
        "Homicide": {
            "Male": 2,
            "Female": 7
        }
    },
    {
        "Age group (years)": "30–49",
        "Road traffic": {
            "Male": 2,
            "Female": 8
        },
        "Suicide": {
            "Male": 7,
            "Female": 10
        },
        "Homicide": {
            "Male": 8,
            "Female": 17
        }
    },
    {
        "Age group (years)": "50–59",
        "Road traffic": {
            "Male": 5,
            "Female": 13
        },
        "Suicide": {
            "Male": 13,
            "Female": 19
        },
        "Homicide": {
            "Male": 21,
            "Female": ">30"
        }
    },
    {
        "Age group (years)": "60–69",
        "Road traffic": {
            "Male": 12,
            "Female": 18
        },
        "Suicide": {
            "Male": 20,
            "Female": 27
        },
        "Homicide": {
            "Male": ">30",
            "Female": ">30"
        }
    },
    {
        "Age group (years)": "70+",
        "Road traffic": {
            "Male": 22,
            "Female": 28
        },
        "Suicide": {
            "Male": ">30",
            "Female": ">30"
        },
        "Homicide": {
            "Male": 50-59
        }
    }
]
```
```Here's the conversion of the provided content into Markdown format:


Box 2.4 New data for assessing water, sanitation and hygiene services in Montenegrin health-care facilities

In 2019, the World Health Assembly adopted resolution WHA72.7 on water, sanitation and hygiene (WASH) in health-care facilities, calling for adequate WASH services for providing safe, people-centred health care and achieving UHC. Integration of WASH in health-care services can catalyze improvements in quality of care, staff morale and performance, health-care costs, disaster/outbreak resilience, infection prevention and control, and reductions in antimicrobial resistance. A key action is to conduct assessments of WASH conditions, on the basis of which follow-up interventions at the policy and practical levels should be identified and prioritized.

In 2021, the Institute of Public Health of Montenegro undertook – in partnership with the WHO European Centre for Environment and Health and the Organization’s Country Office in Montenegro – an analysis of existing policies and the broader enabling environment, as well as a baseline survey of the actual situation in facilities. Internationally recognized indicators for basic and expanded WASH services established by the WHO/UNICEF Joint Monitoring Programme for Water Supply, Sanitation and Hygiene were used to track progress with WASH-related SDG targets. Data were collected from all public and selected private health-care facilities in the country at all levels of care (151 in total). The findings indicated that there was good basic provision of various WASH components in many health-care facilities, especially with respect to water (88%) and hand hygiene (78%), and medium coverage of waste management provision (62%). However, the basic provision of environmental cleaning (13%) and sanitation (16%) remained a challenge in many health-care facilities across the country. Challenges in WASH service provision were observed more often in facilities providing primary care services and those located in rural areas, as well as in private facilities for waste management.

The outcomes of the survey highlighted strengths and gaps and will help in developing and implementing targeted interventions, both at the governance level and in practice at the facility level (e.g., by strengthening the national surveillance system and developing the capacity of medical and nonmedical staff). The outcomes also supported national reporting for global monitoring of progress towards achieving SDG3 (Ensure healthy lives and promote well-being for all at all ages) and SDG 6 (Ensure availability and sustainable management of water and sanitation for all).

Following the assessment, since 2022 water quality control in public health care facilities was included in the regular surveillance programme. Also planned was the integration of provisions related to WASH operation and maintenance in legislation, and the development of a programme dedicated to private health-care facilities in order to enhance capacity-building in health-care waste management.


### Note:
- There were no tables in the provided content, so no JSON conversion is needed.
- No images were included in the provided content to convert or analyze. If there were images, I would follow your specified protocols for conversion or description.

Unintentional poisoning can be caused by household chemicals, pesticides, kerosene, carbon monoxide, and medicines or may be the result of environmental contamination or occupational chemical exposure. Unintentional poisonings were responsible for about 84,000 (UI: 48,000–137,000) deaths in 2019 – of which 73% are thought to be preventable through sound chemical management. Because of occupational exposures, death rates due to unintentional poisonings are higher among men than women, although the gap has narrowed slightly in recent years.

### Figure 2.17
Global trends in mortality rates due to unintentional poisoning, by sex, 2000–2019

json
{
  "data": [
    {
      "year": 2000,
      "male": 2.0,
      "female": 1.0
    },
    {
      "year": 2001,
      "male": 2.0,
      "female": 1.0
    },
    {
      "year": 2002,
      "male": 2.0,
      "female": 1.0
    },
    {
      "year": 2003,
      "male": 2.0,
      "female": 1.5
    },
    {
      "year": 2004,
      "male": 2.0,
      "female": 1.5
    },
    {
      "year": 2005,
      "male": 2.0,
      "female": 1.5
    },
    {
      "year": 2006,
      "male": 2.0,
      "female": 1.5
    },
    {
      "year": 2007,
      "male": 1.9,
      "female": 1.5
    },
    {
      "year": 2008,
      "male": 1.8,
      "female": 1.4
    },
    {
      "year": 2009,
      "male": 1.7,
      "female": 1.3
    },
    {
      "year": 2010,
      "male": 1.7,
      "female": 1.3
    },
    {
      "year": 2011,
      "male": 1.6,
      "female": 1.2
    },
    {
      "year": 2012,
      "male": 1.6,
      "female": 1.2
    },
    {
      "year": 2013,
      "male": 1.5,
      "female": 1.2
    },
    {
      "year": 2014,
      "male": 1.5,
      "female": 1.2
    },
    {
      "year": 2015,
      "male": 1.4,
      "female": 1.2
    },
    {
      "year": 2016,
      "male": 1.4,
      "female": 1.2
    },
    {
      "year": 2017,
      "male": 1.4,
      "female": 1.1
    },
    {
      "year": 2018,
      "male": 1.3,
      "female": 1.1
    },
    {
      "year": 2019,
      "male": 1.3,
      "female": 1.0
    }
  ]
}
```

Source: Ref. (24).
```
2.5 Universal health coverage and health systems

Universal health coverage (UHC) means that all people can get the health services they need, of good quality, and without facing financial hardship from the need to pay for those services. SDG target 3.8 specifically aims to achieve UHC – including financial risk protection, access to quality essential health-care services and access to safe, effective, quality and affordable essential medicines and vaccines for all – by 2030. Advances towards this target are tracked through indicators on the coverage of essential health services (SDG 3.8.1), which is a composite index of health-service tracker indicators, and one indicator for the lack of financial protection (SDG 3.8.2), which is defined as the proportion of a country’s population with large household expenditures on health relative to their total household expenditure. While assessed separately, both UHC indicators provide vital information about the coverage and cost of health services in countries and need to be tracked together.

The expansion of service coverage (SDG indicator 3.8.1) slowed during the first half of the SDG era compared to 2015 gains, rising only three index points to 68 by 2021. There has been no significant progress in reducing financial hardship. The proportion of the population spending more than 10% of their household budget on health out of pocket (OOP) (SDG 3.8.2) has worsened since 2015 at an average of 2.0 percentage points per year to reach 13.5% in 2019 (about 1 billion people). This indicator is focused on relatively large out-of-pocket health spending, but for people living in or near poverty any amount spent on health out-of-pocket might be a source of financial hardship. In 2019, 4.9% of the global population (381 million people) were pushed or further pushed into extreme poverty due to OOP payments for health. While the COVID-19 pandemic is likely to have exacerbated the financial hardship experienced by those paying OOP for health, the degree of impact on health service coverage globally remains unclear. However, decreases in service coverage during the COVID-19 pandemic have been observed at both subregional and country levels.

Monitoring the coverage of essential services presents unique challenges due to the inclusionary nature of UHC and its emphasis on providing health services (promotive, preventive, curative, rehabilitative and palliative) of sufficient quality to be effective to persons in need. No index can fully summarize all the health services required across the life course to achieve UHC. Given this fact, the current UHC Service Coverage Index (UHC SCI) uses a selection of key indicators to track overall coverage of essential health services. The UHC SCI comprises four subdivisions related to areas of key health concern, namely: reproductive, maternal, newborn and child health (RMNCH); infectious diseases; noncommunicable diseases (NCDs); and health service capacity and access. The following paragraphs describe the tracker indicators and related metrics which are used to monitor progress on the pathway to UHC.

Reproductive, maternal, newborn and child health (RMNCH)

Globally, the percentage of women whose contraceptive needs satisfied by modern methods increased by approximately 5% since 2000, reaching 77.5% in 2022. Regional variations in improved contraceptive coverage depended mainly on the respective starting positions in 2000. The largest relative gains were made in the Eastern Mediterranean Region (an increase of under 20% since 2000, up to 62.3% in 2022) and the African Region (an increase of over 50% since 2000, up to 57.5% in 2022).

Antenatal care (ANC) visits are opportunities to reach pregnant women with a series of interventions that are vital for their health and the health of their newborns and infants. WHO recommends a minimum of eight contacts with a health provider that include blood and urine testing, as well as weight/ height and blood pressure measurements. Globally, between 2015 and 2021, 66% of women are estimated to have attended four or more ANC visits during their pregnancies. Importantly, however, this estimate does not capture effective coverage, especially whether the recommended interventions were received during the visits or if the women saw a skilled health provider such as a doctor or nurse. The data used to calculate this latter indicator primarily come from household surveys which do capture the type of provider seen on the first ANC visit. From these data, it is estimated that 88% of pregnant women attended at least one ANC visit with a skilled provider between 2015 and 2021. This does not directly indicate the degree to which respectful, quality pregnancy care was received but rather shows an increased likelihood that quality was present.



{
  "Abbreviations": [
    {"ABR": "Adolescent birth rates"},
    {"AIDS": "Acquired immunodeficiency syndrome"},
    {"AMC": "Antimicrobial consumption"},
    {"AMR": "Antimicrobial resistance"},
    {"ANC": "Antenatal care"},
    {"ARI": "Acute respiratory infection"},
    {"ARR": "Average annual rate of reduction"},
    {"AST": "Antimicrobial susceptibility test results"},
    {"ATACH": "Alliance for Transformative Action on Climate Change and Health"},
    {"BSI": "Bloodstream infection"},
    {"COVID-19": "Coronavirus disease 2019"},
    {"cVDPV2": "Circulating vaccine-derived poliovirus type 2"},
    {"DALY": "Disability-adjusted life-year"},
    {"DTP3": "Diphtheria, tetanus toxoid and pertussis-containing vaccine (3 doses)"},
    {"EENC": "Early essential newborn care"},
    {"GLASS": "Global Antimicrobial Resistance and Use Surveillance System"},
    {"GPW 13": "Thirteenth General Programme of Work (WHO)"},
    {"GTS": "Global technical strategy for malaria"},
    {"HIV": "Human immunodeficiency virus"},
    {"HPV": "Human papillomavirus"},
    {"IHR": "International Health Regulations"},
    {"IQR": "Interquartile range"},
    {"KMC": "Kangaroo mother care"},
    {"MCV2": "Measles-containing vaccine (2 doses)"},
    {"MDG": "Millennium Development Goal"},
    {"MRSA": "Methicillin-resistant Staphylococcus aureus"},
    {"NAP": "National Adaptation Plan"},
    {"NCD": "Noncommunicable disease"},
    {"NDC": "Nationally Determined Contribution"},
    {"NHWA": "National health workforce accounts"},
    {"NICU": "Neonatal intensive care unit"},
    {"NMR": "Neonatal mortality rate"},
    {"NTD": "Neglected tropical disease"},
    {"ODA": "Official Development Assistance"},
    {"OOP": "Out of pocket (expenditure)"},
    {"PCV3": "Pneumococcal conjugate vaccine (3 doses)"},
    {"PM": "Particulate matter"},
    {"RMNCH": "Reproductive, maternal, newborn and child health"},
    {"SAE": "Small area estimation"},
    {"SDG": "Sustainable Development Goal"},
    {"TB": "Tuberculosis"},
    {"U5MR": "Under-five mortality rate"},
    {"UHC": "Universal health coverage"},
    {"UI": "Uncertainty interval"},
    {"UNDESA": "United Nations Department of Economic and Social Affairs"},
    {"UNFCCC": "United Nations Framework Convention on Climate Change"},
    {"UNICEF": "United Nations Children’s Fund"},
    {"WASH": "Water, sanitation and hygiene"},
    {"WHO": "World Health Organization"},
    {"WPV": "Wild poliovirus"},
    {"YLL": "Years of life lost"}
  ]
}
```
Immunization uptake is a critical component of primary health care and a key measurement of progress on the path to UHC. Over the past 30 years, increasing and sustained levels of immunizations among children have contributed to improved rates of childhood survival and well-being. Unfortunately, the proportion of one-year-old children vaccinated with three doses of diphtheria, tetanus toxoid and pertussis vaccine (DTP3) fell nearly 6% (five percentage points) to 81% between 2019 and 2021, leading to an estimated 25 million children missing at least one dose of DTP in 2021. 

Similar trends were observed in the population coverage of other vital immunizations (Figure 2.18). Globally, the coverage of the three doses of pneumococcal conjugate vaccines (PCV3) increased 5-fold between 2010 (10%) and 2020 (51%) and stagnated at this level through 2021. Similarly, coverage of the two doses of measles vaccine (MCV2) expanded from 42% in 2010 to 71% in 2019 and remained at approximately the same level through 2021. Coverage of the human papillomavirus (HPV) vaccine, which has important health implications for women and girls, has remained relatively low since its first introduction, making the more than 100% decrease in coverage between 2019 and 2021 (to 12% in 2021) particularly concerning.

Acute respiratory infection (ARI) is the leading cause of child mortality among all infectious diseases; in 2019, it was estimated that one in every seven deaths among children under 5 years of age was due to ARI. Seeking timely care from a health practitioner for a child suffering from ARI has been shown to reduce mortality. However, population-based survey data show that there has been slow progress in improving care-seeking for ARI symptoms – down from 68% in the period 2008–2014 to 56% in the period 2015–2021 – among countries with available survey data.

Statistics presented at the global, regional and national levels often obscure disparities in health-service coverage. Subnational analyses, at the first (state or province) and second (district or county) administrative levels, provide additional information regarding progress on the pathway to UHC as well as insights for improving the design and implementation of health policies and programmes.

Figure 2.18 Global immunization rates against diphtheria, tetanus toxoid and pertussis (DTP3), measles (MCV2), pneumococcal infections (PCV3) and human papillomavirus (HPV), 2000–2021

json
{
  "figure": "2.18",
  "title": "Global immunization rates against diphtheria, tetanus toxoid and pertussis (DTP3), measles (MCV2), pneumococcal infections (PCV3) and human papillomavirus (HPV), 2000–2021",
  "data": [
    {
      "year": 2000,
      "DTP3": 20,
      "MCV2": 0,
      "PCV3": 0,
      "HPV": 0
    },
    {
      "year": 2001,
      "DTP3": 20,
      "MCV2": 0,
      "PCV3": 0,
      "HPV": 0
    },
    {
      "year": 2002,
      "DTP3": 25,
      "MCV2": 0,
      "PCV3": 0,
      "HPV": 0
    },
    {
      "year": 2003,
      "DTP3": 30,
      "MCV2": 0,
      "PCV3": 0,
      "HPV": 0
    },
    {
      "year": 2004,
      "DTP3": 35,
      "MCV2": 5,
      "PCV3": 0,
      "HPV": 0
    },
    {
      "year": 2005,
      "DTP3": 40,
      "MCV2": 10,
      "PCV3": 0,
      "HPV": 0
    },
    {
      "year": 2006,
      "DTP3": 43,
      "MCV2": 15,
      "PCV3": 0,
      "HPV": 0
    },
    {
      "year": 2007,
      "DTP3": 46,
      "MCV2": 25,
      "PCV3": 0,
      "HPV": 0
    },
    {
      "year": 2008,
      "DTP3": 52,
      "MCV2": 30,
      "PCV3": 0,
      "HPV": 0
    },
    {
      "year": 2009,
      "DTP3": 54,
      "MCV2": 35,
      "PCV3": 5,
      "HPV": 0
    },
    {
      "year": 2010,
      "DTP3": 56,
      "MCV2": 40,
      "PCV3": 10,
      "HPV": 0
    },
    {
      "year": 2011,
      "DTP3": 60,
      "MCV2": 41,
      "PCV3": 15,
      "HPV": 0
    },
    {
      "year": 2012,
      "DTP3": 62,
      "MCV2": 42,
      "PCV3": 25,
      "HPV": 0
    },
    {
      "year": 2013,
      "DTP3": 63,
      "MCV2": 42,
      "PCV3": 35,
      "HPV": 0
    },
    {
      "year": 2014,
      "DTP3": 64,
      "MCV2": 42,
      "PCV3": 40,
      "HPV": 0
    },
    {
      "year": 2015,
      "DTP3": 65,
      "MCV2": 42,
      "PCV3": 46,
      "HPV": 0
    },
    {
      "year": 2016,
      "DTP3": 67,
      "MCV2": 42,
      "PCV3": 48,
      "HPV": 0
    },
    {
      "year": 2017,
      "DTP3": 70,
      "MCV2": 42,
      "PCV3": 49,
      "HPV": 0
    },
    {
      "year": 2018,
      "DTP3": 74,
      "MCV2": 42,
      "PCV3": 50,
      "HPV": 0
    },
    {
      "year": 2019,
      "DTP3": 81,
      "MCV2": 71,
      "PCV3": 51,
      "HPV": 0
    },
    {
      "year": 2020,
      "DTP3": 81,
      "MCV2": 70,
      "PCV3": 51,
      "HPV": 0
    },
    {
      "year": 2021,
      "DTP3": 81,
      "MCV2": 71,
      "PCV3": 51,
      "HPV": 0
    }
  ]
}
```
```
## HIV testing and treatment cascade

### a. Global, 2015 and 2021

| Year | People living with HIV who know their status (%) | People living with HIV who are on treatment (%) | People living with HIV who are virally suppressed (%) |
|------|--------------------------------------------------|------------------------------------------------|-----------------------------------------------------|
| 2015 | 69                                               | 50                                             | 40                                                  |
| 2021 | 85                                               | 75                                             | 68                                                  |

### b. By WHO region, 2021

| Region                         | People living with HIV who know their status (%) | People living with HIV who are on treatment (%) | People living with HIV who are virally suppressed (%) |
|--------------------------------|--------------------------------------------------|------------------------------------------------|-----------------------------------------------------|
| African Region                 | 88                                               | 78                                             | 85                                                  |
| Region of the Americas         | 72                                               | 66                                             | 41                                                  |
| Eastern Mediterranean Region    | 27                                               | 24                                             | N/A                                                 |
| European Region                | 73                                               | 63                                             | 60                                                  |
| South-East Asia Region         | 74                                               | 63                                             | 55                                                  |
| Western Pacific Region         | 88                                               | 79                                             | 76                                                  |

**Source:** Ref. (2) and (3)
```
## Noncommunicable diseases and mental health

Globally, noncommunicable diseases (NCDs) are responsible for the highest proportion of the disease burden (see section 13 on Major noncommunicable diseases and related risk factors). NCDs result from a combination of genetic, physiological, environmental and behavioural factors; consequently, prevention and control efforts tend to focus on reducing relevant risk factors for these diseases. In terms of service coverage on the pathway to UHC, preventive, diagnostic and treatment services for NCDs require multisectoral approaches, underpinned by policy and fiscal decisions to reduce risk factors.

At the global level, hypertension diagnostic, treatment and control rates have increased substantially since 2000. However, nearly one half of people with hypertension were not diagnosed in 2019 and only around one fifth of those with hypertension were receiving effective treatment. The availability of early detection programmes strengthens the ability to detect cancers at an early stage, increasing the potential for survival. Globally, 20% of countries were reported to have early detection programmes for childhood cancers at the primary health care level, while 38% had programmes for colon cancer, 59% for breast cancer and 62% for cervical cancer.

Mental, neurological and substance use disorders accounted for 10% of the global burden of disease (DALYs) and 25% of years lived with disability in 2019. More than 1 in 100 (13%) deaths in 2019 were due to suicide (see section 24 on Injuries and violence). The gap between people needing care for mental conditions and those with access to care remains substantial. For example, only 29% of people with psychosis and only one third of people with depression receive formal mental health care. Depression, anxiety, and conduct disorders are among the leading causes of illness and disability among adolescents. It is estimated that every US$ 1 invested in interventions to prevent and treat mental disorders among adolescents could return around US$ 24 in health, education and employment benefits over the course of 80 years.

Although effective treatments exist for substance use disorders, treatment coverage is very low. Fewer than 1 in 5 people receive treatment for alcohol use disorders—less than 1 in 10 in low- and lower-middle-income countries—and about 1 in 8 of those with drug use disorders. Even fewer people with substance use disorders receive minimally adequate treatment: only about 7% globally and 1% in low- and lower-middle income countries.

Approximately 70% of people with neurological disorders live in low- and middle-income countries, where health systems are ill-equipped to deal with this challenge, resulting in a large treatment gap. Treatment gaps for epilepsy exceed 75% in most low-income countries and 50% in most middle-income countries. Access to dementia diagnostic services is unequally distributed and across countries, with rural or remote areas covered with dementia diagnostic services only in 1 in 4 low- and middle-income countries, compared to 2 in 3 high-income countries.

## Health service capacity and access

Progress toward UHC depends on the availability, accessibility, acceptability and quality of the health workforce. Current challenges include maldistribution, inefficiencies, lack of support and protection, and shortages at national and subnational levels. A recent assessment shows that the global shortage reduced from 20 million in 2013 to 15 million health workers in 2020, with a projected decrease to 10 million by 2030. Although there has been a tremendous increase in the health workforce globally, regions with the highest burden of disease continue to have the lowest proportion of health workforce to deliver the health services.

The WHO European Region at 36.6, 83.4 and 6.2 per 10,000 population respectively, and for pharmacists in the WHO South-East Asia Region and European Region at 6.6 and 6.5 per 10,000 population respectively. The lowest health worker density, however, remains in the WHO African Region with 2.9 medical doctors and 12.9 nursing and midwifery personnel per 10,000 population, and less than 1 per 10,000 population for both dentists and pharmacists. As with other indicators, health workforce statistics at national level often mask disparities within countries. Rural and remote areas particularly often suffer from these challenges.


{
  "Medical doctors": {
    "African Region": 29,
    "South-East Asia Region": 77,
    "Eastern Mediterranean Region": 11.2,
    "Western Pacific Region": 20.9,
    "Region of the Americas": 24.5,
    "European Region": 36.6
  },
  "Nursing and midwifery personnel": {
    "African Region": 12.9,
    "South-East Asia Region": 20.4,
    "Eastern Mediterranean Region": 16.5,
    "Western Pacific Region": 40.0,
    "Region of the Americas": 82.1,
    "European Region": 83.7
  },
  "Dentists": {
    "African Region": 0.3,
    "South-East Asia Region": 1.5,
    "Eastern Mediterranean Region": 2.6,
    "Western Pacific Region": 5.9,
    "Region of the Americas": 6.2,
    "European Region": 5.0
  },
  "Pharmacists": {
    "African Region": 0.8,
    "South-East Asia Region": 3.3,
    "Eastern Mediterranean Region": 4.4,
    "Western Pacific Region": 5.1,
    "Region of the Americas": 6.6,
    "European Region": 6.5
  }
}

Access to essential medicines – a multidimensional concept which combines both the affordability and availability of medicines – is another key component for achieving UHC. Since 2016, the proportion of health facilities that have a core set of relevant essential medicines available and affordable on a sustainable basis has been estimated for 17 countries across WHO’s African, Americas and European regions, with a median value across all 17 countries of 15% (IQR: 0–28%). The sparsity of data and lack of mechanisms for tracking progress make the interpretation of this particular metric difficult. During the COVID-19 pandemic, people suffering from NCDs, such as cancer, heart diseases and diabetes, reported disruptions or sustained challenges in accessing their routine medications for these diseases.

The International Health Regulations (IHR) are a set of legal instruments which oblige all 196 States Parties of WHO to develop and maintain a minimum set of core capacities for surveillance and response to public health events of international concern. The implementation status of the core capacities can be monitored through an average of 35 indicators that are used to measure the 15 capacities. The average implementation status of capacities for all WHO regions increased from 64% in 2021 to 66% in 2022.
# Box 2.6 An evidence-based approach to ensuring retention and effective deployment of health workers in support of UHC Nepal

Having the right number of health workers in the right places and at the right times is crucial to meeting population health needs and achieving universal health coverage. In Nepal, challenges in human resources for health include the over- and under-production of different cadres of health workers, unequal distribution of workloads and geographical disparities in health-worker density. Staff turnover is particularly high in primary health-care facilities in remote and rural areas.

To address the drivers of poor retention of health workers in remote and rural areas of Nepal, the Ministry of Health and Population, with support from WHO, conducted a study on the perspectives of health workers on posting and retention in these areas. Starting in April 2021, 21 case studies were developed through personal interviews and focus group discussions with frontline health workers – including medical officers, staff nurses, health assistants and auxiliary nurse midwives – in remote health-care facilities in 14 districts representative of different geographical areas of Nepal. The study was done in coordination with the provinces concerned. The study aimed to explore which approaches would be the most appropriate for, and have most impact on, the retention and deployment of qualified professionals in rural and remote areas in accordance with government strategies. A review of the case studies was carried out between April and December 2021. The factors identified as influencing health worker decision-making included remuneration and incentives, opportunities for career development, social considerations, cultural values, health governance and the work environment, and national laws and regulations. It is crucial to address these factors to manage and retain health workers in remote areas in order to ensure that health services provided by a qualified health professional are available and easily accessible to every citizen.

WHO’s Workload Indicators of Staffing Need (WISN) was implemented to determine optimal staffing with training in 2019 and a pilot programme involving nine primary health facilities across three provinces in 2021. Analysis of the WISN results identified duplication of responsibilities of health workers in primary health-care settings and the need to improve number, skills and distribution of health workers on the basis of workload and geographical distribution. The findings called for improved task allocation, teamwork and skill mix within the health teams in the primary health-care facilities. The findings from the pilot study were disseminated in November 2021 along with the National Human Resources for Health Strategy. The Ministry of Health and Population, with WHO and partners, continues to roll out the WISN methodology for different health occupations and health facilities in order to support policy and actions.
# References

1. In Danger. UNAIDS Global AIDS Update 2022. Geneva: Joint United Nations Programme on HIV/AIDS; 2022. [Link](https://www.unaids.org/en/resources/documents/2022/in-danger-global-aids-update, accessed 8 April 2023).
2. AIDSinfo (online database) Geneva: Joint United Nations Programme on HIV/AIDS (UNAIDS) [Link](https://aidsinfo.unaids.org/, accessed 27 February 2023).
3. HIV/AIDS (Global Health Observatory online database). Geneva: World Health Organization; 2023. [Link](https://www.who.int/data/gho/data/themes/hiv-aids, accessed 27 February 2023).
4. Global Antimicrobial Resistance and Use Surveillance System (GLASS). (Online). Geneva: World Health Organization [Link](https://www.who.int/initiatives/glass, accessed 13 March 2023).
5. United Nations. IAEG-SDGs 2020 Comprehensive Review Proposals Submitted to the 51st session of the United Nations Statistical Commission for its consideration. 2020 [Link](https://unstats.un.org/sdgs/iaeg-sdgs/2020-comprev/UNSC-proposal/, accessed 14 March 2023).
6. Global antimicrobial resistance and use surveillance system (GLASS) report: 2022. Geneva: World Health Organization; 2022. [Link](https://www.who.int/publications/i/item/9789240062702, accessed 8 April 2023).
7. The WHO Essential Medicines List Antibiotic Book: improving antibiotic AWAReness (Draft for consultation). Geneva: World Health Organization; 2021. [Link](https://www.who.int/publications/m/item/the-who-essential-medicines-list-antibiotic-book-improving-antibiotic-awareness, accessed 8 April 2023).
8. Global tuberculosis report 2022. Fact sheet. Geneva: World Health Organization; 2022. [Link](https://cdn.who.int/media/docs/default-source/ng Tuberculosis/global-tuberculosis-report-2022/global-tb-report-2022-factsheet.pdf?sfvrsn=88fdb76_86&download=true, accessed 1 March 2023).
9. Global tuberculosis report 2022. Geneva: World Health Organization; 2022. [Link](https://www.who.int/publications/i/item/9789240061679, accessed 1 March 2023).
10. Global technical strategy for malaria 2016–2030, 2021 update. Geneva: World Health Organization; 2021. [Link](https://www.who.int/publications/i/item/9789240031357, accessed 26 March 2013).
11. World malaria report 2022. Geneva: World Health Organization; 2022. [Link](https://www.who.int/publications/i/item/9789240064898, accessed 6 March 2023).
12. Global health sector strategy on viral hepatitis 2016–2021. Towards ending viral hepatitis. Geneva: World Health Organization; 2016. [Link](https://apps.who.int/iris/bitstream/handle/10665/246177/WHO-HIV-2016.06-eng.pdf, accessed 7 March 2023).
13. Global health sector strategies on, respectively, HIV, viral hepatitis and sexually transmitted infections for the period 2022–2030. Geneva: World Health Organization; 2022. [Link](https://apps.who.int/iris/rest/bitstreams/1451670/retrieve, accessed 7 March 2023).
14. Global progress report on HIV, viral hepatitis and sexually transmitted infections, 2021. Accountability for the global health sector strategies 2016–2021: actions for impact. Geneva: World Health Organization; June 2021. [Link](https://www.who.int/publications/i/item/9789240207077, accessed 7 March 2023).
15. Hepatitis B surface antigen (HBsAg) prevalence among children under 5 years. Global Health Observatory data. Geneva: World Health Organization [Link](https://www.who.int/data/gho/data/indicators/indicator-details/GHO/hepatitis-b-surface-antigen-hbsag-prevalence-among-children-under-5-years, accessed 7 March 2023).
16. Ending the neglect to attain the sustainable development goals: a road map for neglected tropical diseases 2021–2030. Geneva: World Health Organization; 2020. [Link](https://apps.who.int/iris/handle/10665/338565, accessed 8 March 2023).
17. Global report on neglected tropical diseases 2023. Geneva: World Health Organization; 2023. [Link](https://apps.who.int/iris/rest/bitstreams/1489232/retrieve, accessed 8 March 2023).
```
19. Poliomyelitis (website). Geneva: World Health Organization; 2022 (https://www.who.int/news-room/fact-sheets/detail/poliomyelitis, accessed 8 March 2023).

20. Global Polio Eradication Initiative (website). Geneva: World Health Organization (https://polioeradication.org/polio-today/polio-now/polio-virus-list/, accessed 8 March 2023).

21. Polio Eradication Strategy 2022–2026. Delivering on a promise. Geneva: World Health Organization on behalf of the Global Polio Eradication Initiative; 2021 (https://apps.who.int/iris/bitstream/handle/10665/345967/9789240031973-eng.pdf, accessed 26 March 2023).

22. Levels and trends in child malnutrition. UNICEF/WHO/World Bank Group Joint Child Malnutrition Estimates. New York (NY), Geneva and Washington (DC): United Nations Children's Fund, World Health Organization and the World Bank Group; 2023.

23. Global anaemia estimates, 2021 edition. Geneva: World Health Organization; 2021 (https://www.who.int/data/gho/data/themes/topics/anaemia_in_women_and_children, accessed 5 April 2023).

24. Global health estimates 2019: deaths by cause, age, sex, by country and by region, 2000–2019. Global Health Observatory data. Geneva: World Health Organization; 2020 (https://www.who.int/data/global-health-estimates, accessed 3 April 2023).

25. Stöckl H, Devries K, Rotstein A, Abrahams N, Campbell J, Watts C et al. The global prevalence of intimate partner homicide: a systematic review. Lancet. 2013;382(9895):859–65.

26. Violence against women prevalence estimates, 2018. Geneva: World Health Organization; 2021 (https://www.who.int/publications/i/item/9789240022265, accessed 3 April 2023).

27. Global regional estimates of violence against women: prevalence and health impacts of intimate partner violence and non-partner sexual violence. Geneva: World Health Organization; 2013 (https://www.who.int/publications/i/item/9789241546625, accessed 3 April 2023).

28. Preventing disease through healthy environments: a global assessment of the burden of disease from environmental risks. Geneva: World Health Organization; 2018 (https://www.who.int/publications/i/item/9789241565196, accessed 24 March 2023). The updated 2016 data tables for the WHO publication Preventing disease through healthy environments. Geneva: World Health Organization; 2019 are also available via the same link.

29. Progress on household drinking water, sanitation and hygiene 2000–2020: five years into the SDGs. Geneva: World Health Organization and the United Nations Children’s Fund; 2021 (https://washdata.org/sites/default/files/2022-01/jmp-2021-wash-households-highlights.pdf, accessed 7 February 2023).

30. Progress on wastewater treatment – Global status and acceleration needs for SDG indicator 6.31. New York (NY) and Geneva: United Nations Human Settlements Programme and World Health Organization; 2021 (https://www.unwater.org/publications/progress-wastewater-treatment-2021-update, accessed 16 May 2023).

31. SDG indicators database. New York (NY): United Nations Department of Economic and Social Affairs (https://unstats.un.org/sdgs/dataport/database, accessed 22 April 2023).

32. Public health and environment [online database]. Global Health Observatory data. Geneva: World Health Organization (https://www.who.int/data/gho/data/themes/public-health-and-environment, accessed 9 April 2023).

33. Official development assistance for the water sector (water supply and sanitation, agricultural water resources, and hydroelectric power plants), 2023. Creditor reporting system (CRS). Paris: Organization for Economic Co-operation and Development; (https://stats.oecd.org/Index.aspx?DataSetCode=crs1, accessed 22 April 2023).

34. Strong systems and sound investments: evidence on and key insights into accelerating progress on sanitation, drinking-water and hygiene. The UN-Water global analysis and assessment of sanitation and drinking-water (GLAAS) 2022 report. Geneva: World Health Organization; 2022 (https://glaas.who.int/glaas/un-water-global-analysis-and-assessment-of-sanitation-and-drinking-water-(glaas)-2022-report, accessed 22 April 2023).

35. WHO global air quality guidelines: particulate matter (PM₁, and PM₂.₅), ozone, nitrogen dioxide, sulfur dioxide and carbon monoxide. Geneva: World Health Organization; 2021 (https://apps.who.int/iris/bitstream/handle/10665/343529/978924003428-eng.pdf, accessed 24 March 2023).

36. The public health impacts of chemicals: knowns and unknowns – 2021 data addendum. Geneva: World Health Organization; 2021 (https://www.who.int/publications/i/item/WHO-HEP-ECH-EHD-2101, accessed 22 April 2023).
```I'm unable to process images directly. However, I can offer guidance on how you might convert the information or recommend tools that could assist with this task. If you have specific text or data that you'd like to share, feel free to paste it here!
56. Epilepsy: a public health imperative. Geneva: World Health Organization; 2019 ([https://www.who.int/publications/i/item/epilepsy-a-public-health-imperative](https://www.who.int/publications/i/item/epilepsy-a-public-health-imperative), accessed 27 April 2023).

57. Global status report on the public health response to dementia. Geneva, World Health Organization; 2021 ([https://www.who.int/publications/i/item/9789240033245](https://www.who.int/publications/i/item/9789240033245), accessed 25 April 2023).

58. Health and care workers: Protect. Invest. Together. Technical brief. Geneva: World Health Organization; 2023 ([https://www.who.int/publications/m/item/health-and-care-workers-protect-invest-together](https://www.who.int/publications/m/item/health-and-care-workers-protect-invest-together), accessed 7 April 2023).

59. Boniol M, Kunjumen T, Sasvian Nair T, Siyam A, Campbell J, Diallo K. The global health workforce stock and distribution in 2020 and 2030: a threat to equity and 'universal' health coverage? BMJ Glob Health. 2022;7(6):e009316 ([https://pubmed.ncbi.nlm.nih.gov/35760437/](https://pubmed.ncbi.nlm.nih.gov/35760437/), accessed 22 April 2023).

60. National health workforce accounts (NHWA) data portal, December 2022 update. Geneva: World Health Organization ([https://apps.who.int/nhwaportal/](https://apps.who.int/nhwaportal/), accessed 23 March 2023).

61. Data collected with a) the Essential Medicines and Health Products Price and Availability Monitoring mobile application (WHO EMP MedMon). Geneva: World Health Organization ([https://www.who.int/medicines/areas/policy/monitoring/empmedmon/en/](https://www.who.int/medicines/areas/policy/monitoring/empmedmon/en/), accessed 7 April 2023) and b) Medicine prices, availability, affordability & price components database. Amsterdam: Health Action International/WHO ([https://haiweb.org/what-we-do/price-availability-affordability/price-availability-data/](https://haiweb.org/what-we-do/price-availability-affordability/price-availability-data/), accessed 7 April 2023).

62. Access to NCD medicines: emergent issues during the COVID-19 pandemic and key structural factors; Geneva: World Health Organization; 2023 ([https://www.who.int/publications/i/item/9789240069442](https://www.who.int/publications/i/item/9789240069442), accessed 7 April 2023).

63. Electronic State Parties Self-Assessment Annual Reporting Tool (e-SPAR). Geneva: World Health Organization; 2023 ([https://extranet.who.int/e-spar](https://extranet.who.int/e-spar), accessed 7 April 2023).


### Note:
- The content does not contain any specific table data or images to convert.
- If there were images, please provide context as described for extraction.
### Seventy-five years of improving public health, 1948–2023

| Year | Event Description |
|------|-------------------|
| 1948 | WHO Constitution comes into force |
| 1974 | WHO founds the Expanded Programme on Immunization to bring life-saving vaccines to all the world's children |
| 1978 | WHO launches the global diarrhoeal diseases programme with Oral rehydration salts (ORS) at its heart |
| 1980 | Following an ambitious 12-year global vaccination campaign led by WHO, smallpox is eradicated |
| 1988 | The Global Polio Eradication Initiative (GPEI) is launched |
| 1999 | The first global strategy for the prevention and control of noncommunicable diseases (NCDs) |
| 2000 | The WHO Global Outbreak Alert and Response Network (GOARN) is established to detect and combat the international spread of outbreaks |
| 2003 | The World Health Assembly unanimously adopts WHO's first global public health treaty, the WHO Framework Convention on Tobacco Control |
| 2004 | WHO co-established the UN Road Safety Collaboration to prevent road traffic injuries |
| 2005 | The International Health Regulations are revised |
| 2006 | WHO Child Growth Standards are launched to help every child grow in an equitable way |
| 2012 | The World Health Assembly adopts WHO's implementation plan on maternal, infant, and young child nutrition |
| 2014 | The Every Newborn Action Plan is endorsed by the World Health Assembly |
| 2015 | All United Nations Member States adopt the 2030 Agenda for Sustainable Development |
| 2019 | UN Declaration on Universal Health Coverage |
| 2020 | Access to COVID-19 Tools Accelerator |
| 2021 | More than 74 million lives had been saved through tuberculosis prevention, diagnosis and treatment since 2000; HIV treatment coverage expanded rapidly with well over 17 million people living with HIV on antiretroviral therapy by the end of 2015 |
| 2022 | Agreement for cooperation on the health of humans, animals, plants and the environment |
| 2023 | WHO's 75th anniversary |
```
As the world moves towards achieving the SDG targets by 2030, WHO has redoubled its commitment to the "Health for All" goal adopted in Alma-Ata in 1978 and the Political Declaration of the High-level Meeting on Universal Health Coverage (UHC). The Organization is working closely with countries to orient their health systems towards people-centered, resilient and sustainable primary health care. Acceleration towards UHC is an integral pillar of the Triple Billion strategic priorities outlined in WHO’s 13th General Programme of Work 2018–2025 (GPW 13): 
- 1 billion more people benefiting from universal health coverage; 
- 1 billion more people better protected from health emergencies; 
- 1 billion more people enjoying better health and well-being. 
These form a comprehensive framework to uphold the right to health, promote social justice, empower individuals and communities and address the determinants of human health. In 2022 WHO co-signed a ground-breaking agreement with several international agencies to strengthen cooperation in order to balance and optimize the health of humans, animals, plants and the ecosystem using a sustainable, integrated and coordinated approach. The framework reinforces national and regional health systems and services and contributes to global health security.

Working closely with Member States and other partners, WHO has seen many remarkable milestones achieved during its 75 years of existence. Smallpox was eradicated in 1980 after an ambitious 12-year global vaccination campaign led by WHO. By 2023, five of the six WHO Regions were certified free of wild poliovirus and two of the three wild poliovirus strains have been globally eradicated. HIV treatment coverage has expanded rapidly with over 287 million people living with HIV on antiretroviral treatment by the end of 2021 – up from 7.8 million in 2010. More than 74 million lives have been saved through tuberculosis prevention, diagnosis and treatment since 2000, 42 countries have eliminated malaria and 47 countries have eliminated at least one neglected tropical disease. Moreover, in the past two decades, tobacco use has dropped by a third, maternal mortality has fallen by a third and child mortality has halved.
```
## 3.4 Implications for the next stage of global health

If past trends continue to WHO's 100th anniversary, by 2048 about 86% of global deaths will be attributed to NCDs, and the communicable group and injuries will each account for about 6% of all deaths. In particular, the Region of the Americas and the Western Pacific and European regions are expected to see NCDs accounting for over 90% of all deaths by 2048, while causes from the communicable group will be responsible for below 3% of all deaths. As deaths due to communicable causes fall to below 10%, NCDs are expected to cause over 80% of all deaths in the South-East Asia and Eastern Mediterranean regions. The African Region is foreseen to be still falling behind with causes from the communicable group expected to account for 28% of all deaths in that region in 2048, while only 61% of all deaths are expected to be caused by NCDs.

As a result of population growth and population aging, the total number of annual deaths will grow dramatically in the decades ahead. According to United Nations projections, total annual global deaths will reach nearly 90 million in 2048 (2). WHO projects that 77 million of these will be NCD deaths, representing a nearly 90% increase in absolute numbers over 2019. The relative size of increase in the number of NCD deaths between 2019 and 2048 will range from under 30% in Europe to over 210% in Africa. The projected total number of NCD deaths will be highest in the Western Pacific Region, causing nearly 21 million deaths annually by 2048.

In spite of the expected decline in NCD mortality rates in many parts of the world, both the projected percentage increase and the absolute mortality burden of NCDs are daunting. It is imperative that we are prepared for the consequences of the epidemiological transition and demographic changes that will manifest in the next few decades. The world needs to double down on efforts to go beyond traditional public health measures and to address NCDs, their underlying risk factors and their treatment through a multisectoral approach in order to prevent and control the diseases that will become more prominent causes of death worldwide in the years to come.

Mortality is only part of the picture of population health. As survival continues to improve across nearly all causes of deaths, non-fatal outcomes become more prevalent. People whose deaths have been averted are prone to spend part of their surviving years in less than full-health. Accordingly, it is critical to consider the impact of both mortality and morbidity. Looking at disability-adjusted life-years (DALYs) – a summary measure that accounts for the total number of years lost due to premature deaths and disability – the temporal trends and geographical patterns are similar to those for mortality. However, given that causes in the communicable group continue to contribute to life-year loss through disability despite their declining contribution to premature deaths, the shares of DALYs due to NCDs are lower than the share of all deaths due to NCDs.

It is also noteworthy that disability is noted responsible for a considerable number of years lost. Some primarily non-fatal causes, such as back and neck pains, are already among the highest ranked causes of DALYs (e.g. fifth ranking cause in the European Region). Also, while some communicable diseases such as HIV have fallen out of the top 10 contributors to DALYs, some NCDs and injuries – including diabetes – have remained or rapidly moved up in ranking to take a place in the top 10. In the Region of the Americas in particular, diabetes has surpassed stroke to become the second ranked contributor to DALYs while interpersonal violence has continued to be among the top five contributors since 2000. Thus, it is critical to have a comprehensive view of current and future disease burdens in order to have better targeted and more effective policy formulation.

# Key messages

Since the beginning of the millennium, the world has seen notable improvements in population health globally. As child mortality halved, maternal mortality fell by a third, the incidence of many infectious diseases—including HIV, tuberculosis and malaria—dropped, and the risks from dying prematurely from noncommunicable diseases (NCDs) and injuries declined, global life expectancy at birth rose from 67 years in 2000 to 73 years in 2019. These achievements are consistent with the progress made in areas that influence health—from improved access to essential health services to reduced exposure to health risks, including tobacco use, alcohol consumption and child undernutrition.

However, the rapid progress commonly observed for many of these indicators in the era of the Millennium Development Goals has markedly stalled since 2015, challenging the timely attainment of the Sustainable Development Goal (SDG) targets by 2030. This is evidenced by the falling annual rate of reduction in indicators such as the maternal mortality ratio, under-five and neonatal mortality rates, premature mortality from major NCDs, and suicide and road traffic mortality rates. Almost halfway through the SDG era, some of these indicators are far from reaching the midpoint of the required trajectories to reach their respective SDG targets.

In addition, despite reduction in exposure to many health risks—such as tobacco use, unsafe water and sanitation, and child stunting—progress is inadequate. Risk exposure remains high, especially for factors such as alcohol consumption and hypertension where declines began only in recent years. Alarmingly, the entire global population (99%) breathes unhealthy levels of fine particulate matter, and the prevalence of obesity is moving in the wrong direction with no immediate sign of reversion.

Expansion of access to essential health services has slowed compared to pre-2015 gains, and there has been no significant progress in reducing financial hardship due to health-care costs. Inequalities persist, with disadvantaged populations having lower levels of access to health and related services but higher levels of exposure to health risks and higher levels of associated mortality. People living in less-resourced settings continue to have less access to a wide range of services, from the assistance of skilled health personnel during childbirth to clean cooking fuels and technology. Inequalities impede progress in responding to global crises, as has been shown during the COVID-19 pandemic.

The COVID-19 pandemic has led to 14.9 million excess deaths and cost 336.8 million years of life lost globally in 2020 and 2021. This means that, on average, each death directly or indirectly attributed to the COVID-19 pandemic by the end of 2021 led to a loss of more than 22 years of life—equivalent to over 5 years of life lost every second. The pandemic has also put many health-related indicators further off-track. As a result of service disruptions, the increasing trend in immunization coverage (including against measles, human papillomavirus, and diphtheria, tetanus and pertussis) and the declining trend in incidence of malaria and tuberculosis were both reversed, and fewer people were treated for neglected tropical diseases. The COVID-19 pandemic has exposed inequalities both between countries and within them, including inequalities in access to COVID-19 vaccines, with populations with lower educational levels and in low- and middle-income countries less likely to have received a COVID-19 vaccine.

The COVID-19 pandemic is a stark reminder that infectious diseases can emerge or re-emerge to cause harm—potentially to everyone. Infectious diseases that were previously under control may surge as a result of antimicrobial resistance, setting back progress. Meanwhile, climate change continues to degrade the environmental and social determinants of physical and mental health, posing enormous risks to us all.

The world has witnessed rapid demographic and epidemiological transitions throughout WHO’s 75 years of history. The share of deaths caused annually by NCDs has grown to nearly three quarters of all deaths and, if the trend continues, is projected to reach about 86% globally by WHO's 100th anniversary in 2048. The United Nations projects that total annual deaths will reach nearly 90 million globally in 2048; consequently, 77 million of these will be NCD deaths—a nearly 90% increase in absolute numbers over 2019.
Despite the progress and achievements in public health, inequalities persist. The most vulnerable populations continue to face an elevated risk of dying and disability from avoidable communicable, maternal, perinatal and malnutrition conditions, as well as injuries that are well prevented and controlled in higher-resourced settings. Along with these existing challenges, the emerging NCD pandemic associated with unhealthy lifestyles, environmental hazards and an ageing population creates a double burden of diseases in these populations.

Additionally, progress in combating some major causes of illness and premature deaths have stalled in recent years. For example, the declining trends in maternal and child mortality, premature mortality from NCDs, preventable deaths from injury, and prevalence of major risk factors, have markedly slowed since 2015. Similarly, the expansion in access to essential health services has slowed compared to pre-2015 gains, and there has been no significant progress in reducing financial hardship.

The COVID-19 pandemic is a reality check, reminding us that infectious diseases can emerge or re-emerge to cause harm potentially to everyone regardless of their location, age, sex, ethnicity and socioeconomic status. There are other emerging pathogens, including Ebola and Zika, and infections that were previously under control may surge as a result of antimicrobial resistance, setting back medical progress made in last century. Furthermore, climate change continues to degrade the environmental and social determinants of physical and mental health, posing enormous risks to health. These very real threats at global level show the pressing need for continued monitoring, enhanced awareness, cost-effective prevention and treatment strategies, and further development in medical sciences. Only with these can we secure the hard-won progress we have collaboratively made since the establishment of WHO 75 years ago.

This report documents successes and challenges in various aspects of public health, with a focus on the SDG indicators and the trends observed over the last few decades. The data and statistics presented in the annex are fundamental elements for laying out a strategic roadmap to sustain and accelerate progress to meeting the SDG targets and to further fulfilling WHO’s commitment to promoting the highest standard of health for all in the years to come.

If we are to track—accurately and continuously—population health (including burden of disease and risk factors), health system resources and outcomes, and the impact of global health events (both past and present), we must have timely and reliable data. The COVID-19 pandemic has highlighted the crucial need for robust and flexible health information systems. Yet despite progress in recent years, such systems are still insufficiently resourced in many countries and critical data are still lacking. In addition, the unfolding climate change crisis necessitates a strong and integrated monitoring system across different sectors. We must take urgent action to anticipate and respond to health challenges at global, regional, national and local levels—especially in order to protect vulnerable population groups. It is critical to have timely, reliable, and disaggregated data, estimates and forecasts to inform policy and actions at all levels to maximize health gains and eliminate inequalities. Concerted efforts championed by countries, WHO and partners to promote, provide and protect health for all in the years leading up to the end of the SDG era in 2030 will build a solid foundation for healthier populations around the globe in the decades to come.
```
References

1. Global health estimates 2019: Life expectancy, 2000–2019. Geneva: World Health Organization; 2020 (https://www.who.int/data/gho/data/themes/mortality-and-global-health-estimates/, accessed 2 May 2022). WHO Member States with a population of less than 90 000 in 2019 were not included in the analysis.

2. World population prospects: 2022 revision. New York (NY): United Nations, Department of Economic and Social Affairs, Population Division; 2022 (https://population.un.org/wpp/, accessed 22 April 2023).

3. Estimates and projections based on Global health estimates 2019: deaths by cause, age, sex, by country and by region, 2000–2019. Geneva: World Health Organization; 2020 (https://www.who.int/data/global-health-estimates, accessed 3 April 2023).

4. Vaccines and immunization. (Online). Geneva: World Health Organization (https://www.who.int/health-topics/vaccines-and-immunization, accessed 22 April 2023).

5. Public health milestones through the years. (Online). Geneva: World Health Organization (https://www.who.int/campaigns/75-years-of-improving-public-health/milestones#year-1945, accessed 22 April 2023).

6. Polio Global Eradication Initiative. (Online) (https://polioeradication.org/, accessed 22 April 2023).

7. Global HIV & AIDS statistics – Fact sheet. Geneva: Joint United Nations Programme on HIV/AIDS (UNAIDS) (https://www.unaids.org/en/resources/fact-sheet, accessed 22 April 2023).

8. Global tuberculosis report 2022. Geneva: World Health Organization; 2022 (https://www.who.int/publications/i/item/9789240061789, accessed 22 April 2023).

9. World malaria report 2022. Geneva: World Health Organization; 2022 (https://www.who.int/publications/i/item/9789240064898, accessed 22 April 2023).

10. Global report on neglected tropical diseases 2023. Geneva: World Health Organization; 2023 (https://www.who.int/publications/i/item/9789240062795, accessed 22 April 2023).

11. WHO global report on trends in prevalence of tobacco use 2000–2025, fourth edition. Geneva: World Health Organization; 2021 (https://www.who.int/publications/i/item/9789240039322, accessed 22 April 2023).

12. Levels and trends in child mortality. New York (NY): United Nations Children’s Fund; 2021 (https://www.who.int/publications/m/item/levels-and-trends-in-child-mortality-report-2021, accessed 22 April 2023).

13. Trends in maternal mortality 2000 to 2020: estimates by WHO, UNICEF, UNFPA, World Bank Group and UNDESA/Population Division. Geneva: World Health Organization; 2023 (https://www.who.int/publications/i/item/9789240068759, accessed 22 April 2023).

14. Estimates and projections based on Global Health Estimates 2019: disease burden by cause, age, sex, by country and by region, 2000–2019. Geneva, World Health Organization; 2020 (https://www.who.int/data/gho/data/themes/mortality-and-global-health-estimates, accessed 22 April 2023).
```
# Annex 1. Country, area, WHO region and global health statistics

## Explanatory notes

The statistics shown below are official WHO statistics for selected health-related SDG indicators and selected Thirteenth General Programme of Work indicators, based on data available in early 2023. In addition, summary measures of health, such as (healthy) life expectancy and total population, are included. These statistics have been compiled primarily from publications and databases produced and maintained by WHO, United Nations bodies of which WHO is a member, or other international organizations. In each instance, the source of the data series is provided.

The type of data used for each data series (comparable estimate or primary data) is also provided. Primary data are typically compiled from routine reporting or from publicly available sources such as Demographic and Health Surveys. Statistics are presented as they are reported or with minimal adjustment. Comparable estimates are achieved by adjusting or modelling country data to allow comparisons across countries and over time. Comparable estimates for the same reference years are produced for countries with underlying primary data and, in some cases, also for those without. Comparable estimates are subject to considerable uncertainty, especially for countries where the availability and quality of the underlying primary data are limited. Uncertainty intervals and other details on the indicators and statistics presented here can be found online at the WHO Global Health Observatory.

Although every effort has been made to maximize the comparability of statistics across countries and over time, data series based on primary data may differ in terms of the definitions, data collection methods, population coverage and estimation methods used. For indicators with a reference period expressed as a range, country values refer to the latest available year in the range unless otherwise noted; the accompanying footnotes provide more details. In some cases, in the absence of a recent set of data for a specific SDG or General Programme of Work indicator, a proxy indicator is presented in this annex; where this is the case, proxy indicators have been clearly indicated as such in accompanying footnotes.

Unless otherwise stated, the WHO regional and global aggregates for rates and ratios are presented as weighted averages when relevant, whereas they are the sums for absolute numbers. Aggregates are shown only if data are available for at least 50% of the population (or other denominator) within an indicated group, unless otherwise noted. For indicators with a reference period expressed as a range, aggregates are for the reference period shown in the heading of the corresponding table column above the WHO regional values. Some WHO regional and global aggregates may include country estimates that are not individually reported.

Changes in the values shown for indicators reported in previous editions of WHO’s World health statistics series should not be assumed to be accurate reflections of underlying trends. This applies to all data types (comparable estimates and primary data) and all reporting levels (country, regional and global). The data presented here may also differ from, and should not be regarded as, the official national statistics of individual countries or areas.

The notation "–" indicates that data are not applicable or not available.
```
{
  "table": {
    "headers": ["Countries and areas", "Total population ('000s)", "Life expectancy at birth (years)", "Healthy life expectancy at birth (years)"],
    "data": [
      {"Country": "Afghanistan", "2021": [20.255, 18.845, 0.099], "2019": [63.3, 63.2, 63.2], "Healthy life expectancy": [54.7, 53.2, 53.9]},
      {"Country": "Albania", "2021": [1.426, 1.429, 2.855], "2019": [76.3, 79.9, 78.0], "Healthy life expectancy": [68.0, 70.3, 69.1]},
      {"Country": "Algeria", "2021": [22.497, 21.681, 44.178], "2019": [76.2, 78.1, 77.1], "Healthy life expectancy": [66.7, 66.1, 66.4]},
      {"Country": "Andorra", "2021": [79], "2019": [79], "Healthy life expectancy": []},
      {"Country": "Angola", "2021": [17.051, 17.452, 304.607], "2019": [65.5, 63.1, 56.2], "Healthy life expectancy": [54.8, 54.8, 54.8]},
      {"Country": "Antigua and Barbuda", "2021": [45, 49, 93], "2019": [74.9, 78.0, 76.5], "Healthy life expectancy": [66.2, 67.0, 67.0]},
      {"Country": "Argentina", "2021": [22.465, 22.862, 45.277], "2019": [79.5, 76.6, 65.4], "Healthy life expectancy": [68.8, 67.1, 67.1]},
      {"Country": "Azerbaijan", "2021": [1.256, 1.524, 2.791], "2019": [72.5, 79.2, 76.0], "Healthy life expectancy": [64.9, 69.1, 67.1]},
      {"Country": "Australia", "2021": [12.868, 13.053, 25.921], "2019": [81.4, 83.0, 71.0], "Healthy life expectancy": [71.4, 71.4, 71.4]},
      {"Country": "Bahamas", "2021": [5.089, 2.524, 10.408], "2019": [76.6, 73.2, 62.3], "Healthy life expectancy": [65.6, 64.4, 64.4]},
      {"Country": "Bahrain", "2021": [909, 555, 1.463], "2019": [75.0, 75.8, 66.0], "Healthy life expectancy": [65.5, 65.9, 65.9]},
      {"Country": "Bangladesh", "2021": [83.998, 85.136, 368.362], "2019": [75.4, 64.2, 64.4], "Healthy life expectancy": []},
      {"Country": "Barbados", "2021": [135, 146, 281], "2019": [74.3, 77.6, 66.2], "Healthy life expectancy": [67.0, 67.0, 67.0]},
      {"Country": "Belarus", "2021": [415, 613, 978], "2019": [79.6, 79.6, 76.0], "Healthy life expectancy": [68.0, 68.0, 68.0]},
      {"Country": "Belgium", "2021": [5.735, 5.877, 11.793], "2019": [83.5, 81.8, 69.8], "Healthy life expectancy": [71.3, 71.3, 71.3]},
      {"Country": "Belize", "2021": [201, 799, 400], "2019": [71.4, 74.4, 63.5], "Healthy life expectancy": [67.3, 67.3, 67.3]},
      {"Country": "Benin", "2021": [6.476, 7.192, 612], "2019": [57.5, 54.5, 55.6], "Healthy life expectancy": [56.2, 56.2, 56.2]},
      {"Country": "Bhutan", "2021": [412, 366, 177], "2019": [74.4, 73.1, 62.3], "Healthy life expectancy": [63.5, 63.5, 63.5]},
      {"Country": "Bolivia (Plurinational State of)", "2021": [6.509, 6.270, 1.079], "2019": [71.2, 62.0, 63.1], "Healthy life expectancy": [63.1, 63.1, 63.1]},
      {"Country": "Bosnia and Herzegovina", "2021": [1.610, 1.621, 3.271], "2019": [74.4, 79.1, 76.8], "Healthy life expectancy": [65.7, 68.7, 67.2]},
      {"Country": "Botswana", "2021": [1.278, 1.318, 2.588], "2019": [58.9, 65.1, 62.2], "Healthy life expectancy": [51.2, 51.2, 51.2]},
      {"Country": "Brazil", "2021": [105.291, 109.035, 246.724], "2019": [79.5, 73.9, 63.4], "Healthy life expectancy": [65.2, 66.1, 66.1]},
      {"Country": "Brunei Darussalam", "2021": [230, 15.245, 734.74], "2019": [75.4, 74.5, 62.7], "Healthy life expectancy": [65.2, 65.7, 65.6]},
      {"Country": "Bulgaria", "2021": [3.339, 3.547, 886.716], "2019": [71.6, 75.1, 67.9], "Healthy life expectancy": [67.1, 67.1, 67.1]},
      {"Country": "Burkina Faso", "2021": [11.011, 0.930, 22.101], "2019": [65.2, 62.7, 54.9], "Healthy life expectancy": [48.5, 48.5, 48.5]},
      {"Country": "Burundi", "2021": [6.322, 6.319, 12.151], "2019": [61.5, 63.8, 57.2], "Healthy life expectancy": [56.0, 56.0, 56.0]},
      {"Country": "Cabo Verde", "2021": [1.157, 1.288, 588], "2019": [74.0, 62.2, 67.2], "Healthy life expectancy": [70.5, 71.0, 71.0]},
      {"Country": "Cambodia", "2021": [12.812, 8.377, 16.599], "2019": [72.7, 69.2, 63.0], "Healthy life expectancy": [59.2, 56.5, 56.5]},
      {"Country": "Cameroon", "2021": [13.564, 10.431, 29.197], "2019": [60.3, 64.5, 53.5], "Healthy life expectancy": [55.6, 55.6, 55.6]},
      {"Country": "Central African Republic", "2021": [2.728, 2.754, 547.502], "2019": [64.3, 64.8, 54.4], "Healthy life expectancy": [48.4, 48.4, 48.4]},
      {"Country": "Chad", "2021": [8.624, 8.556, 18.700], "2019": [58.0, 61.5, 51.6], "Healthy life expectancy": [53.4, 53.4, 53.4]},
      {"Country": "Chile", "2021": [9.186, 9.908, 19.493], "2019": [78.1, 80.0, 71.0], "Healthy life expectancy": [71.0, 71.0, 71.0]},
      {"Country": "China", "2021": [728.005, 697.843, 1425.494], "2019": [74.7, 80.5, 77.0], "Healthy life expectancy": [67.2, 67.2, 67.2]},
      {"Country": "China, Hong Kong SAR", "2021": [3.457, 3.638, 7.495], "2019": [], "Healthy life expectancy": []},
      {"Country": "China, Macao SAR", "2021": [322, 364, 687], "2019": [84.2, 76.1, 82.0], "Healthy life expectancy": []},
      {"Country": "Colombia", "2021": [25.615, 26.101, 51.517], "2019": [76.7, 81.9, 79.3], "Healthy life expectancy": [67.4, 70.5, 69.0]},
      {"Country": "Comoros", "2021": [413, 409, 822], "2019": [65.9, 67.4, 59.6], "Healthy life expectancy": []},
      {"Country": "Congo", "2021": [2.914, 2.921, 8.336], "2019": [65.6, 64.7, 56.4], "Healthy life expectancy": [56.1, 56.1, 56.1]},
      {"Country": "Cook Islands", "2021": [1, 2, 3], "2019": [17], "Healthy life expectancy": []},
      {"Country": "Costa Rica", "2021": [2.579, 2.575, 154.783], "2019": [83.4, 80.6, 71.0], "Healthy life expectancy": []},
      {"Country": "Côte d'Ivoire", "2021": [13.878, 13.601, 27.478], "2019": [65.8, 65.9, 56.4], "Healthy life expectancy": []},
      {"Country": "Croatia", "2021": [1.977, 2.860, 60.6], "2019": [75.5, 75.2, 68.7], "Healthy life expectancy": []},
      {"Country": "Cuba", "2021": [5.891, 6.567, 11.256], "2019": [74.8, 76.8, 66.6], "Healthy life expectancy": []},
      {"Country": "Cyprus", "2021": [623, 621, 124.481], "2019": [85.1, 81.3, 71.8], "Healthy life expectancy": []},
      {"Country": "Czechia", "2021": [1.576, 5.334, 10.511], "2019": [76.3, 79.1, 67.0], "Healthy life expectancy": []},
      {"Country": "Democratic People's Republic of Korea", "2021": [2.844, 1.138, 25.972], "2019": [69.3, 75.7, 72.6], "Healthy life expectancy": []},
      {"Country": "Democratic Republic of the Congo", "2021": [47.575, 48.396, 95.894], "2019": [64.8, 62.4, 53.6], "Healthy life expectancy": []},
      {"Country": "Denmark", "2021": [2.912, 2.942, 5.584], "2019": [79.6, 83.0, 81.3], "Healthy life expectancy": []},
      {"Country": "Djibouti", "2021": [549, 557, 1.106], "2019": [64.1, 67.8, 58.0], "Healthy life expectancy": []}
    ]
  }
}
json
{
  "table": [
    {
      "Maternal mortality ratio (per 100 000 live births)": "620",
      "Proportion of births attended by skilled health personnel (%)": "8",
      "Under-five mortality rate (per 1000 live births)": "78",
      "Neonatal mortality rate (per 1000 live births)": "41",
      "New HIV infections (per 1000 uninfected population)": "77",
      "Tuberculosis incidence (per 100 000 population)": "123",
      "Malaria incidence (per 100 000 population at risk)": "39",
      "Hepatitis B surface antigen (HBsAg) prevalence among children under 5 years (%)": "1",
      "Reported number of people requiring interventions against NTDs": "5"
    },
    {
      "Maternal mortality ratio (per 100 000 live births)": "62",
      "Proportion of births attended by skilled health personnel (%)": "9",
      "Under-five mortality rate (per 1000 live births)": "99",
      "Neonatal mortality rate (per 1000 live births)": "100",
      "New HIV infections (per 1000 uninfected population)": "99",
      "Tuberculosis incidence (per 100 000 population)": "98",
      "Malaria incidence (per 100 000 population at risk)": "98",
      "Hepatitis B surface antigen (HBsAg) prevalence among children under 5 years (%)": "3",
      "Reported number of people requiring interventions against NTDs": "1"
    },
    {
      "Maternal mortality ratio (per 100 000 live births)": "56",
      "Proportion of births attended by skilled health personnel (%)": "16",
      "Under-five mortality rate (per 1000 live births)": "22",
      "Neonatal mortality rate (per 1000 live births)": "19",
      "New HIV infections (per 1000 uninfected population)": "13",
      "Tuberculosis incidence (per 100 000 population)": "27",
      "Malaria incidence (per 100 000 population at risk)": "16",
      "Hepatitis B surface antigen (HBsAg) prevalence among children under 5 years (%)": "4",
      "Reported number of people requiring interventions against NTDs": "3"
    },
    // The table continues with the other rows
  ]
}
```Sure! Here is the markdown conversion of the table you provided:


| Countries and areas                | Total population ('000s) | Life expectancy at birth (years)                         | Healthy life expectancy at birth (years) |
|------------------------------------|---------------------------|---------------------------------------------------------|-------------------------------------------|
|                                    | 2021        | 2019        | Male   | Female | Both sexes | Male   | Female | Both sexes | Male   | Female | Both sexes |
| Dominica                           |  72         |           |  76.2  |  72.8  |  74.0  |  62.1  |  66.1  |  64.0  |           |           |           |
| Dominican Republic                 |  5,582      | 5,536     |  69.8  |  76.2  |  72.8  |  61.3  |  66.1  |  64.0  |           |           |           |
| Ecuador                            |  8,887      |  8,911    |  76.4  |  80.5  |  78.4  |  67.7  |  69.3  |  68.5  |           |           |           |
| Egypt                              |  55,260     | 54,002    |  69.6  |  74.1  |  71.8  |  62.3  |  63.7  |  63.0  |           |           |           |
| El Salvador                        |  3,007      | 3,007     |  70.6  |  79.1  |  75.0  |  61.6  |  67.8  |  64.9  |           |           |           |
| Equatorial Guinea                  |  863        | 771       |  63.6  |  62.2  |  62.4  |  54.1  |  53.9  |           |           |           |           |
| Eritrea                            |  1,786      | 1,834     |  61.3  |  67.1  |  64.1  |  57.7  |  59.5  |           |           |           |           |
| Estonia                            |  630        | 699       |  74.7  |  82.6  |  78.9  |  66.4  |  71.6  |           |           |           |           |
| Eswatini                           |  592        | 600       |  53.4  |  63.2  |  57.7  |  47.1  |  53.8  |  50.1  |           |           |           |
| Ethiopia                           |  60,443     | 59,840    |  66.9  |  70.5  |  68.7  |  60.9  |  60.8  |           |           |           |           |
| Fiji                               |  464        | 461       |  92.5  |  65.9  |  70.3  |  58.5  |  60.7  |  59.6  |           |           |           |
| Finland                            |  2,735      | 2,801     |  79.2  |  84.0  |  81.6  |  69.9  |  72.0  |  71.0  |           |           |           |
| France                             |  31,195     | 33,396    |  79.8  |  85.1  |  82.5  |  71.1  |  73.1  |           |           |           |           |
| Gabon                              |  1,192      | 1,139     |  63.6  |  69.7  |  66.5  |  56.0  |  57.6  |           |           |           |           |
| Gambia                             |  1,133      | 1,297     |  62.4  |  63.4  |  63.8  |  57.8  |  59.2  |           |           |           |           |
| Georgia                            |  1,170      | 1,758     |  68.8  |  77.8  |  73.3  |  61.4  |  67.9  |  64.7  |           |           |           |
| Germany                            |  41,754     | 42,955    |  78.7  |  84.8  |  81.7  |  69.7  |  71.9  |           |           |           |           |
| Ghana                              |  16,376     | 16,467    |  83.3  |  68.7  |  69.2  |  62.5  |  69.6  |  65.6  |           |           |           |
| Greece                             |  5,171      | 5,328     |  78.6  |  83.6  |  81.5  |  67.9  |  71.9  |           |           |           |           |
| Grenada                            |  62         |  62       |  75.7  |  75.3  |           |  62.6  |  65.4  |           |           |           |           |
| Guatemala                          |  8,177      | 8,892     |  70.6  |  75.0  |  72.0  |  60.5  |  64.1  |           |           |           |           |
| Guinea                             |  6,686      | 6,846     |  59.5  |  63.0  |  62.0  |  52.9  |  53.7  |           |           |           |           |
| Guinea-Bissau                      |  1,011      | 1,004     |  57.4  |  60.1  |  59.1  |  54.1  |  56.0  |           |           |           |           |
| Guyana                             |  394        | 411       |  62.5  |  69.4  |  65.7  |  55.1  |  59.7  |           |           |           |           |
| Haiti                              |  5,673      | 5,711     |  48.4  |  63.3  |  55.9  |  55.5  |  58.5  |           |           |           |           |
| Honduras                           |  1,571      | 5,008     |  70.8  |  73.2  |  71.9  |  67.2  |  63.0  |           |           |           |           |
| Hungary                            |  6,654      | 5,686     |  79.1  |  76.4  |  76.0  |  63.0  |  69.3  |           |           |           |           |
| Iceland                            |  370        | 370       |  80.8  |  83.9  |  82.3  |  72.3  |  72.0  |           |           |           |           |
| India                              |  726,503    | 681,600   |  70.4  |  74.6  |  72.5  |  70.8  |  60.3  |           |           |           |           |
| Indonesia                          |  183,821    | 185,091   |  73.5  |  69.4  |  71.8  |  63.8  |  65.6  |           |           |           |           |
| Iran (Islamic Republic of)        |  44,427     | 43,497    |  92.3  |  75.7  |  79.1  |  77.3  |  66.0  |           |           |           |           |
| Iraq                               |  21,797     | 23,176    |  73.4  |  53.4  |           |  62.4  |  61.7  |           |           |           |           |
| Ireland                            |  2,471      | 2,516     |  80.7  |  82.3  |  81.8  |  70.9  |  71.4  |           |           |           |           |
| Israel                             |  4,437      | 4,463     |  80.2  |  84.8  |  82.0  |  71.2  |  72.4  |           |           |           |           |
| Italy                              |  28,873     | 30,367    |  84.9  |  89.4  |  88.2  |  72.6  |  73.6  |           |           |           |           |
| Jamaica                            |  1,403      | 1,425     |  74.4  |  77.7  |  76.0  |  63.6  |  67.6  |           |           |           |           |
| Japan                              |  60,568     |  60,545   |  81.5  |  89.8  |  86.1  |  75.5  |           |           |           |           |           |
| Jordan                             |  7,580      | 5,386     |  71.8  |  77.6  |  74.0  |  62.4  |  67.4  |  65.0  |           |           |           |
| Kazakhstan                         |  2,930      |  3,966    |  76.9  |  79.2  |  76.3  |  66.1  |  67.4  |           |           |           |           |
| Kenya                              |  26,279     | 26,766    |  64.7  |  68.4  |  66.6  |  58.9  |  57.9  |           |           |           |           |
| Kiribati                           |  63         | 63       |  129   |  561  |  628.9  |  594.5 |  549.2 |           |           |           |           |
| Kuwait                             |  2,591      | 1,659     |  42.0  |  793  |  810.7 |  69.5  |  71.5  |           |           |           |           |
| Kyrgyzstan                         |  3,205      | 3,322     |  70.7  |  77.3  |  74.2  |  63.6  |  67.7  |           |           |           |           |
| Lao People's Democratic Republic    |  3,073      | 3,682     |  74.2  |  70.9  |  68.5  |  59.2  |  61.2  |           |           |           |           |
| Latvia                             |  868        | 1,006     |  79.6  |  79.8  |  75.4  |  62.9  |  63.9  |           |           |           |           |
| Lebanon                            |  2,713      | 2,730     |  75.4  |  74.0  |  70.0  |  65.1  |  67.0  |           |           |           |           |
| Lesotho                            |  1,126      | 1,156     |  47.2  |  54.2  |  50.7  |  42.6  |  42.4  |           |           |           |           |
| Liberia                            |  2,586      | 1,593     |  63.2  |  59.5  |  55.0  |  54.9  |  58.5  |           |           |           |           |
| Libya                              |  3,410      | 3,298     |  75.0  |  73.0  |  74.25 |  75.8  |  64.5  |           |           |           |           |
| Lithuania                          |  1,300      | 1,479     |  78.2  |  80.4  |  76.0  |  63.4  |  66.7  |           |           |           |           |
| Luxembourg                         |  322        | 381       |  80.6  |  82.4  |  81.4  |  70.2  |  71.6  |           |           |           |           |
| Madagascar                         |  14,691     | 14,258    |  68.6  |  66.5  |  67.5  |  57.9  |  57.3  |           |           |           |           |
| Malawi                             |  967        | 973       |  62.3  |  68.6  |  65.1  |  59.0  |  57.1  |           |           |           |           |
| Malaysia                           |  17,167     | 16,407    |  75.6  |  77.2  |  76.7  |  64.5  |  66.9  |           |           |           |           |
| Maldives                           |  301        | 221       |  78.6  |  80.8  |  79.7  |  70.0  |  70.0  |           |           |           |           |


The data has been structured in a markdown table format. The values are organized with respect to total population, life expectancy, and healthy life expectancy at birth for various countries and areas. 

If there are any specific details or further adjustments you need, feel free to ask!
| Year | Maternal mortality ratio (per 100,000 live births) | Proportion of births attended by skilled health personnel (%) | Under-five mortality rate (per 1000 live births) | Neonatal mortality rate (per 1000 live births) | New HIV infections (per 1000 uninfected population) | Tuberculosis incidence (per 100,000 population) | Malaria incidence (per 100,000 population at risk) | Hepatitis B surface antigen (HBsAg) prevalence among children under 5 years (%) | Reported number of people requiring interventions against NTDs |
|------|------------------------------------------------------|----------------------------------------------------------------|--------------------------------------------------|-----------------------------------------------------|--------------------------------------------------------|--------------------------------------------------|------------------------------------------------------------|------------------------------------------------------------------------|-----------------------------------------------------------|
| 2020 | 107                                                  | 99                                                             | 33                                               | 23                                                  | 0.39                                                   | 45                                               | 0.10                                                      | 2.612.634                                                               | 418                                                       |
| 2021 | 66                                                   | 99                                                             | 12                                               | 7                                                   | 0.11                                                   | 48                                               | 4.2                                                       | 0.09                                                                   | 22.080                                                    |
| 2021 | 17                                                   | 97                                                             | 10                                               | 10                                                  | 0.20                                                   | 2.932.816                                         | -                                                          | -                                                                      | -                                                         |
| 2021 | 43                                                   | 100                                                            | 12                                               | 6                                                   | 0.17                                                   | 49                                               | 0.0                                                       | 1.483.962                                                              | -                                                         |
| 2021 | 322                                                  | 38                                                             | 17                                               | 0.06                                                | 257                                                   | 12                                               | 0.29                                                      | 668.511                                                               | 462.141                                                   |
| 2021 | 5                                                    | 100                                                            | 2                                                | 1                                                   | 765                                                   | 348                                              | 0.9                                                       | 46.184                                                                | -                                                         |
| 2021 | 267                                                  | 50                                                             | 47                                               | 26                                                  | 0.12                                                   | 11                                               | 46.3                                                      | 159                                                                   | 71.787.220                                               |
| 2021 | 38                                                   | 100                                                            | 28                                               | 1                                                   | 0.19                                                   | 66                                               | 0.0                                                       | 923.067                                                               | -                                                         |
| 2021 | 8                                                    | 100                                                            | 2                                                | 1                                                   | 3.5                                                    | -                                                | -                                                          | 5                                                                     | -                                                         |
| 2021 | 8                                                    | 98                                                             | 4                                                | 3                                                   | 0.09                                                   | 77                                               | -                                                          | 88                                                                    | -                                                         |
| 2021 | 277                                                  | 40                                                             | 19                                               | 80                                                  | 0                                                    | 513                                              | 2289.21                                                  | 912.073                                                              | -                                                         |
| 2021 | 458                                                  | 84                                                             | 28                                               | 1                                                   | 0.80                                                   | 149                                              | 80.8                                                      | 160                                                                   | 478.576                                                 |
| 2021 | 28                                                   | 100                                                            | 9                                                | 5                                                   | 0.1                                                    | 64                                               | 6.0                                                       | 16                                                                    | -                                                         |
| 2021 | 4                                                    | 96                                                             | 4                                                | 2                                                   | 0.57                                                   | 136                                             | 164.4                                                    | 12.500.340                                                            | 131                                                       |
| 2021 | 8                                                    | 100                                                            | 4                                                | 2                                                   | 0.07                                                   | 4                                                | 0.1                                                       | 14                                                                    | 24                                                        |
| 2021 | 21                                                   | 100                                                            | 16                                               | 10                                                  | 3.2                                                    | 0.12                                               | 230                                                      | 0.0                                                                   | 230                                                       |
| 2021 | 96                                                   | 70                                                             | 2                                                | 11                                                  | 0.07                                                   | 27                                               | 0.03                                                      | 965.477                                                               | -                                                         |
| 2021 | 553                                                  | 54                                                             | 99                                               | 31                                                  | 0.49                                                   | 175                                               | 330.9                                                    | 607                                                                   | 8.407.131                                                  |
| 2021 | 725                                                  | 98                                                             | 34                                               | 12                                                  | 361                                                   | 10.51                                            | 211                                                       | 1.191.909                                                              | -                                                         |
| 2021 | 112                                                  | 98                                                             | 28                                               | 17                                                  | 0.62                                                   | 83                                               | 321                                                       | 0.40                                                                   | 685.968                                                    |
| 2021 | 350                                                  | 42                                                             | 59                                               | 24                                                  | 0.38                                                   | 159                                              | 1.04                                                      | 4.447.036                                                            | -                                                         |
| 2021 | 72                                                   | 94                                                             | 17                                               | 10                                                  | 0.08                                                   | 2.0                                               | 0.03                                                      | 2.363.251                                                              | -                                                         |
| 2021 | 15                                                   | 100                                                            | 4                                                | 2                                                   | 0.39                                                   | 0                                                | 0.0                                                       | 0                                                                     | 0                                                         |
| 2021 | 13                                                   | 97                                                             | 3                                                | 1                                                   | 0.03                                                   | 29                                               | 0.15                                                      | 0                                                                     | 0                                                         |
| 2021 | 103                                                  | 89                                                             | 31                                               | 19                                                  | 0.05                                                   | 210                                              | 3.2                                                       | 16                                                                    | 677.290.119                                               |
| 2021 | 173                                                  | 95                                                             | 22                                               | 11                                                  | 0.10                                                   | 354                                              | 3.0                                                       | 130                                                                   | 79.889.847                                                |
| 2021 | 22                                                   | 99                                                             | 13                                               | 8                                                   | 0.03                                                   | 12                                               | 0.0                                                       | 0                                                                     | 14.729                                                    |
| 2021 | 76                                                   | 96                                                             | 25                                               | 14                                                  | 0.29                                                   | 24                                               | 0.0                                                       | 2.170.486                                                              | -                                                         |
| 2021 | 5                                                    | 100                                                            | 3                                                | 2                                                   | 0.07                                                   | 4.8                                               | -                                                          | 0                                                                     | 1                                                         |
| 2021 | 3                                                    | 100                                                            | 4                                                | 2                                                   | 2.8                                                    | -                                                | -                                                          | -                                                                     | -                                                         |
| 2021 | 5                                                    | 100                                                            | 4                                                | 2                                                   | 0.49                                                   | 0.33                                              | -                                                          | 100                                                                   | -                                                         |
| 2021 | 99                                                   | 100                                                            | 12                                               | 10                                                  | 0.50                                                   | 3.5                                               | -                                                          | 96                                                                    | -                                                         |
| 2021 | 41                                                   | 100                                                            | 15                                               | 9                                                   | 0.18                                                   | 0.56                                              | -                                                          | 58                                                                    | -                                                         |
| 2021 | 13                                                   | 100                                                            | 10                                               | 5                                                   | 0.18                                                   | 0.15                                              | -                                                          | 0                                                                     | -                                                         |
| 2021 | 530                                                  | 70                                                             | 37                                               | 18                                                  | 0.73                                                   | 251                                              | 64.5                                                      | 10.649.944                                                            | -                                                         |
| 2021 | 76                                                   | 92                                                             | 48                                               | 21                                                  | 424                                                   | 1.57                                              | 125.740                                                  | -                                                                     | 17                                                        |
| 2021 | 7                                                    | 100                                                            | 9                                                | 5                                                   | 20                                                    | 0.03                                              | 17.0                                                       | 2.169.854                                                              | -                                                         |
| 2021 | 126                                                  | 64                                                             | 43                                               | 21                                                  | 143                                                   | 17                                               | 0.68                                                      | 25.290                                                               | -                                                         |
| 2021 | 18                                                   | 100                                                            | 4                                                | 2                                                   | 0.29                                                   | 16                                               | 0.27                                                      | 6                                                                     | -                                                         |
| 2021 | 21                                                   | 5                                                              | 0                                                | 5                                                   | 0.03                                                   | 97                                               | 0.0                                                       | 0                                                                     | -                                                         |
| 2021 | 566                                                  | 87                                                             | 73                                               | 35                                                  | 4.76                                                   | 614                                              | 122                                                       | 387.421                                                               | -                                                         |
| 2021 | 652                                                  | 84                                                             | 76                                               | 30                                                  | 308                                                   | 3567                                             | 4.66                                                      | 3.272.582                                                              | -                                                         |
| 2021 | 72                                                   | 100                                                            | 11                                               | 6                                                   | 0.07                                                   | 59                                               | -                                                          | 1.096                                                                 | -                                                         |
| 2021 | 9                                                    | 100                                                            | 3                                                | 2                                                   | 0.08                                                   | 26                                               | 0.0                                                       | 16                                                                    | -                                                         |
| 2021 | 6                                                    | 92                                                             | 2                                                | 2                                                   | 0.07                                                   | 61                                               | 0.06                                                      | 0                                                                     | -                                                         |
| 2021 | 381                                                  | 96                                                             | 42                                               | 19                                                  | 113                                                   | 132                                              | 2792.1                                                   | 139                                                                    | 13.130.699                                               |
| 2021 | 21                                                   | 100                                                            | 8                                                | 4                                                   | 0.17                                                   | 97                                               | 0.06                                                      | 26.507                                                               | -                                                         |
| 2021 | 57                                                   | 100                                                            | 6                                                | 4                                                   | 0.38                                                   | -                                                | 0.21                                                      | 24.589                                                               | -                                                         |


{
  "table": [
    {
      "Country": "Mali",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 11_061,
        "Female": 10_841,
        "Both Sexes": 21_905
      },
      "Life Expectancy at Birth (years)": {
        "Male": 62.2,
        "Female": 63.4,
        "Both Sexes": 62.8
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 54.8,
        "Female": 54.5,
        "Both Sexes": 54.6
      }
    },
    {
      "Country": "Malta",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 274,
        "Female": 253,
        "Both Sexes": 527
      },
      "Life Expectancy at Birth (years)": {
        "Male": 79.9,
        "Female": 83.8,
        "Both Sexes": 81.9
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 70.9,
        "Female": 71.5,
        "Both Sexes": 71.2
      }
    },
    {
      "Country": "Marshall Islands",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 42,
        "Female": null,
        "Both Sexes": null
      },
      "Life Expectancy at Birth (years)": {
        "Male": null,
        "Female": null,
        "Both Sexes": null
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": null,
        "Female": null,
        "Both Sexes": null
      }
    },
    {
      "Country": "Mauritania",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 2_261,
        "Female": 2_354,
        "Both Sexes": 4_615
      },
      "Life Expectancy at Birth (years)": {
        "Male": 68.1,
        "Female": 68.7,
        "Both Sexes": 68.4
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 60.2,
        "Female": 59.4,
        "Both Sexes": 59.8
      }
    },
    {
      "Country": "Mauritius",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 641,
        "Female": 658,
        "Both Sexes": 1_299
      },
      "Life Expectancy at Birth (years)": {
        "Male": 71.0,
        "Female": 77.3,
        "Both Sexes": 74.1
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 62.0,
        "Female": 65.9,
        "Both Sexes": 63.9
      }
    },
    {
      "Country": "Mexico",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 61_856,
        "Female": 64_849,
        "Both Sexes": 126_705
      },
      "Life Expectancy at Birth (years)": {
        "Male": 73.1,
        "Female": 78.9,
        "Both Sexes": 76.0
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 64.3,
        "Female": 67.2,
        "Both Sexes": 65.8
      }
    },
    {
      "Country": "Micronesia (Federated States of)",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 57,
        "Female": 56,
        "Both Sexes": 113
      },
      "Life Expectancy at Birth (years)": {
        "Male": 60.3,
        "Female": 66.0,
        "Both Sexes": 63.0
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 54.4,
        "Female": 57.8,
        "Both Sexes": 56.0
      }
    },
    {
      "Country": "Monaco",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 37,
        "Female": null,
        "Both Sexes": null
      },
      "Life Expectancy at Birth (years)": {
        "Male": null,
        "Female": null,
        "Both Sexes": null
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": null,
        "Female": null,
        "Both Sexes": null
      }
    },
    {
      "Country": "Mongolia",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 1_661,
        "Female": 1_686,
        "Both Sexes": 3_348
      },
      "Life Expectancy at Birth (years)": {
        "Male": 63.8,
        "Female": 72.8,
        "Both Sexes": 68.3
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 57.1,
        "Female": 63.8,
        "Both Sexes": 60.3
      }
    },
    {
      "Country": "Montenegro",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 306,
        "Female": 322,
        "Both Sexes": 628
      },
      "Life Expectancy at Birth (years)": {
        "Male": 73.2,
        "Female": 78.7,
        "Both Sexes": 75.9
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 65.2,
        "Female": 68.7,
        "Both Sexes": 67.0
      }
    },
    {
      "Country": "Morocco",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 18_666,
        "Female": 18_471,
        "Both Sexes": 37_137
      },
      "Life Expectancy at Birth (years)": {
        "Male": 71.7,
        "Female": 74.3,
        "Both Sexes": 73.0
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 63.7,
        "Female": 63.7,
        "Both Sexes": 63.7
      }
    },
    {
      "Country": "Mozambique",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 15_737,
        "Female": 36_420,
        "Both Sexes": 52_157
      },
      "Life Expectancy at Birth (years)": {
        "Male": 54.5,
        "Female": 61.7,
        "Both Sexes": 58.1
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 47.9,
        "Female": 52.4,
        "Both Sexes": 50.4
      }
    },
    {
      "Country": "Myanmar",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 26_783,
        "Female": 27_015,
        "Both Sexes": 53_798
      },
      "Life Expectancy at Birth (years)": {
        "Male": 65.9,
        "Female": 72.2,
        "Both Sexes": 69.1
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 58.8,
        "Female": 62.8,
        "Both Sexes": 60.9
      }
    },
    {
      "Country": "Namibia",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 1_221,
        "Female": 1_309,
        "Both Sexes": 2_530
      },
      "Life Expectancy at Birth (years)": {
        "Male": 60.6,
        "Female": 68.4,
        "Both Sexes": 64.6
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 53.4,
        "Female": 58.6,
        "Both Sexes": 56.1
      }
    },
    {
      "Country": "Nauru",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 13,
        "Female": null,
        "Both Sexes": null
      },
      "Life Expectancy at Birth (years)": {
        "Male": null,
        "Female": null,
        "Both Sexes": null
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": null,
        "Female": null,
        "Both Sexes": null
      }
    },
    {
      "Country": "Nepal",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 14_371,
        "Female": 15_664,
        "Both Sexes": 30_035
      },
      "Life Expectancy at Birth (years)": {
        "Male": 68.9,
        "Female": 72.7,
        "Both Sexes": 70.6
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 61.6,
        "Female": 62.1,
        "Both Sexes": 61.3
      }
    },
    {
      "Country": "Netherlands (Kingdom of the)",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 8_696,
        "Female": 8_507,
        "Both Sexes": 17_203
      },
      "Life Expectancy at Birth (years)": {
        "Male": 83.1,
        "Female": 81.8,
        "Both Sexes": 82.5
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 71.5,
        "Female": 71.7,
        "Both Sexes": 71.6
      }
    },
    {
      "Country": "New Zealand",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 2_542,
        "Female": 2_577,
        "Both Sexes": 5_119
      },
      "Life Expectancy at Birth (years)": {
        "Male": 80.4,
        "Female": 83.6,
        "Both Sexes": 82.0
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 69.6,
        "Female": 70.8,
        "Both Sexes": 70.2
      }
    },
    {
      "Country": "Nicaragua",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 3_376,
        "Female": 3_475,
        "Both Sexes": 6_851
      },
      "Life Expectancy at Birth (years)": {
        "Male": 72.1,
        "Female": 77.9,
        "Both Sexes": 75.7
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 62.7,
        "Female": 65.2,
        "Both Sexes": 64.0
      }
    },
    {
      "Country": "Niger",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 18_209,
        "Female": 12_444,
        "Both Sexes": 30_653
      },
      "Life Expectancy at Birth (years)": {
        "Male": 62.6,
        "Female": 63.5,
        "Both Sexes": 63.0
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 52.6,
        "Female": 54.5,
        "Both Sexes": 53.5
      }
    },
    {
      "Country": "Nigeria",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 107_827,
        "Female": 105_574,
        "Both Sexes": 213_401
      },
      "Life Expectancy at Birth (years)": {
        "Male": 61.2,
        "Female": 64.1,
        "Both Sexes": 62.6
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 53.9,
        "Female": 54.9,
        "Both Sexes": 54.4
      }
    },
    {
      "Country": "Niue",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 1_049,
        "Female": 1_055,
        "Both Sexes": 2_103
      },
      "Life Expectancy at Birth (years)": {
        "Male": 72.8,
        "Female": 76.9,
        "Both Sexes": 74.8
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 65.1,
        "Female": 67.3,
        "Both Sexes": 66.1
      }
    },
    {
      "Country": "North Macedonia",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 1_049,
        "Female": 1_059,
        "Both Sexes": 2_103
      },
      "Life Expectancy at Birth (years)": {
        "Male": 72.8,
        "Female": 76.9,
        "Both Sexes": 74.8
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 65.1,
        "Female": 67.3,
        "Both Sexes": 66.1
      }
    },
    {
      "Country": "Norway",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 2_676,
        "Female": 5_403,
        "Both Sexes": 8_081
      },
      "Life Expectancy at Birth (years)": {
        "Male": 81.4,
        "Female": 82.6,
        "Both Sexes": 81.0
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 71.6,
        "Female": 71.0,
        "Both Sexes": 71.3
      }
    },
    {
      "Country": "Occupied Palestinian Territory, including East Jerusalem",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 2_560,
        "Female": 2_573,
        "Both Sexes": 5_133
      },
      "Life Expectancy at Birth (years)": {
        "Male": 75.2,
        "Female": 73.1,
        "Both Sexes": 74.6
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 64.5,
        "Female": 64.5,
        "Both Sexes": 64.5
      }
    },
    {
      "Country": "Oman",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 2_762,
        "Female": null,
        "Both Sexes": null
      },
      "Life Expectancy at Birth (years)": {
        "Male": 73.0,
        "Female": null,
        "Both Sexes": null
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 64.5,
        "Female": null,
        "Both Sexes": null
      }
    },
    {
      "Country": "Pakistan",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 116_816,
        "Female": 114_586,
        "Both Sexes": 231_402
      },
      "Life Expectancy at Birth (years)": {
        "Male": 64.6,
        "Female": 66.7,
        "Both Sexes": 65.6
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 56.9,
        "Female": 58.6,
        "Both Sexes": 57.8
      }
    },
    {
      "Country": "Palau",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 2_177,
        "Female": 1_175,
        "Both Sexes": 3_051
      },
      "Life Expectancy at Birth (years)": {
        "Male": 76.6,
        "Female": 82.1,
        "Both Sexes": 79.3
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 67.4,
        "Female": 70.0,
        "Both Sexes": 68.7
      }
    },
    {
      "Country": "Panama",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 2_177,
        "Female": 1_175,
        "Both Sexes": 3_051
      },
      "Life Expectancy at Birth (years)": {
        "Male": 76.6,
        "Female": 82.1,
        "Both Sexes": 79.3
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 67.4,
        "Female": 70.0,
        "Both Sexes": 68.7
      }
    },
    {
      "Country": "Papua New Guinea",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 5_138,
        "Female": 4_812,
        "Both Sexes": 9_950
      },
      "Life Expectancy at Birth (years)": {
        "Male": 63.4,
        "Female": 67.6,
        "Both Sexes": 65.5
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 56.2,
        "Female": 58.1,
        "Both Sexes": 57.1
      }
    },
    {
      "Country": "Paraguay",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 3_363,
        "Female": 3_275,
        "Both Sexes": 6_638
      },
      "Life Expectancy at Birth (years)": {
        "Male": 73.0,
        "Female": 78.1,
        "Both Sexes": 75.6
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 65.4,
        "Female": 67.3,
        "Both Sexes": 66.4
      }
    },
    {
      "Country": "Peru",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 16_695,
        "Female": 17_020,
        "Both Sexes": 33_715
      },
      "Life Expectancy at Birth (years)": {
        "Male": 73.7,
        "Female": 78.3,
        "Both Sexes": 76.0
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 67.9,
        "Female": 69.2,
        "Both Sexes": 68.5
      }
    },
    {
      "Country": "Philippines",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 57_817,
        "Female": 60_168,
        "Both Sexes": 118_985
      },
      "Life Expectancy at Birth (years)": {
        "Male": 67.6,
        "Female": 71.6,
        "Both Sexes": 69.6
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 60.4,
        "Female": 62.6,
        "Both Sexes": 61.5
      }
    },
    {
      "Country": "Poland",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 18_526,
        "Female": 19_783,
        "Both Sexes": 38_309
      },
      "Life Expectancy at Birth (years)": {
        "Male": 74.5,
        "Female": 81.5,
        "Both Sexes": 78.0
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 67.0,
        "Female": 71.7,
        "Both Sexes": 69.2
      }
    },
    {
      "Country": "Portugal",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 4_855,
        "Female": 5_438,
        "Both Sexes": 10_293
      },
      "Life Expectancy at Birth (years)": {
        "Male": 78.6,
        "Female": 84.4,
        "Both Sexes": 81.5
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 66.4,
        "Female": 72.7,
        "Both Sexes": 69.8
      }
    },
    {
      "Country": "Puerto Rico",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 1_538,
        "Female": 1_176,
        "Both Sexes": 2_714
      },
      "Life Expectancy at Birth (years)": {
        "Male": 78.6,
        "Female": 78.0,
        "Both Sexes": 78.3
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 66.7,
        "Female": 68.5,
        "Both Sexes": 67.6
      }
    },
    {
      "Country": "Qatar",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 1_958,
        "Female": 2_345,
        "Both Sexes": 4_303
      },
      "Life Expectancy at Birth (years)": {
        "Male": 78.8,
        "Female": 76.6,
        "Both Sexes": 77.6
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 72.7,
        "Female": 71.9,
        "Both Sexes": 72.3
      }
    },
    {
      "Country": "Republic of Korea",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 25_863,
        "Female": 25_345,
        "Both Sexes": 51_208
      },
      "Life Expectancy at Birth (years)": {
        "Male": 80.3,
        "Female": 83.1,
        "Both Sexes": 81.7
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 74.6,
        "Female": 75.1,
        "Both Sexes": 74.8
      }
    },
    {
      "Country": "Republic of Moldova",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 1_453,
        "Female": 1_608,
        "Both Sexes": 3_061
      },
      "Life Expectancy at Birth (years)": {
        "Male": 69.3,
        "Female": 73.3,
        "Both Sexes": 71.3
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 61.7,
        "Female": 64.5,
        "Both Sexes": 63.1
      }
    },
    {
      "Country": "Romania",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 3_954,
        "Female": 3_984,
        "Both Sexes": 7_938
      },
      "Life Expectancy at Birth (years)": {
        "Male": 75.6,
        "Female": 79.3,
        "Both Sexes": 77.5
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 68.3,
        "Female": 69.4,
        "Both Sexes": 68.9
      }
    },
    {
      "Country": "Russian Federation",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 63_798,
        "Female": 71_775,
        "Both Sexes": 135_573
      },
      "Life Expectancy at Birth (years)": {
        "Male": 78.2,
        "Female": 73.2,
        "Both Sexes": 75.7
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 60.7,
        "Female": 62.0,
        "Both Sexes": 61.4
      }
    },
    {
      "Country": "Rwanda",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 6_582,
        "Female": 6_800,
        "Both Sexes": 13_482
      },
      "Life Expectancy at Birth (years)": {
        "Male": 68.1,
        "Female": 72.4,
        "Both Sexes": 70.3
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 59.0,
        "Female": 60.4,
        "Both Sexes": 59.7
      }
    },
    {
      "Country": "Saint Kitts and Nevis",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 81,
        "Female": 81,
        "Both Sexes": 162
      },
      "Life Expectancy at Birth (years)": {
        "Male": 77.7,
        "Female": 73.4,
        "Both Sexes": 75.5
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 63.6,
        "Female": 64.7,
        "Both Sexes": 64.1
      }
    },
    {
      "Country": "Saint Lucia",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 53,
        "Female": 51,
        "Both Sexes": 104
      },
      "Life Expectancy at Birth (years)": {
        "Male": 75.3,
        "Female": 75.3,
        "Both Sexes": 75.3
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 62.7,
        "Female": 61.5,
        "Both Sexes": 62.1
      }
    },
    {
      "Country": "Samoa",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 112,
        "Female": 107,
        "Both Sexes": 219
      },
      "Life Expectancy at Birth (years)": {
        "Male": 69.2,
        "Female": 71.8,
        "Both Sexes": 70.5
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 61.8,
        "Female": 62.5,
        "Both Sexes": 62.2
      }
    },
    {
      "Country": "San Marino",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 33,
        "Female": null,
        "Both Sexes": null
      },
      "Life Expectancy at Birth (years)": {
        "Male": 83.3,
        "Female": null,
        "Both Sexes": null
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 66.4,
        "Female": null,
        "Both Sexes": null
      }
    },
    {
      "Country": "Sao Tome and Principe",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 20_766,
        "Female": 15_184,
        "Both Sexes": 35_950
      },
      "Life Expectancy at Birth (years)": {
        "Male": 73.1,
        "Female": 76.1,
        "Both Sexes": 74.3
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 63.8,
        "Female": 64.0,
        "Both Sexes": 63.9
      }
    },
    {
      "Country": "Saudi Arabia",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 20_766,
        "Female": 15_184,
        "Both Sexes": 35_950
      },
      "Life Expectancy at Birth (years)": {
        "Male": 73.1,
        "Female": 76.1,
        "Both Sexes": 74.3
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 63.8,
        "Female": 64.0,
        "Both Sexes": 63.9
      }
    },
    {
      "Country": "Senegal",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 8_297,
        "Female": 8_800,
        "Both Sexes": 17_097
      },
      "Life Expectancy at Birth (years)": {
        "Male": 66.8,
        "Female": 70.1,
        "Both Sexes": 68.5
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 58.6,
        "Female": 59.8,
        "Both Sexes": 59.2
      }
    },
    {
      "Country": "Serbia",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 3_497,
        "Female": 3_290,
        "Both Sexes": 6_787
      },
      "Life Expectancy at Birth (years)": {
        "Male": 73.7,
        "Female": 78.3,
        "Both Sexes": 76.0
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 65.5,
        "Female": 68.9,
        "Both Sexes": 67.1
      }
    },
    {
      "Country": "Seychelles",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 56,
        "Female": 50,
        "Both Sexes": 106
      },
      "Life Expectancy at Birth (years)": {
        "Male": 70.0,
        "Female": 71.0,
        "Both Sexes": 70.5
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 61.6,
        "Female": 64.6,
        "Both Sexes": 63.1
      }
    },
    {
      "Country": "Sierra Leone",
      "Data Type": "2021",
      "Total Population (000's)": {
        "Male": 4_219,
        "Female": 4_202,
        "Both Sexes": 8_421
      },
      "Life Expectancy at Birth (years)": {
        "Male": 59.6,
        "Female": 61.9,
        "Both Sexes": 60.8
      },
      "Healthy Life Expectancy at Birth (years)": {
        "Male": 52.5,
        "Female": 53.3,
        "Both Sexes": 52.9
      }
    }
  ]
}

